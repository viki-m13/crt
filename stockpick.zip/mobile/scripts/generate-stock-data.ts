#!/usr/bin/env node
/**
 * Generate Pre-computed Stock Data
 *
 * This script fetches all stock data, calculates factor scores and backtest results,
 * and outputs a JSON file that can be hosted anywhere (GitHub Gist, GitHub Pages, etc.)
 *
 * Usage:
 *   1. Run locally: npx ts-node scripts/generate-stock-data.ts
 *   2. Or via GitHub Actions (see .github/workflows/generate-data.yml)
 *
 * Output: stock-data.json (upload this to your hosting)
 *
 * To use with GitHub Gist:
 *   1. Create a new Gist at https://gist.github.com
 *   2. Upload the generated stock-data.json
 *   3. Click "Raw" to get the raw URL
 *   4. Add to your app's ENV: EXPO_PUBLIC_PRECOMPUTED_DATA_URL=<raw_gist_url>
 */

// Note: This script is designed to run in Node.js, not React Native
// You'll need to run it on your computer or in a CI environment

const YAHOO_CHART_API = 'https://query1.finance.yahoo.com/v8/finance/chart';

const STOCK_UNIVERSE = [
  'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'NVDA', 'META', 'TSLA', 'BRK-B', 'JPM', 'JNJ',
  'V', 'UNH', 'HD', 'PG', 'MA', 'DIS', 'ADBE', 'NFLX', 'CRM', 'PYPL',
  'INTC', 'CSCO', 'PEP', 'ABT', 'TMO', 'COST', 'AVGO', 'ACN', 'MRK', 'NKE',
  'WMT', 'LLY', 'BAC', 'KO', 'PFE', 'ABBV', 'CVX', 'XOM', 'MCD', 'T',
  'ORCL', 'AMD', 'QCOM', 'TXN', 'LOW', 'UPS', 'NEE', 'RTX', 'HON', 'IBM',
  // Crypto ETFs
  'IBIT', 'GBTC', 'ETHE', 'BITO'
];

const STOCK_NAMES: Record<string, string> = {
  'AAPL': 'Apple Inc.',
  'MSFT': 'Microsoft Corp.',
  'GOOGL': 'Alphabet Inc.',
  'AMZN': 'Amazon.com Inc.',
  'NVDA': 'NVIDIA Corp.',
  'META': 'Meta Platforms',
  'TSLA': 'Tesla Inc.',
  'BRK-B': 'Berkshire Hathaway',
  'JPM': 'JPMorgan Chase',
  'JNJ': 'Johnson & Johnson',
  'V': 'Visa Inc.',
  'UNH': 'UnitedHealth Group',
  'HD': 'Home Depot',
  'PG': 'Procter & Gamble',
  'MA': 'Mastercard Inc.',
  'DIS': 'Walt Disney Co.',
  'ADBE': 'Adobe Inc.',
  'NFLX': 'Netflix Inc.',
  'CRM': 'Salesforce Inc.',
  'PYPL': 'PayPal Holdings',
  'INTC': 'Intel Corp.',
  'CSCO': 'Cisco Systems',
  'PEP': 'PepsiCo Inc.',
  'ABT': 'Abbott Labs',
  'TMO': 'Thermo Fisher',
  'COST': 'Costco Wholesale',
  'AVGO': 'Broadcom Inc.',
  'ACN': 'Accenture plc',
  'MRK': 'Merck & Co.',
  'NKE': 'Nike Inc.',
  'WMT': 'Walmart Inc.',
  'LLY': 'Eli Lilly',
  'BAC': 'Bank of America',
  'KO': 'Coca-Cola Co.',
  'PFE': 'Pfizer Inc.',
  'ABBV': 'AbbVie Inc.',
  'CVX': 'Chevron Corp.',
  'XOM': 'Exxon Mobil',
  'MCD': "McDonald's Corp.",
  'T': 'AT&T Inc.',
  'ORCL': 'Oracle Corp.',
  'AMD': 'AMD Inc.',
  'QCOM': 'Qualcomm Inc.',
  'TXN': 'Texas Instruments',
  'LOW': "Lowe's Companies",
  'UPS': 'United Parcel Service',
  'NEE': 'NextEra Energy',
  'RTX': 'RTX Corp.',
  'HON': 'Honeywell Intl.',
  'IBM': 'IBM Corp.',
  'IBIT': 'iShares Bitcoin Trust',
  'GBTC': 'Grayscale Bitcoin',
  'ETHE': 'Grayscale Ethereum',
  'BITO': 'ProShares Bitcoin'
};

interface StockData {
  symbol: string;
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  adjClose: number;
}

// Utility functions
function mean(arr: number[]): number {
  if (arr.length === 0) return 0;
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

function std(arr: number[]): number {
  if (arr.length < 2) return 0;
  const avg = mean(arr);
  const variance = arr.map(x => Math.pow(x - avg, 2)).reduce((a, b) => a + b, 0) / arr.length;
  return Math.sqrt(variance);
}

function zScore(value: number, values: number[]): number {
  const avg = mean(values);
  const stdDev = std(values);
  if (stdDev === 0) return 0;
  return Math.max(-3, Math.min(3, (value - avg) / stdDev));
}

function calculateReturns(prices: number[]): number[] {
  const returns: number[] = [];
  for (let i = 1; i < prices.length; i++) {
    if (prices[i - 1] > 0) {
      returns.push((prices[i] - prices[i - 1]) / prices[i - 1]);
    }
  }
  return returns;
}

function simpleMovingAverage(prices: number[], period: number): number[] {
  const sma: number[] = [];
  for (let i = 0; i < prices.length; i++) {
    if (i < period - 1) {
      sma.push(prices[i]);
    } else {
      const slice = prices.slice(i - period + 1, i + 1);
      sma.push(mean(slice));
    }
  }
  return sma;
}

function exponentialMovingAverage(prices: number[], period: number): number[] {
  const ema: number[] = [];
  const multiplier = 2 / (period + 1);
  if (prices.length === 0) return ema;
  ema[0] = prices[0];
  for (let i = 1; i < prices.length; i++) {
    ema[i] = (prices[i] - ema[i - 1]) * multiplier + ema[i - 1];
  }
  return ema;
}

// Factor calculations
function calculateMomentum(prices: number[], months: number, excludeRecent: number = 0): number {
  const tradingDaysPerMonth = 21;
  const lookback = months * tradingDaysPerMonth;
  const exclude = excludeRecent * tradingDaysPerMonth;
  if (prices.length < lookback + exclude + 5) return 0;
  const endIdx = prices.length - 1 - exclude;
  const startIdx = endIdx - lookback;
  if (startIdx < 0 || prices[startIdx] <= 0) return 0;
  return ((prices[endIdx] - prices[startIdx]) / prices[startIdx]) * 100;
}

function calculateValueScore(prices: number[]): number {
  if (prices.length < 252) return 50;
  const recent = prices.slice(-252);
  const high52w = Math.max(...recent);
  const current = prices[prices.length - 1];
  if (high52w === 0) return 50;
  const distanceFromHigh = ((current - high52w) / high52w) * 100;
  return Math.max(0, Math.min(100, 50 - distanceFromHigh));
}

function calculateQualityScore(prices: number[]): number {
  if (prices.length < 252) return 50;
  const returns = calculateReturns(prices.slice(-252));
  if (returns.length < 200) return 50;
  const positiveReturns = returns.filter(r => r > 0).length;
  const winRate = positiveReturns / returns.length;
  const monthlyReturns: number[] = [];
  for (let i = 21; i <= returns.length; i += 21) {
    const monthReturn = returns.slice(i - 21, i).reduce((a, b) => (1 + a) * (1 + b) - 1, 0);
    monthlyReturns.push(monthReturn);
  }
  const monthlyStd = std(monthlyReturns);
  const monthlyMean = mean(monthlyReturns);
  const consistencyRatio = monthlyMean > 0 && monthlyStd > 0 ? monthlyMean / monthlyStd : 0;
  let maxStreak = 0;
  let currentStreak = 0;
  for (const r of returns) {
    if (r > 0) {
      currentStreak++;
      maxStreak = Math.max(maxStreak, currentStreak);
    } else {
      currentStreak = 0;
    }
  }
  const winRateScore = winRate * 100;
  const consistencyScore = Math.min(100, Math.max(0, consistencyRatio * 200 + 50));
  const streakScore = Math.min(100, maxStreak * 5);
  return winRateScore * 0.4 + consistencyScore * 0.4 + streakScore * 0.2;
}

function calculateLowVolScore(prices: number[]): number {
  if (prices.length < 63) return 50;
  const returns = calculateReturns(prices.slice(-63));
  const vol = std(returns) * Math.sqrt(252) * 100;
  return Math.max(0, Math.min(100, 100 - (vol - 15) * 2));
}

function calculateTrendScore(prices: number[]): number {
  if (prices.length < 200) return 50;
  const current = prices[prices.length - 1];
  const sma20 = simpleMovingAverage(prices, 20);
  const sma50 = simpleMovingAverage(prices, 50);
  const sma200 = simpleMovingAverage(prices, 200);
  const ema12 = exponentialMovingAverage(prices, 12);
  const ema26 = exponentialMovingAverage(prices, 26);
  const sma20Current = sma20[sma20.length - 1];
  const sma50Current = sma50[sma50.length - 1];
  const sma200Current = sma200[sma200.length - 1];
  const ema12Current = ema12[ema12.length - 1];
  const ema26Current = ema26[ema26.length - 1];
  let score = 50;
  if (current > sma20Current) score += 10;
  if (current > sma50Current) score += 10;
  if (current > sma200Current) score += 15;
  if (sma20Current > sma50Current) score += 10;
  if (sma50Current > sma200Current) score += 15;
  const macd = ema12Current - ema26Current;
  const macdPercent = (macd / current) * 100;
  if (macdPercent > 0) score += Math.min(15, macdPercent * 10);
  if (macdPercent < 0) score -= Math.min(15, Math.abs(macdPercent) * 10);
  const sma20Prev = sma20[sma20.length - 21] || sma20Current;
  const slope = ((sma20Current - sma20Prev) / sma20Prev) * 100;
  score += Math.max(-15, Math.min(15, slope * 5));
  return Math.max(0, Math.min(100, score));
}

function calculateRelativeStrength(stockPrices: number[], marketPrices: number[], period: number = 63): number {
  if (stockPrices.length < period || marketPrices.length < period) return 0;
  const stockStart = stockPrices[stockPrices.length - period];
  const stockEnd = stockPrices[stockPrices.length - 1];
  const marketStart = marketPrices[marketPrices.length - period];
  const marketEnd = marketPrices[marketPrices.length - 1];
  if (stockStart <= 0 || marketStart <= 0) return 0;
  const stockReturn = (stockEnd - stockStart) / stockStart;
  const marketReturn = (marketEnd - marketStart) / marketStart;
  return (stockReturn - marketReturn) * 100;
}

function calculateBeta(stockReturns: number[], marketReturns: number[]): number {
  const n = Math.min(stockReturns.length, marketReturns.length, 252);
  if (n < 60) return 1;
  const sReturns = stockReturns.slice(-n);
  const mReturns = marketReturns.slice(-n);
  const stockMean = mean(sReturns);
  const marketMean = mean(mReturns);
  let covariance = 0;
  let marketVariance = 0;
  for (let i = 0; i < n; i++) {
    covariance += (sReturns[i] - stockMean) * (mReturns[i] - marketMean);
    marketVariance += Math.pow(mReturns[i] - marketMean, 2);
  }
  return marketVariance > 0 ? covariance / marketVariance : 1;
}

function calculateMaxDrawdown(prices: number[]): number {
  if (prices.length < 2) return 0;
  let maxDrawdown = 0;
  let peak = prices[0];
  for (const price of prices) {
    if (price > peak) peak = price;
    const drawdown = (peak - price) / peak;
    maxDrawdown = Math.max(maxDrawdown, drawdown);
  }
  return maxDrawdown * 100;
}

function calculateSharpeRatio(returns: number[], riskFreeRate: number = 0.04): number {
  if (returns.length < 21) return 0;
  const avgReturn = mean(returns) * 252;
  const volatility = std(returns) * Math.sqrt(252);
  if (volatility === 0) return 0;
  return (avgReturn - riskFreeRate) / volatility;
}

// Market regime detection
function detectMarketRegime(marketPrices: number[]) {
  if (marketPrices.length < 200) {
    return { type: 'NEUTRAL' as const, score: 50, volatilityRegime: 'NORMAL' as const, trendStrength: 0 };
  }
  const current = marketPrices[marketPrices.length - 1];
  const sma50 = simpleMovingAverage(marketPrices, 50);
  const sma200 = simpleMovingAverage(marketPrices, 200);
  const sma50Current = sma50[sma50.length - 1];
  const sma200Current = sma200[sma200.length - 1];
  const returns = calculateReturns(marketPrices.slice(-63));
  const currentVol = std(returns) * Math.sqrt(252) * 100;
  const historicalReturns = calculateReturns(marketPrices.slice(-252));
  const historicalVol = std(historicalReturns) * Math.sqrt(252) * 100;
  let volatilityRegime: 'LOW' | 'NORMAL' | 'HIGH' = 'NORMAL';
  if (currentVol < historicalVol * 0.7) volatilityRegime = 'LOW';
  if (currentVol > historicalVol * 1.3) volatilityRegime = 'HIGH';
  const aboveSma50 = current > sma50Current;
  const aboveSma200 = current > sma200Current;
  const goldenCross = sma50Current > sma200Current;
  let trendStrength = 0;
  if (aboveSma50) trendStrength += 25;
  if (aboveSma200) trendStrength += 25;
  if (goldenCross) trendStrength += 25;
  const ret3m = marketPrices.length >= 63
    ? (current - marketPrices[marketPrices.length - 63]) / marketPrices[marketPrices.length - 63] * 100
    : 0;
  if (ret3m > 5) trendStrength += 25;
  else if (ret3m < -5) trendStrength -= 25;
  let type: 'BULL' | 'BEAR' | 'NEUTRAL' | 'VOLATILE' = 'NEUTRAL';
  let score = 50;
  if (volatilityRegime === 'HIGH' && trendStrength < 50) {
    type = 'VOLATILE';
    score = 30;
  } else if (trendStrength >= 75) {
    type = 'BULL';
    score = 80;
  } else if (trendStrength <= 25) {
    type = 'BEAR';
    score = 20;
  }
  return { type, score, volatilityRegime, trendStrength };
}

// V2 Alpha Model factors
const SECTOR_MAP: Record<string, string> = {
  'AAPL': 'Technology', 'MSFT': 'Technology', 'GOOGL': 'Technology', 'AMZN': 'Consumer',
  'NVDA': 'Technology', 'META': 'Technology', 'TSLA': 'Consumer', 'BRK-B': 'Financials',
  'JPM': 'Financials', 'JNJ': 'Healthcare', 'V': 'Financials', 'UNH': 'Healthcare',
  'HD': 'Consumer', 'PG': 'Consumer', 'MA': 'Financials', 'DIS': 'Communication',
  'ADBE': 'Technology', 'NFLX': 'Communication', 'CRM': 'Technology', 'PYPL': 'Financials',
  'INTC': 'Technology', 'CSCO': 'Technology', 'PEP': 'Consumer', 'ABT': 'Healthcare',
  'TMO': 'Healthcare', 'COST': 'Consumer', 'AVGO': 'Technology', 'ACN': 'Technology',
  'MRK': 'Healthcare', 'NKE': 'Consumer', 'WMT': 'Consumer', 'LLY': 'Healthcare',
  'BAC': 'Financials', 'KO': 'Consumer', 'PFE': 'Healthcare', 'ABBV': 'Healthcare',
  'CVX': 'Energy', 'XOM': 'Energy', 'MCD': 'Consumer', 'T': 'Communication',
  'ORCL': 'Technology', 'AMD': 'Technology', 'QCOM': 'Technology', 'TXN': 'Technology',
  'LOW': 'Consumer', 'UPS': 'Industrials', 'NEE': 'Utilities', 'RTX': 'Industrials',
  'HON': 'Industrials', 'IBM': 'Technology',
  'IBIT': 'Crypto', 'GBTC': 'Crypto', 'ETHE': 'Crypto', 'BITO': 'Crypto'
};

function calculate52WeekHighScore(prices: number[]): number {
  if (prices.length < 252) return 50;
  const high52w = Math.max(...prices.slice(-252));
  const current = prices[prices.length - 1];
  if (high52w === 0) return 50;
  const percentFromHigh = (current / high52w) * 100;
  if (percentFromHigh >= 95) return 90 + (percentFromHigh - 95);
  if (percentFromHigh >= 90) return 75 + (percentFromHigh - 90) * 3;
  if (percentFromHigh >= 80) return 50 + (percentFromHigh - 80) * 2.5;
  return Math.max(0, percentFromHigh * 0.625);
}

function calculateVolumeAccumulationScore(prices: number[], volumes: number[]): number {
  if (prices.length < 21 || volumes.length < 21) return 50;
  let accumulation = 0;
  for (let i = prices.length - 20; i < prices.length; i++) {
    const priceChange = prices[i] - prices[i - 1];
    const avgVolume = mean(volumes.slice(Math.max(0, i - 20), i));
    if (avgVolume > 0) {
      const relVolume = volumes[i] / avgVolume;
      if (priceChange > 0) accumulation += relVolume;
      else if (priceChange < 0) accumulation -= relVolume;
    }
  }
  return Math.max(0, Math.min(100, 50 + accumulation * 2.5));
}

function calculateADXScore(highs: number[], lows: number[], closes: number[], period: number = 14): number {
  if (highs.length < period + 1) return 50;
  const trueRanges: number[] = [];
  const plusDMs: number[] = [];
  const minusDMs: number[] = [];
  for (let i = 1; i < highs.length; i++) {
    const high = highs[i];
    const low = lows[i];
    const prevClose = closes[i - 1];
    const prevHigh = highs[i - 1];
    const prevLow = lows[i - 1];
    trueRanges.push(Math.max(high - low, Math.abs(high - prevClose), Math.abs(low - prevClose)));
    const plusDM = high - prevHigh > prevLow - low ? Math.max(high - prevHigh, 0) : 0;
    const minusDM = prevLow - low > high - prevHigh ? Math.max(prevLow - low, 0) : 0;
    plusDMs.push(plusDM);
    minusDMs.push(minusDM);
  }
  if (trueRanges.length < period) return 50;
  const smoothedTR = mean(trueRanges.slice(-period));
  const smoothedPlusDM = mean(plusDMs.slice(-period));
  const smoothedMinusDM = mean(minusDMs.slice(-period));
  if (smoothedTR === 0) return 50;
  const plusDI = (smoothedPlusDM / smoothedTR) * 100;
  const minusDI = (smoothedMinusDM / smoothedTR) * 100;
  const diSum = plusDI + minusDI;
  const dx = diSum > 0 ? (Math.abs(plusDI - minusDI) / diSum) * 100 : 0;
  const trendDirection = plusDI > minusDI ? 1 : -1;
  if (dx < 20) return 40 + trendDirection * 5;
  if (dx < 40) return 50 + trendDirection * (dx - 20);
  return 50 + trendDirection * Math.min(40, dx - 20);
}

function calculateRSITrendScore(prices: number[], period: number = 14): number {
  if (prices.length < period + 1) return 50;
  const gains: number[] = [];
  const losses: number[] = [];
  for (let i = 1; i < prices.length; i++) {
    const change = prices[i] - prices[i - 1];
    gains.push(change > 0 ? change : 0);
    losses.push(change < 0 ? -change : 0);
  }
  const avgGain = mean(gains.slice(-period));
  const avgLoss = mean(losses.slice(-period));
  const rs = avgLoss > 0 ? avgGain / avgLoss : (avgGain > 0 ? 100 : 1);
  const rsi = 100 - (100 / (1 + rs));
  if (rsi >= 70) return 30 + (100 - rsi);
  if (rsi <= 30) return 70 + (30 - rsi);
  if (rsi >= 50 && rsi < 70) return 50 + (rsi - 50) * 1.5;
  return 50 - (50 - rsi) * 0.5;
}

function calculateHigherLowsScore(prices: number[]): number {
  if (prices.length < 60) return 50;
  const recent = prices.slice(-60);
  const windowSize = 10;
  const localLows: number[] = [];
  for (let i = windowSize; i < recent.length - windowSize; i += windowSize) {
    const window = recent.slice(i - windowSize, i + windowSize);
    const minIdx = window.indexOf(Math.min(...window));
    if (minIdx >= windowSize - 2 && minIdx <= windowSize + 2) {
      localLows.push(recent[i]);
    }
  }
  if (localLows.length < 2) return 50;
  let higherLows = 0;
  for (let i = 1; i < localLows.length; i++) {
    if (localLows[i] > localLows[i - 1]) higherLows++;
  }
  const score = (higherLows / (localLows.length - 1)) * 100;
  return Math.max(0, Math.min(100, score));
}

function calculateBreakoutScore(prices: number[], volumes: number[]): number {
  if (prices.length < 21) return 50;
  const recent20High = Math.max(...prices.slice(-21, -1));
  const recent20Low = Math.min(...prices.slice(-21, -1));
  const range = recent20High - recent20Low;
  const current = prices[prices.length - 1];
  if (range === 0) return 50;
  const avgVolume = mean(volumes.slice(-21, -1));
  const currentVolume = volumes[volumes.length - 1];
  const volumeRatio = avgVolume > 0 ? currentVolume / avgVolume : 1;
  if (current > recent20High) {
    const breakoutStrength = ((current - recent20High) / range) * 100;
    return Math.min(100, 60 + breakoutStrength * 2 + (volumeRatio > 1.5 ? 15 : 0));
  }
  if (current < recent20Low) {
    const breakdownStrength = ((recent20Low - current) / range) * 100;
    return Math.max(0, 40 - breakdownStrength * 2 - (volumeRatio > 1.5 ? 15 : 0));
  }
  const positionInRange = (current - recent20Low) / range;
  return 40 + positionInRange * 20;
}

function calculateVolatilityRegimeScore(prices: number[]): number {
  if (prices.length < 63) return 50;
  const returns = calculateReturns(prices);
  const recentVol = std(returns.slice(-21)) * Math.sqrt(252) * 100;
  const mediumVol = std(returns.slice(-63)) * Math.sqrt(252) * 100;
  if (mediumVol === 0) return 50;
  const volRatio = recentVol / mediumVol;
  if (volRatio < 0.7) return 70 + (0.7 - volRatio) * 50;
  if (volRatio > 1.3) return 30 - (volRatio - 1.3) * 30;
  return 50;
}

function calculateEarningsMomentumScore(prices: number[]): number {
  if (prices.length < 126) return 50;
  const quarterlyReturns: number[] = [];
  for (let i = 63; i <= Math.min(252, prices.length); i += 63) {
    const idx = prices.length - i;
    const startIdx = Math.max(0, idx - 63);
    if (prices[startIdx] > 0) {
      quarterlyReturns.push((prices[idx] - prices[startIdx]) / prices[startIdx]);
    }
  }
  if (quarterlyReturns.length < 2) return 50;
  const recentQuarter = quarterlyReturns[0] || 0;
  const prevQuarter = quarterlyReturns[1] || 0;
  const acceleration = recentQuarter - prevQuarter;
  return Math.max(0, Math.min(100, 50 + acceleration * 200));
}

function calculateSectorStrength(symbol: string, allReturns: Map<string, number>): number {
  const sector = SECTOR_MAP[symbol];
  if (!sector) return 50;
  const sectorReturns: number[] = [];
  for (const [sym, ret] of allReturns.entries()) {
    if (SECTOR_MAP[sym] === sector) {
      sectorReturns.push(ret);
    }
  }
  if (sectorReturns.length === 0) return 50;
  const avgSectorReturn = mean(sectorReturns);
  const allReturnValues = Array.from(allReturns.values());
  const avgMarketReturn = mean(allReturnValues);
  const relativeStrength = avgSectorReturn - avgMarketReturn;
  return Math.max(0, Math.min(100, 50 + relativeStrength * 500));
}

interface AlphaFactorsV2 {
  highScore52w: number;
  volumeAccum: number;
  adxTrend: number;
  rsiTrend: number;
  higherLows: number;
  breakout: number;
  volRegime: number;
  earningsMomentum: number;
  sectorStrength: number;
}

function calculateAlphaScoreV2(factors: AlphaFactorsV2): { score: number; signal: string; confidence: number } {
  const weights = {
    highScore52w: 0.20,
    volumeAccum: 0.12,
    adxTrend: 0.15,
    rsiTrend: 0.10,
    higherLows: 0.13,
    breakout: 0.12,
    volRegime: 0.08,
    earningsMomentum: 0.05,
    sectorStrength: 0.05,
  };

  const score =
    factors.highScore52w * weights.highScore52w +
    factors.volumeAccum * weights.volumeAccum +
    factors.adxTrend * weights.adxTrend +
    factors.rsiTrend * weights.rsiTrend +
    factors.higherLows * weights.higherLows +
    factors.breakout * weights.breakout +
    factors.volRegime * weights.volRegime +
    factors.earningsMomentum * weights.earningsMomentum +
    factors.sectorStrength * weights.sectorStrength;

  const bullishFactors = [
    factors.highScore52w > 70,
    factors.volumeAccum > 60,
    factors.adxTrend > 60,
    factors.higherLows > 60,
    factors.breakout > 60,
  ].filter(Boolean).length;

  const bearishFactors = [
    factors.highScore52w < 30,
    factors.volumeAccum < 40,
    factors.adxTrend < 40,
    factors.breakout < 40,
  ].filter(Boolean).length;

  let signal: string;
  if (score >= 70 && bullishFactors >= 4) signal = 'STRONG_BUY';
  else if (score >= 60 && bullishFactors >= 3) signal = 'BUY';
  else if (score <= 35 || bearishFactors >= 3) signal = 'AVOID';
  else signal = 'HOLD';

  const confidence = Math.min(100, Math.abs(score - 50) * 2 + bullishFactors * 5);

  return { score: Math.max(0, Math.min(100, score)), signal, confidence };
}

// Fetch stock data from Yahoo Finance
async function fetchStockDataYahoo(symbol: string, period: string = '2y'): Promise<StockData[]> {
  try {
    const url = `${YAHOO_CHART_API}/${symbol}?interval=1d&range=${period}`;
    const response = await fetch(url, {
      headers: { 'User-Agent': 'Mozilla/5.0' },
    });

    if (!response.ok) {
      throw new Error(`HTTP error: ${response.status}`);
    }

    const data = await response.json();
    if (data.chart.error || !data.chart.result?.[0]) {
      throw new Error(`Yahoo API error: ${data.chart.error?.description || 'No data'}`);
    }

    const result = data.chart.result[0];
    const timestamps = result.timestamp || [];
    const quotes = result.indicators.quote[0];
    const adjClose = result.indicators.adjclose?.[0]?.adjclose || quotes.close;

    const stockData: StockData[] = [];
    for (let i = 0; i < timestamps.length; i++) {
      if (quotes.close[i] != null) {
        stockData.push({
          symbol,
          date: new Date(timestamps[i] * 1000).toISOString().split('T')[0],
          open: quotes.open[i] || 0,
          high: quotes.high[i] || 0,
          low: quotes.low[i] || 0,
          close: quotes.close[i],
          volume: quotes.volume[i] || 0,
          adjClose: adjClose[i] || quotes.close[i],
        });
      }
    }
    return stockData;
  } catch (error) {
    console.error(`Error fetching ${symbol}:`, error);
    return [];
  }
}

// Main generation function
async function generateStockData() {
  console.log('Starting stock data generation...');
  console.log(`Processing ${STOCK_UNIVERSE.length} stocks + SPY`);

  const allSymbols = [...STOCK_UNIVERSE, 'SPY'];
  const dataMap = new Map<string, StockData[]>();

  // Fetch all data
  console.log('Fetching historical data...');
  const batchSize = 5;
  for (let i = 0; i < allSymbols.length; i += batchSize) {
    const batch = allSymbols.slice(i, i + batchSize);
    console.log(`  Batch ${Math.floor(i / batchSize) + 1}/${Math.ceil(allSymbols.length / batchSize)}: ${batch.join(', ')}`);

    const results = await Promise.all(batch.map(s => fetchStockDataYahoo(s, '2y')));
    batch.forEach((symbol, index) => {
      if (results[index].length > 0) {
        dataMap.set(symbol, results[index]);
      }
    });

    if (i + batchSize < allSymbols.length) {
      await new Promise(resolve => setTimeout(resolve, 500));
    }
  }

  console.log(`Successfully fetched data for ${dataMap.size} symbols`);

  // Calculate scores
  console.log('Calculating factor scores...');

  const spyData = dataMap.get('SPY') || [];
  const spyPrices = spyData.map(d => d.adjClose);
  const spyReturns = calculateReturns(spyPrices);
  const regime = detectMarketRegime(spyPrices);

  // Calculate 1-month returns for sector strength
  const allStockReturns = new Map<string, number>();
  for (const symbol of STOCK_UNIVERSE) {
    const stockData = dataMap.get(symbol);
    if (!stockData || stockData.length < 21) continue;
    const prices = stockData.map(d => d.adjClose);
    const startPrice = prices[prices.length - 22] || prices[0];
    const endPrice = prices[prices.length - 1];
    if (startPrice > 0) {
      allStockReturns.set(symbol, (endPrice - startPrice) / startPrice);
    }
  }

  // First pass: collect raw factors for z-score normalization
  const allMomentum12m: number[] = [];
  const allMomentum6m: number[] = [];
  const allRelStrength: number[] = [];
  const rawFactors = new Map();

  for (const symbol of STOCK_UNIVERSE) {
    const stockData = dataMap.get(symbol);
    if (!stockData || stockData.length < 252) continue;
    const prices = stockData.map(d => d.adjClose);
    const momentum12m = calculateMomentum(prices, 12, 1) / 100;
    const momentum6m = calculateMomentum(prices, 6, 0) / 100;
    const relStrength = calculateRelativeStrength(prices, spyPrices, 63);
    allMomentum12m.push(momentum12m);
    allMomentum6m.push(momentum6m);
    allRelStrength.push(relStrength);
    rawFactors.set(symbol, { momentum12m, momentum6m, relStrength });
  }

  // Second pass: calculate final scores
  const scores: any[] = [];

  for (const symbol of STOCK_UNIVERSE) {
    const stockData = dataMap.get(symbol);
    if (!stockData || stockData.length < 252) continue;

    const prices = stockData.map(d => d.adjClose);
    const highs = stockData.map(d => d.high);
    const lows = stockData.map(d => d.low);
    const volumes = stockData.map(d => d.volume);
    const stockReturns = calculateReturns(prices);
    const currentPrice = prices[prices.length - 1];

    const raw = rawFactors.get(symbol);
    const momentum1m = calculateMomentum(prices, 1, 0) / 100;
    const valueScore = calculateValueScore(prices);
    const qualityScore = calculateQualityScore(prices);
    const lowVolScore = calculateLowVolScore(prices);
    const trendScore = calculateTrendScore(prices);

    const factors = {
      momentum12m: zScore(raw.momentum12m, allMomentum12m),
      momentum6m: zScore(raw.momentum6m, allMomentum6m),
      momentum1m,
      valueScore,
      qualityScore,
      lowVolScore,
      trendScore,
      relStrength: zScore(raw.relStrength, allRelStrength),
    };

    // Proprietary V2 factors
    const propFactors: AlphaFactorsV2 = {
      highScore52w: calculate52WeekHighScore(prices),
      volumeAccum: calculateVolumeAccumulationScore(prices, volumes),
      adxTrend: calculateADXScore(highs, lows, prices, 14),
      rsiTrend: calculateRSITrendScore(prices),
      higherLows: calculateHigherLowsScore(prices),
      breakout: calculateBreakoutScore(prices, volumes),
      volRegime: calculateVolatilityRegimeScore(prices),
      earningsMomentum: calculateEarningsMomentumScore(prices),
      sectorStrength: calculateSectorStrength(symbol, allStockReturns),
    };

    const { score: alphaScore, signal, confidence } = calculateAlphaScoreV2(propFactors);

    // Risk metrics
    const volatility = std(stockReturns.slice(-63)) * Math.sqrt(252) * 100;
    const beta = calculateBeta(stockReturns, spyReturns);
    const maxDrawdown = calculateMaxDrawdown(prices.slice(-252));
    const sharpeRatio = calculateSharpeRatio(stockReturns.slice(-252));

    // Expected return
    const high52wContrib = (propFactors.highScore52w - 50) * 0.3;
    const breakoutContrib = (propFactors.breakout - 50) * 0.2;
    const adxContrib = (propFactors.adxTrend - 50) * 0.15;
    const volRegimeAdj = propFactors.volRegime > 60 ? 1.1 : (propFactors.volRegime < 40 ? 0.8 : 1.0);
    const rawExpected = (high52wContrib + breakoutContrib + adxContrib) * volRegimeAdj;
    const regimeAdj = regime.type === 'BULL' ? 1.3 : (regime.type === 'BEAR' ? 0.6 : 1.0);
    const expectedReturn = Math.max(-15, Math.min(25, rawExpected * regimeAdj / 10));

    scores.push({
      symbol,
      name: STOCK_NAMES[symbol] || symbol,
      currentPrice,
      factors,
      momentumComposite: factors.momentum12m * 0.6 + factors.momentum6m * 0.3,
      qualityValue: (qualityScore + valueScore) / 2,
      riskAdjusted: (lowVolScore + qualityScore) / 2,
      alphaScore,
      regimeScore: regime.score,
      regimeType: regime.type,
      volatility,
      beta,
      maxDrawdown,
      sharpeRatio,
      signal,
      conviction: confidence,
      expectedReturn,
    });
  }

  scores.sort((a, b) => b.alphaScore - a.alphaScore);

  console.log(`Calculated scores for ${scores.length} stocks`);

  // Generate output
  const now = new Date();
  const expiresAt = new Date(now.getTime() + 24 * 60 * 60 * 1000); // 24 hours

  const output = {
    generatedAt: now.toISOString(),
    expiresAt: expiresAt.toISOString(),
    stockScores: scores,
    backtestResults: [], // Backtest is expensive, skip for now
    backtestSummary: null,
  };

  // Output to stdout (can redirect to file)
  console.log('\n--- OUTPUT JSON ---\n');
  console.log(JSON.stringify(output, null, 2));

  console.log('\n--- GENERATION COMPLETE ---');
  console.log(`Generated at: ${now.toISOString()}`);
  console.log(`Expires at: ${expiresAt.toISOString()}`);
  console.log(`Total stocks: ${scores.length}`);
  console.log(`Top picks: ${scores.slice(0, 5).map(s => s.symbol).join(', ')}`);
}

// Run
generateStockData().catch(console.error);
