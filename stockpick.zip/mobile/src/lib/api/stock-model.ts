/**
 * Multi-Factor Alpha Model
 *
 * Combines proven quantitative factors that have historically generated alpha:
 * 1. Momentum (12-1): Price momentum excluding most recent month (mean-reversion)
 * 2. Value: Price-to-fundamentals ratios (using price/52w high as proxy)
 * 3. Quality: Stability and consistency metrics
 * 4. Low Volatility: Risk-adjusted returns favor lower vol stocks
 * 5. Trend Following: Moving average crossovers and price structure
 *
 * Key innovations:
 * - Factor z-score normalization for cross-sectional comparison
 * - Dynamic factor weighting based on market regime
 * - Volatility targeting for position sizing
 * - Composite signal with multiple confirmation gates
 */

// Expanded universe focusing on liquid large/mid caps
export const STOCK_UNIVERSE = [
  'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'NVDA', 'META', 'TSLA', 'BRK-B', 'JPM', 'JNJ',
  'V', 'UNH', 'HD', 'PG', 'MA', 'DIS', 'ADBE', 'NFLX', 'CRM', 'PYPL',
  'INTC', 'CSCO', 'PEP', 'ABT', 'TMO', 'COST', 'AVGO', 'ACN', 'MRK', 'NKE',
  'WMT', 'LLY', 'BAC', 'KO', 'PFE', 'ABBV', 'CVX', 'XOM', 'MCD', 'T',
  'ORCL', 'AMD', 'QCOM', 'TXN', 'LOW', 'UPS', 'NEE', 'RTX', 'HON', 'IBM'
];

export interface StockData {
  symbol: string;
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  adjClose: number;
}

export interface FactorScores {
  momentum12m: number;      // 12-month momentum (excluding last month)
  momentum6m: number;       // 6-month momentum
  momentum1m: number;       // 1-month momentum (mean reversion signal)
  valueScore: number;       // Distance from 52-week high
  qualityScore: number;     // Consistency of returns
  lowVolScore: number;      // Inverse volatility rank
  trendScore: number;       // MA crossover strength
  relStrength: number;      // Relative strength vs market
}

export interface AlphaScore {
  symbol: string;
  name: string;
  currentPrice: number;

  // Individual factor scores (z-normalized, -3 to +3)
  factors: FactorScores;

  // Composite scores
  momentumComposite: number;  // Combined momentum signal
  qualityValue: number;       // Combined quality + value
  riskAdjusted: number;       // Risk-adjusted composite

  // Final alpha score (0-100)
  alphaScore: number;

  // Market regime context
  regimeScore: number;        // How favorable is current regime
  regimeType: 'BULL' | 'BEAR' | 'NEUTRAL' | 'VOLATILE';

  // Risk metrics
  volatility: number;
  beta: number;
  maxDrawdown: number;
  sharpeRatio: number;

  // Signal
  signal: 'STRONG_BUY' | 'BUY' | 'HOLD' | 'AVOID';
  conviction: number;
  expectedReturn: number;
}

export interface BacktestResult {
  date: string;
  modelReturn: number;
  sp500Return: number;
  cumulativeModelReturn: number;
  cumulativeSp500Return: number;
  topPicks: string[];
  regime: string;
}

export interface BacktestSummary {
  totalModelReturn: number;
  totalSp500Return: number;
  annualizedModelReturn: number;
  annualizedSp500Return: number;
  alpha: number;
  sharpeRatio: number;
  sortinoRatio: number;
  maxDrawdown: number;
  calmarRatio: number;
  winRate: number;
  avgWin: number;
  avgLoss: number;
  profitFactor: number;
  totalTrades: number;
  outperformancePeriods: number;
  totalPeriods: number;
  informationRatio: number;
  trackingError: number;
}

export const STOCK_NAMES: Record<string, string> = {
  'AAPL': 'Apple Inc.',
  'MSFT': 'Microsoft Corp.',
  'GOOGL': 'Alphabet Inc.',
  'AMZN': 'Amazon.com Inc.',
  'NVDA': 'NVIDIA Corp.',
  'META': 'Meta Platforms',
  'TSLA': 'Tesla Inc.',
  'BRK-B': 'Berkshire Hathaway',
  'JPM': 'JPMorgan Chase',
  'JNJ': 'Johnson & Johnson',
  'V': 'Visa Inc.',
  'UNH': 'UnitedHealth Group',
  'HD': 'Home Depot',
  'PG': 'Procter & Gamble',
  'MA': 'Mastercard Inc.',
  'DIS': 'Walt Disney Co.',
  'ADBE': 'Adobe Inc.',
  'NFLX': 'Netflix Inc.',
  'CRM': 'Salesforce Inc.',
  'PYPL': 'PayPal Holdings',
  'INTC': 'Intel Corp.',
  'CSCO': 'Cisco Systems',
  'PEP': 'PepsiCo Inc.',
  'ABT': 'Abbott Labs',
  'TMO': 'Thermo Fisher',
  'COST': 'Costco Wholesale',
  'AVGO': 'Broadcom Inc.',
  'ACN': 'Accenture plc',
  'MRK': 'Merck & Co.',
  'NKE': 'Nike Inc.',
  'WMT': 'Walmart Inc.',
  'LLY': 'Eli Lilly',
  'BAC': 'Bank of America',
  'KO': 'Coca-Cola Co.',
  'PFE': 'Pfizer Inc.',
  'ABBV': 'AbbVie Inc.',
  'CVX': 'Chevron Corp.',
  'XOM': 'Exxon Mobil',
  'MCD': "McDonald's Corp.",
  'T': 'AT&T Inc.',
  'ORCL': 'Oracle Corp.',
  'AMD': 'AMD Inc.',
  'QCOM': 'Qualcomm Inc.',
  'TXN': 'Texas Instruments',
  'LOW': "Lowe's Companies",
  'UPS': 'United Parcel Service',
  'NEE': 'NextEra Energy',
  'RTX': 'RTX Corp.',
  'HON': 'Honeywell Intl.',
  'IBM': 'IBM Corp.'
};

// ==================== UTILITY FUNCTIONS ====================

export function calculateReturns(prices: number[]): number[] {
  const returns: number[] = [];
  for (let i = 1; i < prices.length; i++) {
    if (prices[i - 1] > 0) {
      returns.push((prices[i] - prices[i - 1]) / prices[i - 1]);
    }
  }
  return returns;
}

export function calculateLogReturns(prices: number[]): number[] {
  const returns: number[] = [];
  for (let i = 1; i < prices.length; i++) {
    if (prices[i - 1] > 0 && prices[i] > 0) {
      returns.push(Math.log(prices[i] / prices[i - 1]));
    }
  }
  return returns;
}

function mean(arr: number[]): number {
  if (arr.length === 0) return 0;
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

function std(arr: number[]): number {
  if (arr.length < 2) return 0;
  const avg = mean(arr);
  const variance = arr.map(x => Math.pow(x - avg, 2)).reduce((a, b) => a + b, 0) / arr.length;
  return Math.sqrt(variance);
}

function zScore(value: number, values: number[]): number {
  const avg = mean(values);
  const stdDev = std(values);
  if (stdDev === 0) return 0;
  return Math.max(-3, Math.min(3, (value - avg) / stdDev));
}

function percentileRank(value: number, values: number[]): number {
  const sorted = [...values].sort((a, b) => a - b);
  const idx = sorted.findIndex(v => v >= value);
  if (idx === -1) return 100;
  return (idx / sorted.length) * 100;
}

function exponentialMovingAverage(prices: number[], period: number): number[] {
  const ema: number[] = [];
  const multiplier = 2 / (period + 1);

  if (prices.length === 0) return ema;

  ema[0] = prices[0];
  for (let i = 1; i < prices.length; i++) {
    ema[i] = (prices[i] - ema[i - 1]) * multiplier + ema[i - 1];
  }
  return ema;
}

function simpleMovingAverage(prices: number[], period: number): number[] {
  const sma: number[] = [];
  for (let i = 0; i < prices.length; i++) {
    if (i < period - 1) {
      sma.push(prices[i]);
    } else {
      const slice = prices.slice(i - period + 1, i + 1);
      sma.push(mean(slice));
    }
  }
  return sma;
}

// ==================== FACTOR CALCULATIONS ====================

/**
 * Momentum Factor (12-1)
 * Classic momentum: 12-month return excluding the most recent month
 * The 1-month exclusion captures mean-reversion at short horizon
 */
export function calculateMomentum(prices: number[], months: number, excludeRecent: number = 0): number {
  const tradingDaysPerMonth = 21;
  const lookback = months * tradingDaysPerMonth;
  const exclude = excludeRecent * tradingDaysPerMonth;

  if (prices.length < lookback + exclude + 5) return 0;

  const endIdx = prices.length - 1 - exclude;
  const startIdx = endIdx - lookback;

  if (startIdx < 0 || prices[startIdx] <= 0) return 0;

  return ((prices[endIdx] - prices[startIdx]) / prices[startIdx]) * 100;
}

/**
 * Value Factor
 * Distance from 52-week high as a proxy for valuation
 * Stocks further from highs are considered more "value"
 */
export function calculateValueScore(prices: number[]): number {
  if (prices.length < 252) return 50;

  const recent = prices.slice(-252);
  const high52w = Math.max(...recent);
  const current = prices[prices.length - 1];

  if (high52w === 0) return 50;

  // Distance from high: 0% (at high) to -100% (worthless)
  const distanceFromHigh = ((current - high52w) / high52w) * 100;

  // Convert to 0-100 score: further from high = higher value score
  return Math.max(0, Math.min(100, 50 - distanceFromHigh));
}

/**
 * Quality Factor
 * Measures consistency and stability of returns
 */
export function calculateQualityScore(prices: number[]): number {
  if (prices.length < 252) return 50;

  const returns = calculateReturns(prices.slice(-252));
  if (returns.length < 200) return 50;

  // 1. Win rate (positive return days)
  const positiveReturns = returns.filter(r => r > 0).length;
  const winRate = positiveReturns / returns.length;

  // 2. Consistency: rolling monthly returns consistency
  const monthlyReturns: number[] = [];
  for (let i = 21; i <= returns.length; i += 21) {
    const monthReturn = returns.slice(i - 21, i).reduce((a, b) => (1 + a) * (1 + b) - 1, 0);
    monthlyReturns.push(monthReturn);
  }

  const monthlyStd = std(monthlyReturns);
  const monthlyMean = mean(monthlyReturns);
  const consistencyRatio = monthlyMean > 0 && monthlyStd > 0 ? monthlyMean / monthlyStd : 0;

  // 3. Streak analysis: longest winning streak
  let maxStreak = 0;
  let currentStreak = 0;
  for (const r of returns) {
    if (r > 0) {
      currentStreak++;
      maxStreak = Math.max(maxStreak, currentStreak);
    } else {
      currentStreak = 0;
    }
  }

  // Combine metrics
  const winRateScore = winRate * 100;
  const consistencyScore = Math.min(100, Math.max(0, consistencyRatio * 200 + 50));
  const streakScore = Math.min(100, maxStreak * 5);

  return winRateScore * 0.4 + consistencyScore * 0.4 + streakScore * 0.2;
}

/**
 * Low Volatility Factor
 * Lower volatility stocks tend to outperform on risk-adjusted basis
 */
export function calculateLowVolScore(prices: number[]): number {
  if (prices.length < 63) return 50;

  const returns = calculateReturns(prices.slice(-63));
  const vol = std(returns) * Math.sqrt(252) * 100; // Annualized volatility

  // Invert: lower vol = higher score
  // Typical range: 15% (low vol) to 60% (high vol)
  const score = Math.max(0, Math.min(100, 100 - (vol - 15) * 2));

  return score;
}

/**
 * Trend Factor
 * Multiple timeframe moving average analysis
 */
export function calculateTrendScore(prices: number[]): number {
  if (prices.length < 200) return 50;

  const current = prices[prices.length - 1];
  const sma20 = simpleMovingAverage(prices, 20);
  const sma50 = simpleMovingAverage(prices, 50);
  const sma200 = simpleMovingAverage(prices, 200);
  const ema12 = exponentialMovingAverage(prices, 12);
  const ema26 = exponentialMovingAverage(prices, 26);

  const sma20Current = sma20[sma20.length - 1];
  const sma50Current = sma50[sma50.length - 1];
  const sma200Current = sma200[sma200.length - 1];
  const ema12Current = ema12[ema12.length - 1];
  const ema26Current = ema26[ema26.length - 1];

  let score = 50;

  // Price above/below MAs
  if (current > sma20Current) score += 10;
  if (current > sma50Current) score += 10;
  if (current > sma200Current) score += 15;

  // MA alignment (golden cross structure)
  if (sma20Current > sma50Current) score += 10;
  if (sma50Current > sma200Current) score += 15;

  // MACD (EMA12 - EMA26)
  const macd = ema12Current - ema26Current;
  const macdPercent = (macd / current) * 100;
  if (macdPercent > 0) score += Math.min(15, macdPercent * 10);
  if (macdPercent < 0) score -= Math.min(15, Math.abs(macdPercent) * 10);

  // Trend slope (20-day MA slope)
  const sma20Prev = sma20[sma20.length - 21] || sma20Current;
  const slope = ((sma20Current - sma20Prev) / sma20Prev) * 100;
  score += Math.max(-15, Math.min(15, slope * 5));

  return Math.max(0, Math.min(100, score));
}

/**
 * Relative Strength vs Market
 */
export function calculateRelativeStrength(
  stockPrices: number[],
  marketPrices: number[],
  period: number = 63
): number {
  if (stockPrices.length < period || marketPrices.length < period) return 0;

  const stockStart = stockPrices[stockPrices.length - period];
  const stockEnd = stockPrices[stockPrices.length - 1];
  const marketStart = marketPrices[marketPrices.length - period];
  const marketEnd = marketPrices[marketPrices.length - 1];

  if (stockStart <= 0 || marketStart <= 0) return 0;

  const stockReturn = (stockEnd - stockStart) / stockStart;
  const marketReturn = (marketEnd - marketStart) / marketStart;

  return (stockReturn - marketReturn) * 100;
}

/**
 * Calculate Beta
 */
export function calculateBeta(stockReturns: number[], marketReturns: number[]): number {
  const n = Math.min(stockReturns.length, marketReturns.length, 252);
  if (n < 60) return 1;

  const sReturns = stockReturns.slice(-n);
  const mReturns = marketReturns.slice(-n);

  const stockMean = mean(sReturns);
  const marketMean = mean(mReturns);

  let covariance = 0;
  let marketVariance = 0;

  for (let i = 0; i < n; i++) {
    covariance += (sReturns[i] - stockMean) * (mReturns[i] - marketMean);
    marketVariance += Math.pow(mReturns[i] - marketMean, 2);
  }

  return marketVariance > 0 ? covariance / marketVariance : 1;
}

/**
 * Calculate Max Drawdown
 */
export function calculateMaxDrawdown(prices: number[]): number {
  if (prices.length < 2) return 0;

  let maxDrawdown = 0;
  let peak = prices[0];

  for (const price of prices) {
    if (price > peak) peak = price;
    const drawdown = (peak - price) / peak;
    maxDrawdown = Math.max(maxDrawdown, drawdown);
  }

  return maxDrawdown * 100;
}

/**
 * Calculate Sharpe Ratio
 */
export function calculateSharpeRatio(returns: number[], riskFreeRate: number = 0.04): number {
  if (returns.length < 21) return 0;

  const avgReturn = mean(returns) * 252; // Annualized
  const volatility = std(returns) * Math.sqrt(252);

  if (volatility === 0) return 0;
  return (avgReturn - riskFreeRate) / volatility;
}

// ==================== REGIME DETECTION ====================

export interface MarketRegime {
  type: 'BULL' | 'BEAR' | 'NEUTRAL' | 'VOLATILE';
  score: number;
  volatilityRegime: 'LOW' | 'NORMAL' | 'HIGH';
  trendStrength: number;
}

export function detectMarketRegime(marketPrices: number[]): MarketRegime {
  if (marketPrices.length < 200) {
    return { type: 'NEUTRAL', score: 50, volatilityRegime: 'NORMAL', trendStrength: 0 };
  }

  const current = marketPrices[marketPrices.length - 1];
  const sma50 = simpleMovingAverage(marketPrices, 50);
  const sma200 = simpleMovingAverage(marketPrices, 200);

  const sma50Current = sma50[sma50.length - 1];
  const sma200Current = sma200[sma200.length - 1];

  // Volatility regime
  const returns = calculateReturns(marketPrices.slice(-63));
  const currentVol = std(returns) * Math.sqrt(252) * 100;

  const historicalReturns = calculateReturns(marketPrices.slice(-252));
  const historicalVol = std(historicalReturns) * Math.sqrt(252) * 100;

  let volatilityRegime: 'LOW' | 'NORMAL' | 'HIGH' = 'NORMAL';
  if (currentVol < historicalVol * 0.7) volatilityRegime = 'LOW';
  if (currentVol > historicalVol * 1.3) volatilityRegime = 'HIGH';

  // Trend regime
  const aboveSma50 = current > sma50Current;
  const aboveSma200 = current > sma200Current;
  const goldenCross = sma50Current > sma200Current;

  let trendStrength = 0;
  if (aboveSma50) trendStrength += 25;
  if (aboveSma200) trendStrength += 25;
  if (goldenCross) trendStrength += 25;

  // 3-month return
  const ret3m = marketPrices.length >= 63
    ? (current - marketPrices[marketPrices.length - 63]) / marketPrices[marketPrices.length - 63] * 100
    : 0;

  if (ret3m > 5) trendStrength += 25;
  else if (ret3m < -5) trendStrength -= 25;

  let type: 'BULL' | 'BEAR' | 'NEUTRAL' | 'VOLATILE' = 'NEUTRAL';
  let score = 50;

  if (volatilityRegime === 'HIGH' && trendStrength < 50) {
    type = 'VOLATILE';
    score = 30;
  } else if (trendStrength >= 75) {
    type = 'BULL';
    score = 80;
  } else if (trendStrength <= 25) {
    type = 'BEAR';
    score = 20;
  }

  return { type, score, volatilityRegime, trendStrength };
}

// ==================== FACTOR WEIGHTING BY REGIME ====================

interface FactorWeights {
  momentum: number;
  value: number;
  quality: number;
  lowVol: number;
  trend: number;
}

export function getFactorWeights(regime: MarketRegime): FactorWeights {
  // Regime-adaptive factor weights based on empirical research
  switch (regime.type) {
    case 'BULL':
      return {
        momentum: 0.35,  // Momentum works best in bull markets
        value: 0.10,
        quality: 0.20,
        lowVol: 0.10,
        trend: 0.25,
      };
    case 'BEAR':
      return {
        momentum: 0.10,  // Momentum fails in bear markets
        value: 0.30,     // Value outperforms in bear markets
        quality: 0.30,   // Quality is defensive
        lowVol: 0.20,    // Low vol is defensive
        trend: 0.10,
      };
    case 'VOLATILE':
      return {
        momentum: 0.15,
        value: 0.20,
        quality: 0.30,   // Quality most important in volatility
        lowVol: 0.25,
        trend: 0.10,
      };
    default: // NEUTRAL
      return {
        momentum: 0.25,
        value: 0.20,
        quality: 0.25,
        lowVol: 0.15,
        trend: 0.15,
      };
  }
}

// ==================== COMPOSITE ALPHA SCORE ====================

export function calculateAlphaScore(
  factors: FactorScores,
  weights: FactorWeights,
  regime: MarketRegime
): number {
  // Convert factor z-scores to 0-100 scale
  const normalize = (z: number) => Math.max(0, Math.min(100, 50 + z * 16.67));

  // Momentum composite (12-1 momentum is the core)
  const momentumRaw = factors.momentum12m * 0.6 + factors.momentum6m * 0.3 - factors.momentum1m * 0.1;
  const momentumScore = normalize(momentumRaw);

  // Quality-Value composite
  const qualityValueScore = (factors.qualityScore + factors.valueScore) / 2;

  // Risk-adjusted composite
  const riskAdjustedScore = (factors.lowVolScore + factors.qualityScore) / 2;

  // Trend following score
  const trendScoreNorm = normalize(factors.trendScore / 50 - 1);

  // Relative strength bonus
  const rsBonus = factors.relStrength > 5 ? 5 : (factors.relStrength < -5 ? -5 : 0);

  // Weighted composite
  const composite =
    momentumScore * weights.momentum +
    factors.valueScore * weights.value +
    factors.qualityScore * weights.quality +
    factors.lowVolScore * weights.lowVol +
    trendScoreNorm * weights.trend;

  // Apply regime adjustment
  const regimeMultiplier = 0.8 + (regime.score / 250); // 0.8 to 1.2

  // Final score with RS bonus
  const finalScore = Math.max(0, Math.min(100, composite * regimeMultiplier + rsBonus));

  return finalScore;
}

export function getSignal(
  alphaScore: number,
  trendScore: number,
  qualityScore: number
): 'STRONG_BUY' | 'BUY' | 'HOLD' | 'AVOID' {
  if (alphaScore >= 70 && trendScore >= 60 && qualityScore >= 50) return 'STRONG_BUY';
  if (alphaScore >= 55 && (trendScore >= 50 || qualityScore >= 60)) return 'BUY';
  if (alphaScore >= 40) return 'HOLD';
  return 'AVOID';
}

export function calculateExpectedReturn(
  factors: FactorScores,
  regime: MarketRegime
): number {
  // Base expected return from factor exposures
  const momentumContribution = factors.momentum12m * 0.15;
  const trendContribution = (factors.trendScore - 50) * 0.1;
  const rsContribution = factors.relStrength * 0.2;

  // Quality adjustment (higher quality = more reliable estimate)
  const qualityMultiplier = 0.5 + (factors.qualityScore / 200);

  // Regime adjustment
  const regimeAdj = regime.type === 'BULL' ? 1.2 : (regime.type === 'BEAR' ? 0.6 : 1.0);

  const rawExpected = (momentumContribution + trendContribution + rsContribution) * qualityMultiplier * regimeAdj;

  // Cap at reasonable range
  return Math.max(-20, Math.min(30, rawExpected));
}

export function calculateConviction(
  alphaScore: number,
  factors: FactorScores,
  regime: MarketRegime
): number {
  // Conviction based on signal strength and regime alignment
  const scoreStrength = Math.abs(alphaScore - 50) / 50;
  const factorAlignment = calculateFactorAlignment(factors);
  const regimeConfidence = regime.score / 100;

  return Math.min(100, (scoreStrength * 40 + factorAlignment * 40 + regimeConfidence * 20));
}

function calculateFactorAlignment(factors: FactorScores): number {
  // How many factors agree?
  let positive = 0;
  let negative = 0;

  if (factors.momentum12m > 0.5) positive++; else if (factors.momentum12m < -0.5) negative++;
  if (factors.valueScore > 55) positive++; else if (factors.valueScore < 45) negative++;
  if (factors.qualityScore > 55) positive++; else if (factors.qualityScore < 45) negative++;
  if (factors.trendScore > 55) positive++; else if (factors.trendScore < 45) negative++;
  if (factors.relStrength > 2) positive++; else if (factors.relStrength < -2) negative++;

  const total = 5;
  const maxAgreement = Math.max(positive, negative);

  return (maxAgreement / total) * 100;
}
