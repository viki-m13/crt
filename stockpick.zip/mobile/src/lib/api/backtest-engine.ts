/**
 * Backtesting Engine for Stock Prediction Model
 *
 * Validates prediction accuracy by testing historical predictions against actual outcomes.
 * Tests predictions made at various points in time to ensure robustness.
 */

import {
  StockData,
  PREDICTION_UNIVERSE,
  STOCK_INFO,
  calculatePredictionFactors,
  calculateProbabilities,
  calculateCompositeScore,
  determineSignal,
  fetchAllStocksData,
  BacktestPeriod,
  BacktestSummary,
} from './prediction-model';

// ==================== BACKTEST CONFIGURATION ====================

const BACKTEST_CONFIG = {
  // Number of top picks to track
  topN: 5,
  // Minimum data required
  minDataPoints: 252 * 2,  // 2 years minimum
  // Signal frequency (monthly)
  signalIntervalDays: 21,
};

// ==================== BACKTESTING FUNCTIONS ====================

/**
 * Find index of date in data array (or closest date before)
 */
function findDateIndex(data: StockData[], targetDate: string): number {
  for (let i = data.length - 1; i >= 0; i--) {
    if (data[i].date <= targetDate) {
      return i;
    }
  }
  return -1;
}

/**
 * Get date N trading days/years from a given index
 */
function getDateOffset(
  data: StockData[],
  fromIndex: number,
  years: number
): { index: number; date: string } | null {
  const targetDays = Math.round(years * 252);
  const targetIndex = fromIndex + targetDays;

  if (targetIndex >= data.length) return null;

  return {
    index: targetIndex,
    date: data[targetIndex].date,
  };
}

/**
 * Calculate factors for a stock at a specific point in time
 */
function calculateHistoricalFactors(
  stockData: StockData[],
  asOfIndex: number
): ReturnType<typeof calculatePredictionFactors> | null {
  if (asOfIndex < 252) return null;

  const historicalData = stockData.slice(0, asOfIndex + 1);
  const prices = historicalData.map(d => d.adjClose);
  const highs = historicalData.map(d => d.high);
  const lows = historicalData.map(d => d.low);
  const volumes = historicalData.map(d => d.volume);

  return calculatePredictionFactors(prices, highs, lows, volumes);
}

/**
 * Calculate return from one index to another
 */
function calculateReturn(data: StockData[], fromIndex: number, toIndex: number): number {
  if (fromIndex < 0 || toIndex < 0 || toIndex >= data.length || fromIndex >= data.length) {
    return 0;
  }
  const startPrice = data[fromIndex].adjClose;
  const endPrice = data[toIndex].adjClose;
  return startPrice > 0 ? ((endPrice - startPrice) / startPrice) * 100 : 0;
}

/**
 * Run backtest for a single signal date
 */
function runSinglePeriodBacktest(
  dataMap: Map<string, StockData[]>,
  signalDateIndex: number,
  signalDate: string,
  spyData: StockData[]
): BacktestPeriod | null {
  // Calculate scores for all stocks at signal date
  const stockScores: Array<{
    symbol: string;
    score: number;
    signal: string;
  }> = [];

  for (const symbol of PREDICTION_UNIVERSE) {
    const stockData = dataMap.get(symbol);
    if (!stockData) continue;

    const stockSignalIdx = findDateIndex(stockData, signalDate);
    if (stockSignalIdx < 252) continue;

    const factors = calculateHistoricalFactors(stockData, stockSignalIdx);
    if (!factors) continue;

    const prob = calculateProbabilities(factors);
    const score = calculateCompositeScore(factors, prob);
    const { signal } = determineSignal(score, factors, prob);

    stockScores.push({ symbol, score, signal });
  }

  if (stockScores.length < BACKTEST_CONFIG.topN) return null;

  // Sort by score and get top picks
  stockScores.sort((a, b) => b.score - a.score);
  const topPicks = stockScores.slice(0, BACKTEST_CONFIG.topN).map(s => s.symbol);

  // Get evaluation dates
  const eval1Y = getDateOffset(spyData, signalDateIndex, 1);
  const eval3Y = getDateOffset(spyData, signalDateIndex, 3);
  const eval5Y = getDateOffset(spyData, signalDateIndex, 5);

  // Calculate returns for each time horizon
  const actualReturns1Y: number[] = [];
  const actualReturns3Y: number[] = [];
  const actualReturns5Y: number[] = [];

  for (const symbol of topPicks) {
    const stockData = dataMap.get(symbol);
    if (!stockData) continue;

    const stockSignalIdx = findDateIndex(stockData, signalDate);

    // 1-Year returns
    if (eval1Y) {
      const stock1YIdx = findDateIndex(stockData, eval1Y.date);
      if (stock1YIdx > stockSignalIdx) {
        actualReturns1Y.push(calculateReturn(stockData, stockSignalIdx, stock1YIdx));
      }
    }

    // 3-Year returns
    if (eval3Y) {
      const stock3YIdx = findDateIndex(stockData, eval3Y.date);
      if (stock3YIdx > stockSignalIdx) {
        actualReturns3Y.push(calculateReturn(stockData, stockSignalIdx, stock3YIdx));
      }
    }

    // 5-Year returns
    if (eval5Y) {
      const stock5YIdx = findDateIndex(stockData, eval5Y.date);
      if (stock5YIdx > stockSignalIdx) {
        actualReturns5Y.push(calculateReturn(stockData, stockSignalIdx, stock5YIdx));
      }
    }
  }

  // Calculate SPY returns
  const spyReturn1Y = eval1Y ? calculateReturn(spyData, signalDateIndex, eval1Y.index) : 0;
  const spyReturn3Y = eval3Y ? calculateReturn(spyData, signalDateIndex, eval3Y.index) : 0;
  const spyReturn5Y = eval5Y ? calculateReturn(spyData, signalDateIndex, eval5Y.index) : 0;

  // Calculate hit rates (% of picks that went up)
  const hitRate1Y = actualReturns1Y.length > 0
    ? (actualReturns1Y.filter(r => r > 0).length / actualReturns1Y.length) * 100
    : 0;
  const hitRate3Y = actualReturns3Y.length > 0
    ? (actualReturns3Y.filter(r => r > 0).length / actualReturns3Y.length) * 100
    : 0;
  const hitRate5Y = actualReturns5Y.length > 0
    ? (actualReturns5Y.filter(r => r > 0).length / actualReturns5Y.length) * 100
    : 0;

  // Calculate beat market rates
  const beatMarket1Y = actualReturns1Y.length > 0
    ? (actualReturns1Y.filter(r => r > spyReturn1Y).length / actualReturns1Y.length) * 100
    : 0;
  const beatMarket3Y = actualReturns3Y.length > 0
    ? (actualReturns3Y.filter(r => r > spyReturn3Y).length / actualReturns3Y.length) * 100
    : 0;
  const beatMarket5Y = actualReturns5Y.length > 0
    ? (actualReturns5Y.filter(r => r > spyReturn5Y).length / actualReturns5Y.length) * 100
    : 0;

  return {
    signalDate,
    evaluationDate1Y: eval1Y?.date || '',
    evaluationDate3Y: eval3Y?.date || '',
    evaluationDate5Y: eval5Y?.date || '',
    topPicks,
    actualReturns1Y,
    actualReturns3Y,
    actualReturns5Y,
    spyReturn1Y,
    spyReturn3Y,
    spyReturn5Y,
    hitRate1Y,
    hitRate3Y,
    hitRate5Y,
    beatMarket1Y,
    beatMarket3Y,
    beatMarket5Y,
  };
}

/**
 * Run comprehensive backtest across multiple periods
 */
export async function runComprehensiveBacktest(): Promise<{
  periods: BacktestPeriod[];
  summary: BacktestSummary;
}> {
  // Fetch extended historical data (10 years if available)
  const allSymbols = [...PREDICTION_UNIVERSE, 'SPY'];
  const dataMap = await fetchAllStocksData(allSymbols, '10y');

  const spyData = dataMap.get('SPY');
  if (!spyData || spyData.length < BACKTEST_CONFIG.minDataPoints) {
    throw new Error('Insufficient SPY data for backtesting');
  }

  const periods: BacktestPeriod[] = [];

  // Get signal dates (quarterly for comprehensive test)
  const signalIntervalDays = 63;  // Quarterly
  const startIndex = 252 * 2;  // Start after 2 years of data
  const endIndex = spyData.length - 252;  // End 1 year before present (for 1Y evaluation)

  for (let i = startIndex; i < endIndex; i += signalIntervalDays) {
    const signalDate = spyData[i].date;

    const periodResult = runSinglePeriodBacktest(dataMap, i, signalDate, spyData);

    if (periodResult) {
      periods.push(periodResult);
    }
  }

  // Calculate summary statistics
  const summary = calculateBacktestSummary(periods);

  return { periods, summary };
}

/**
 * Calculate summary statistics from backtest periods
 */
function calculateBacktestSummary(periods: BacktestPeriod[]): BacktestSummary {
  if (periods.length === 0) {
    return {
      avgHitRate1Y: 0,
      avgHitRate3Y: 0,
      avgHitRate5Y: 0,
      avgBeatMarket1Y: 0,
      avgBeatMarket3Y: 0,
      avgBeatMarket5Y: 0,
      avgReturn1Y: 0,
      avgReturn3Y: 0,
      avgReturn5Y: 0,
      avgSpyReturn1Y: 0,
      avgSpyReturn3Y: 0,
      avgSpyReturn5Y: 0,
      alpha1Y: 0,
      alpha3Y: 0,
      alpha5Y: 0,
      winRate: 0,
      sharpeRatio: 0,
      maxDrawdown: 0,
      totalPeriods: 0,
    };
  }

  // Filter periods with valid data for each horizon
  const periods1Y = periods.filter(p => p.actualReturns1Y.length > 0);
  const periods3Y = periods.filter(p => p.actualReturns3Y.length > 0);
  const periods5Y = periods.filter(p => p.actualReturns5Y.length > 0);

  // Helper function for averaging
  const avg = (arr: number[]) => arr.length > 0 ? arr.reduce((a, b) => a + b, 0) / arr.length : 0;

  // Hit rates
  const avgHitRate1Y = avg(periods1Y.map(p => p.hitRate1Y));
  const avgHitRate3Y = avg(periods3Y.map(p => p.hitRate3Y));
  const avgHitRate5Y = avg(periods5Y.map(p => p.hitRate5Y));

  // Beat market rates
  const avgBeatMarket1Y = avg(periods1Y.map(p => p.beatMarket1Y));
  const avgBeatMarket3Y = avg(periods3Y.map(p => p.beatMarket3Y));
  const avgBeatMarket5Y = avg(periods5Y.map(p => p.beatMarket5Y));

  // Average returns (of picks)
  const avgReturn1Y = avg(periods1Y.flatMap(p => p.actualReturns1Y));
  const avgReturn3Y = avg(periods3Y.flatMap(p => p.actualReturns3Y));
  const avgReturn5Y = avg(periods5Y.flatMap(p => p.actualReturns5Y));

  // Average SPY returns
  const avgSpyReturn1Y = avg(periods1Y.map(p => p.spyReturn1Y));
  const avgSpyReturn3Y = avg(periods3Y.map(p => p.spyReturn3Y));
  const avgSpyReturn5Y = avg(periods5Y.map(p => p.spyReturn5Y));

  // Alpha (outperformance)
  const alpha1Y = avgReturn1Y - avgSpyReturn1Y;
  const alpha3Y = avgReturn3Y - avgSpyReturn3Y;
  const alpha5Y = avgReturn5Y - avgSpyReturn5Y;

  // Overall win rate (picks that beat SPY)
  const allBeatMarket = [
    ...periods1Y.map(p => p.beatMarket1Y),
    ...periods3Y.map(p => p.beatMarket3Y),
    ...periods5Y.map(p => p.beatMarket5Y),
  ];
  const winRate = avg(allBeatMarket);

  // Calculate Sharpe-like ratio using 1Y returns
  const returns1Y = periods1Y.flatMap(p => p.actualReturns1Y);
  const spyReturns1Y = periods1Y.map(p => p.spyReturn1Y);
  const excessReturns = periods1Y.flatMap((p, idx) =>
    p.actualReturns1Y.map(r => r - spyReturns1Y[idx])
  );

  const stdDev = excessReturns.length > 1
    ? Math.sqrt(excessReturns.map(r => Math.pow(r - avg(excessReturns), 2)).reduce((a, b) => a + b, 0) / excessReturns.length)
    : 1;

  const sharpeRatio = stdDev > 0 ? avg(excessReturns) / stdDev : 0;

  // Max drawdown (from cumulative returns)
  let cumReturn = 0;
  let peak = 0;
  let maxDrawdown = 0;

  for (const period of periods1Y) {
    const periodReturn = avg(period.actualReturns1Y) / 100;
    cumReturn = (1 + cumReturn) * (1 + periodReturn) - 1;
    if (cumReturn > peak) peak = cumReturn;
    const dd = peak - cumReturn;
    if (dd > maxDrawdown) maxDrawdown = dd;
  }

  return {
    avgHitRate1Y: Math.round(avgHitRate1Y * 10) / 10,
    avgHitRate3Y: Math.round(avgHitRate3Y * 10) / 10,
    avgHitRate5Y: Math.round(avgHitRate5Y * 10) / 10,
    avgBeatMarket1Y: Math.round(avgBeatMarket1Y * 10) / 10,
    avgBeatMarket3Y: Math.round(avgBeatMarket3Y * 10) / 10,
    avgBeatMarket5Y: Math.round(avgBeatMarket5Y * 10) / 10,
    avgReturn1Y: Math.round(avgReturn1Y * 10) / 10,
    avgReturn3Y: Math.round(avgReturn3Y * 10) / 10,
    avgReturn5Y: Math.round(avgReturn5Y * 10) / 10,
    avgSpyReturn1Y: Math.round(avgSpyReturn1Y * 10) / 10,
    avgSpyReturn3Y: Math.round(avgSpyReturn3Y * 10) / 10,
    avgSpyReturn5Y: Math.round(avgSpyReturn5Y * 10) / 10,
    alpha1Y: Math.round(alpha1Y * 10) / 10,
    alpha3Y: Math.round(alpha3Y * 10) / 10,
    alpha5Y: Math.round(alpha5Y * 10) / 10,
    winRate: Math.round(winRate * 10) / 10,
    sharpeRatio: Math.round(sharpeRatio * 100) / 100,
    maxDrawdown: Math.round(maxDrawdown * 100 * 10) / 10,
    totalPeriods: periods.length,
  };
}

/**
 * Quick backtest for validation (1-year horizon only, recent periods)
 */
export async function runQuickBacktest(): Promise<{
  periods: BacktestPeriod[];
  summary: BacktestSummary;
}> {
  const allSymbols = [...PREDICTION_UNIVERSE, 'SPY'];
  const dataMap = await fetchAllStocksData(allSymbols, '5y');

  const spyData = dataMap.get('SPY');
  if (!spyData || spyData.length < 252 * 3) {
    throw new Error('Insufficient data for backtesting');
  }

  const periods: BacktestPeriod[] = [];

  // Monthly signals for last 2 years (with 1-year forward evaluation)
  const signalIntervalDays = 21;
  const startIndex = 252;  // Start after 1 year of data
  const endIndex = spyData.length - 252;  // End 1 year before present

  for (let i = startIndex; i < endIndex; i += signalIntervalDays) {
    const signalDate = spyData[i].date;
    const periodResult = runSinglePeriodBacktest(dataMap, i, signalDate, spyData);
    if (periodResult) {
      periods.push(periodResult);
    }
  }

  const summary = calculateBacktestSummary(periods);

  return { periods, summary };
}

// ==================== REACT QUERY HOOKS ====================

import { useQuery } from '@tanstack/react-query';
import { getStockPredictions, getTopPredictions, StockPrediction } from './prediction-model';

export function usePredictions() {
  return useQuery<StockPrediction[], Error>({
    queryKey: ['predictions'],
    queryFn: getStockPredictions,
    staleTime: 1000 * 60 * 30, // 30 minutes
    gcTime: 1000 * 60 * 60 * 2, // 2 hours
  });
}

export function useTopPredictions(n: number = 5) {
  return useQuery<StockPrediction[], Error>({
    queryKey: ['topPredictions', n],
    queryFn: () => getTopPredictions(n),
    staleTime: 1000 * 60 * 30,
    gcTime: 1000 * 60 * 60 * 2,
  });
}

export function useBacktest() {
  return useQuery<{ periods: BacktestPeriod[]; summary: BacktestSummary }, Error>({
    queryKey: ['backtest'],
    queryFn: runQuickBacktest,
    staleTime: 1000 * 60 * 60, // 1 hour
    gcTime: 1000 * 60 * 60 * 24, // 24 hours
  });
}

export function useComprehensiveBacktest() {
  return useQuery<{ periods: BacktestPeriod[]; summary: BacktestSummary }, Error>({
    queryKey: ['comprehensiveBacktest'],
    queryFn: runComprehensiveBacktest,
    staleTime: 1000 * 60 * 60 * 24, // 24 hours
    gcTime: 1000 * 60 * 60 * 24 * 7, // 7 days
  });
}
