/**
 * DCA (Dollar Cost Averaging) Comparison Engine
 *
 * Compares monthly DCA investing across different assets
 * Shows which assets would have given best returns with regular monthly investments
 */

export interface DCAAsset {
  symbol: string;
  name: string;
  type: 'etf' | 'stock' | 'crypto';
  description: string;
}

// Assets to compare DCA performance
export const DCA_ASSETS: DCAAsset[] = [
  { symbol: 'SPY', name: 'S&P 500 ETF', type: 'etf', description: 'Tracks the S&P 500 index' },
  { symbol: 'QQQ', name: 'Nasdaq 100 ETF', type: 'etf', description: 'Tech-heavy index fund' },
  { symbol: 'VTI', name: 'Total Stock Market', type: 'etf', description: 'Entire US stock market' },
  { symbol: 'AAPL', name: 'Apple Inc.', type: 'stock', description: 'Consumer electronics & services' },
  { symbol: 'MSFT', name: 'Microsoft Corp.', type: 'stock', description: 'Software & cloud computing' },
  { symbol: 'GOOGL', name: 'Alphabet Inc.', type: 'stock', description: 'Search & advertising' },
  { symbol: 'AMZN', name: 'Amazon.com', type: 'stock', description: 'E-commerce & cloud' },
  { symbol: 'NVDA', name: 'NVIDIA Corp.', type: 'stock', description: 'AI & graphics chips' },
  { symbol: 'META', name: 'Meta Platforms', type: 'stock', description: 'Social media & VR' },
  { symbol: 'TSLA', name: 'Tesla Inc.', type: 'stock', description: 'Electric vehicles' },
  { symbol: 'VOO', name: 'Vanguard S&P 500', type: 'etf', description: 'Low-cost S&P 500 fund' },
  { symbol: 'IVV', name: 'iShares S&P 500', type: 'etf', description: 'S&P 500 tracker' },
  { symbol: 'BRK-B', name: 'Berkshire Hathaway', type: 'stock', description: "Warren Buffett's company" },
  { symbol: 'JPM', name: 'JPMorgan Chase', type: 'stock', description: 'Largest US bank' },
  { symbol: 'V', name: 'Visa Inc.', type: 'stock', description: 'Payment processing' },
  { symbol: 'LLY', name: 'Eli Lilly', type: 'stock', description: 'Pharmaceuticals' },
  { symbol: 'AVGO', name: 'Broadcom Inc.', type: 'stock', description: 'Semiconductors' },
  { symbol: 'COST', name: 'Costco', type: 'stock', description: 'Warehouse retail' },
  { symbol: 'HD', name: 'Home Depot', type: 'stock', description: 'Home improvement' },
  { symbol: 'UNH', name: 'UnitedHealth', type: 'stock', description: 'Healthcare' },
];

export const DCA_ASSET_MAP: Record<string, DCAAsset> = Object.fromEntries(
  DCA_ASSETS.map(a => [a.symbol, a])
);

export interface DCAResult {
  symbol: string;
  name: string;
  type: 'etf' | 'stock' | 'crypto';

  // Investment details
  totalInvested: number;
  currentValue: number;
  totalShares: number;
  avgCostBasis: number;
  currentPrice: number;

  // Returns
  totalReturn: number;        // Total return %
  totalGainLoss: number;      // Dollar gain/loss
  annualizedReturn: number;   // CAGR

  // vs S&P 500
  sp500TotalReturn: number;
  sp500Value: number;
  outperformance: number;     // % better than SPY DCA

  // Risk metrics
  maxDrawdown: number;
  volatility: number;

  // Monthly breakdown
  monthlyData: DCAMonthlyData[];
}

export interface DCAMonthlyData {
  date: string;
  price: number;
  sharesPurchased: number;
  totalShares: number;
  totalInvested: number;
  portfolioValue: number;
  returnPercent: number;
}

export interface DCAComparisonSummary {
  monthlyAmount: number;
  totalMonths: number;
  startDate: string;
  endDate: string;
  totalInvested: number;

  // Best performers
  bestPerformer: {
    symbol: string;
    name: string;
    totalReturn: number;
    currentValue: number;
  };

  // S&P 500 benchmark
  sp500Result: {
    totalReturn: number;
    currentValue: number;
    annualizedReturn: number;
  };

  // Winners vs SPY
  beatingMarket: number;
  losingToMarket: number;
}

// Yahoo Finance API
const YAHOO_CHART_API = 'https://query1.finance.yahoo.com/v8/finance/chart';

interface PriceData {
  date: string;
  price: number;
}

/**
 * Fetch historical price data from Yahoo Finance
 */
export async function fetchPriceHistory(
  symbol: string,
  period: '1y' | '2y' | '5y' = '2y'
): Promise<PriceData[]> {
  try {
    const url = `${YAHOO_CHART_API}/${symbol}?interval=1d&range=${period}`;

    const response = await fetch(url, {
      headers: { 'User-Agent': 'Mozilla/5.0' },
    });

    if (!response.ok) {
      throw new Error(`HTTP error: ${response.status}`);
    }

    const data = await response.json();

    if (data.chart.error || !data.chart.result?.[0]) {
      throw new Error(`Yahoo API error: ${data.chart.error?.description || 'No data'}`);
    }

    const result = data.chart.result[0];
    const timestamps = result.timestamp || [];
    const quotes = result.indicators.quote[0];
    const adjClose = result.indicators.adjclose?.[0]?.adjclose || quotes.close;

    const prices: PriceData[] = [];

    for (let i = 0; i < timestamps.length; i++) {
      if (adjClose[i] != null && adjClose[i] > 0) {
        prices.push({
          date: new Date(timestamps[i] * 1000).toISOString().split('T')[0],
          price: adjClose[i],
        });
      }
    }

    return prices;
  } catch (error) {
    console.error(`Error fetching ${symbol}:`, error);
    return [];
  }
}

/**
 * Get monthly prices (first trading day of each month)
 */
function getMonthlyPrices(dailyPrices: PriceData[]): PriceData[] {
  const monthlyPrices: PriceData[] = [];
  let currentMonth = '';

  for (const price of dailyPrices) {
    const month = price.date.substring(0, 7);
    if (month !== currentMonth) {
      monthlyPrices.push(price);
      currentMonth = month;
    }
  }

  return monthlyPrices;
}

/**
 * Calculate DCA results for a single asset
 */
export function calculateDCA(
  monthlyPrices: PriceData[],
  monthlyAmount: number,
  asset: DCAAsset
): DCAResult | null {
  if (monthlyPrices.length < 2) return null;

  let totalShares = 0;
  let totalInvested = 0;
  const monthlyData: DCAMonthlyData[] = [];
  let peakValue = 0;
  let maxDrawdown = 0;
  const returns: number[] = [];

  for (let i = 0; i < monthlyPrices.length; i++) {
    const { date, price } = monthlyPrices[i];

    // Buy shares with monthly amount
    const sharesPurchased = monthlyAmount / price;
    totalShares += sharesPurchased;
    totalInvested += monthlyAmount;

    // Calculate current portfolio value
    const portfolioValue = totalShares * price;
    const returnPercent = totalInvested > 0
      ? ((portfolioValue - totalInvested) / totalInvested) * 100
      : 0;

    // Track drawdown
    if (portfolioValue > peakValue) {
      peakValue = portfolioValue;
    }
    const currentDrawdown = peakValue > 0
      ? ((peakValue - portfolioValue) / peakValue) * 100
      : 0;
    maxDrawdown = Math.max(maxDrawdown, currentDrawdown);

    // Track monthly returns for volatility
    if (i > 0) {
      const prevValue = monthlyData[i - 1].portfolioValue;
      const monthlyReturn = prevValue > 0
        ? (portfolioValue - prevValue - monthlyAmount) / prevValue
        : 0;
      returns.push(monthlyReturn);
    }

    monthlyData.push({
      date,
      price,
      sharesPurchased,
      totalShares,
      totalInvested,
      portfolioValue,
      returnPercent,
    });
  }

  const currentPrice = monthlyPrices[monthlyPrices.length - 1].price;
  const currentValue = totalShares * currentPrice;
  const totalReturn = ((currentValue - totalInvested) / totalInvested) * 100;
  const totalGainLoss = currentValue - totalInvested;
  const avgCostBasis = totalInvested / totalShares;

  // Annualized return (CAGR approximation for DCA)
  const years = monthlyPrices.length / 12;
  const annualizedReturn = years > 0
    ? (Math.pow(currentValue / totalInvested, 1 / years) - 1) * 100
    : 0;

  // Volatility (annualized std dev of monthly returns)
  const volatility = returns.length > 1
    ? standardDeviation(returns) * Math.sqrt(12) * 100
    : 0;

  return {
    symbol: asset.symbol,
    name: asset.name,
    type: asset.type,
    totalInvested,
    currentValue,
    totalShares,
    avgCostBasis,
    currentPrice,
    totalReturn,
    totalGainLoss,
    annualizedReturn,
    sp500TotalReturn: 0, // Will be filled in later
    sp500Value: 0,
    outperformance: 0,
    maxDrawdown,
    volatility,
    monthlyData,
  };
}

function standardDeviation(arr: number[]): number {
  if (arr.length < 2) return 0;
  const avg = arr.reduce((a, b) => a + b, 0) / arr.length;
  const variance = arr.map(x => Math.pow(x - avg, 2)).reduce((a, b) => a + b, 0) / arr.length;
  return Math.sqrt(variance);
}

/**
 * Fetch and calculate DCA comparison for all assets
 */
export async function runDCAComparison(
  monthlyAmount: number = 500,
  period: '1y' | '2y' | '5y' = '2y'
): Promise<{
  results: DCAResult[];
  summary: DCAComparisonSummary;
}> {
  // Fetch all price data
  const symbols = DCA_ASSETS.map(a => a.symbol);
  const priceDataMap: Map<string, PriceData[]> = new Map();

  // Fetch in batches
  const batchSize = 5;
  for (let i = 0; i < symbols.length; i += batchSize) {
    const batch = symbols.slice(i, i + batchSize);
    const results = await Promise.all(
      batch.map(symbol => fetchPriceHistory(symbol, period))
    );

    batch.forEach((symbol, idx) => {
      if (results[idx].length > 0) {
        priceDataMap.set(symbol, results[idx]);
      }
    });

    // Rate limiting
    if (i + batchSize < symbols.length) {
      await new Promise(resolve => setTimeout(resolve, 300));
    }
  }

  // Calculate SPY benchmark first
  const spyPrices = priceDataMap.get('SPY');
  if (!spyPrices || spyPrices.length < 2) {
    throw new Error('Failed to fetch S&P 500 data');
  }

  const spyMonthly = getMonthlyPrices(spyPrices);
  const spyAsset = DCA_ASSET_MAP['SPY'];
  const spyResult = calculateDCA(spyMonthly, monthlyAmount, spyAsset);

  if (!spyResult) {
    throw new Error('Failed to calculate SPY DCA');
  }

  // Calculate DCA for all assets
  const results: DCAResult[] = [];

  for (const asset of DCA_ASSETS) {
    const dailyPrices = priceDataMap.get(asset.symbol);
    if (!dailyPrices || dailyPrices.length < 2) continue;

    const monthlyPrices = getMonthlyPrices(dailyPrices);

    // Align dates with SPY
    const alignedPrices = monthlyPrices.filter(p =>
      spyMonthly.some(s => s.date.substring(0, 7) === p.date.substring(0, 7))
    );

    if (alignedPrices.length < 2) continue;

    const result = calculateDCA(alignedPrices, monthlyAmount, asset);
    if (!result) continue;

    // Calculate vs SPY
    result.sp500TotalReturn = spyResult.totalReturn;
    result.sp500Value = spyResult.currentValue;
    result.outperformance = result.totalReturn - spyResult.totalReturn;

    results.push(result);
  }

  // Sort by total return
  results.sort((a, b) => b.totalReturn - a.totalReturn);

  // Build summary
  const bestPerformer = results[0];
  const beatingMarket = results.filter(r => r.outperformance > 0).length;
  const losingToMarket = results.filter(r => r.outperformance <= 0).length;

  const summary: DCAComparisonSummary = {
    monthlyAmount,
    totalMonths: spyMonthly.length,
    startDate: spyMonthly[0]?.date || '',
    endDate: spyMonthly[spyMonthly.length - 1]?.date || '',
    totalInvested: spyResult.totalInvested,
    bestPerformer: {
      symbol: bestPerformer?.symbol || 'SPY',
      name: bestPerformer?.name || 'S&P 500',
      totalReturn: bestPerformer?.totalReturn || 0,
      currentValue: bestPerformer?.currentValue || 0,
    },
    sp500Result: {
      totalReturn: spyResult.totalReturn,
      currentValue: spyResult.currentValue,
      annualizedReturn: spyResult.annualizedReturn,
    },
    beatingMarket,
    losingToMarket,
  };

  return { results, summary };
}

/**
 * Get top DCA performers
 */
export async function getTopDCAPerformers(
  monthlyAmount: number = 500,
  limit: number = 5
): Promise<DCAResult[]> {
  const { results } = await runDCAComparison(monthlyAmount, '2y');
  return results.slice(0, limit);
}
