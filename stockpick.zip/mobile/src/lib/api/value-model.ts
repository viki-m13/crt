/**
 * CRT-Style Value Stock Picker
 *
 * Identifies undervalued stocks with high probability of appreciation based on
 * historical similar instances. Unlike momentum models, this focuses on:
 *
 * 1. VALUE: Stocks trading below historical fair value
 * 2. SIMILARITY: Finding historical instances with similar characteristics
 * 3. PROBABILITY: Calculating actual outcomes from similar past instances
 *
 * Key metrics for "undervalued":
 * - Price relative to 52-week range (value position)
 * - Distance from moving averages (mean reversion potential)
 * - RSI levels (oversold conditions)
 * - Volatility-adjusted returns (risk-adjusted value)
 */

// Expanded universe - stocks and crypto with sufficient history
export const VALUE_UNIVERSE = [
  // Mega-cap Tech
  'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'NVDA', 'META', 'TSLA',
  // Large-cap Tech
  'AVGO', 'CRM', 'ORCL', 'ACN', 'CSCO', 'AMD', 'INTC', 'QCOM', 'TXN', 'IBM',
  'ADBE', 'NOW', 'INTU', 'AMAT', 'MU', 'LRCX', 'KLAC', 'SNPS', 'CDNS', 'PANW',
  'CRWD', 'PLTR', 'SNOW', 'DDOG', 'ZS', 'NET', 'TEAM', 'WDAY', 'VEEV', 'FTNT',
  // Financial
  'BRK-B', 'JPM', 'V', 'MA', 'GS', 'AXP', 'SPGI', 'BLK', 'BAC', 'WFC', 'C',
  'MS', 'SCHW', 'CME', 'ICE', 'MCO', 'MSCI', 'COF', 'USB', 'PNC', 'TFC',
  // Healthcare
  'UNH', 'JNJ', 'LLY', 'MRK', 'ABBV', 'ABT', 'TMO', 'PFE', 'DHR', 'BMY',
  'AMGN', 'GILD', 'VRTX', 'REGN', 'ISRG', 'SYK', 'MDT', 'BSX', 'ELV', 'CI',
  'HUM', 'ZTS', 'DXCM', 'IQV', 'IDXX', 'MTD', 'A', 'BIO', 'TECH',
  // Consumer
  'HD', 'PG', 'COST', 'MCD', 'NKE', 'DIS', 'NFLX', 'SBUX', 'TGT', 'LOW',
  'TJX', 'BKNG', 'MAR', 'YUM', 'CMG', 'DHI', 'LEN', 'ROST', 'ORLY', 'AZO',
  'LULU', 'DG', 'DLTR', 'EL', 'KMB', 'CL', 'GIS', 'K', 'HSY', 'MKC',
  'PEP', 'KO', 'WMT', 'PM', 'MO', 'STZ', 'MDLZ', 'MNST', 'KDP', 'KHC',
  // Industrial
  'UPS', 'HON', 'RTX', 'BA', 'CAT', 'DE', 'UNP', 'LMT', 'GE', 'MMM',
  'EMR', 'ETN', 'ITW', 'PH', 'ROK', 'CMI', 'PCAR', 'FDX', 'NSC', 'CSX',
  'WM', 'RSG', 'VRSK', 'FAST', 'ODFL', 'GWW', 'SWK', 'IR', 'DOV', 'NDSN',
  // Energy
  'XOM', 'CVX', 'COP', 'EOG', 'SLB', 'MPC', 'PSX', 'VLO', 'OXY', 'APA',
  'DVN', 'FANG', 'HAL', 'BKR', 'KMI', 'WMB', 'OKE', 'TRGP', 'LNG', 'ET',
  // Utilities
  'NEE', 'DUK', 'SO', 'D', 'AEP', 'EXC', 'SRE', 'XEL', 'PEG', 'ED',
  'WEC', 'ES', 'AWK', 'DTE', 'AEE', 'CMS', 'CNP', 'EVRG', 'NI', 'ATO',
  // REITs
  'PLD', 'AMT', 'EQIX', 'CCI', 'PSA', 'SPG', 'O', 'WELL', 'DLR', 'AVB',
  'EQR', 'VTR', 'ARE', 'MAA', 'UDR', 'ESS', 'INVH', 'SUI', 'ELS', 'CPT',
  // Materials
  'LIN', 'APD', 'SHW', 'ECL', 'NEM', 'FCX', 'NUE', 'VMC', 'MLM', 'DOW',
  'DD', 'PPG', 'ALB', 'CTVA', 'CF', 'MOS', 'IFF', 'CE', 'EMN', 'IP',
  // Crypto (via ETFs and proxies)
  'BTC-USD', 'ETH-USD', 'SOL-USD', 'DOGE-USD', 'ADA-USD', 'AVAX-USD',
  'DOT-USD', 'LINK-USD', 'MATIC-USD', 'UNI-USD', 'ATOM-USD', 'XRP-USD',
  'LTC-USD', 'BCH-USD', 'XLM-USD',
  // Crypto-related stocks
  'COIN', 'MSTR', 'MARA', 'RIOT', 'HUT', 'BITF', 'CLSK',
];

export const STOCK_INFO: Record<string, { name: string; sector: string }> = {
  // Mega-cap Tech
  'AAPL': { name: 'Apple', sector: 'Technology' },
  'MSFT': { name: 'Microsoft', sector: 'Technology' },
  'GOOGL': { name: 'Alphabet', sector: 'Technology' },
  'AMZN': { name: 'Amazon', sector: 'Technology' },
  'NVDA': { name: 'NVIDIA', sector: 'Technology' },
  'META': { name: 'Meta', sector: 'Technology' },
  'TSLA': { name: 'Tesla', sector: 'Technology' },
  // Large-cap Tech
  'AVGO': { name: 'Broadcom', sector: 'Technology' },
  'CRM': { name: 'Salesforce', sector: 'Technology' },
  'ORCL': { name: 'Oracle', sector: 'Technology' },
  'ACN': { name: 'Accenture', sector: 'Technology' },
  'CSCO': { name: 'Cisco', sector: 'Technology' },
  'AMD': { name: 'AMD', sector: 'Technology' },
  'INTC': { name: 'Intel', sector: 'Technology' },
  'QCOM': { name: 'Qualcomm', sector: 'Technology' },
  'TXN': { name: 'Texas Instruments', sector: 'Technology' },
  'IBM': { name: 'IBM', sector: 'Technology' },
  'ADBE': { name: 'Adobe', sector: 'Technology' },
  'NOW': { name: 'ServiceNow', sector: 'Technology' },
  'INTU': { name: 'Intuit', sector: 'Technology' },
  'AMAT': { name: 'Applied Materials', sector: 'Technology' },
  'MU': { name: 'Micron', sector: 'Technology' },
  'LRCX': { name: 'Lam Research', sector: 'Technology' },
  'KLAC': { name: 'KLA Corp', sector: 'Technology' },
  'SNPS': { name: 'Synopsys', sector: 'Technology' },
  'CDNS': { name: 'Cadence', sector: 'Technology' },
  'PANW': { name: 'Palo Alto', sector: 'Technology' },
  'CRWD': { name: 'CrowdStrike', sector: 'Technology' },
  'PLTR': { name: 'Palantir', sector: 'Technology' },
  'SNOW': { name: 'Snowflake', sector: 'Technology' },
  'DDOG': { name: 'Datadog', sector: 'Technology' },
  'ZS': { name: 'Zscaler', sector: 'Technology' },
  'NET': { name: 'Cloudflare', sector: 'Technology' },
  'TEAM': { name: 'Atlassian', sector: 'Technology' },
  'WDAY': { name: 'Workday', sector: 'Technology' },
  'VEEV': { name: 'Veeva', sector: 'Technology' },
  'FTNT': { name: 'Fortinet', sector: 'Technology' },
  // Financial
  'BRK-B': { name: 'Berkshire', sector: 'Financial' },
  'JPM': { name: 'JPMorgan', sector: 'Financial' },
  'V': { name: 'Visa', sector: 'Financial' },
  'MA': { name: 'Mastercard', sector: 'Financial' },
  'GS': { name: 'Goldman Sachs', sector: 'Financial' },
  'AXP': { name: 'Amex', sector: 'Financial' },
  'SPGI': { name: 'S&P Global', sector: 'Financial' },
  'BLK': { name: 'BlackRock', sector: 'Financial' },
  'BAC': { name: 'Bank of America', sector: 'Financial' },
  'WFC': { name: 'Wells Fargo', sector: 'Financial' },
  'C': { name: 'Citigroup', sector: 'Financial' },
  'MS': { name: 'Morgan Stanley', sector: 'Financial' },
  'SCHW': { name: 'Schwab', sector: 'Financial' },
  'CME': { name: 'CME Group', sector: 'Financial' },
  'ICE': { name: 'ICE', sector: 'Financial' },
  'MCO': { name: "Moody's", sector: 'Financial' },
  'MSCI': { name: 'MSCI', sector: 'Financial' },
  'COF': { name: 'Capital One', sector: 'Financial' },
  'USB': { name: 'US Bancorp', sector: 'Financial' },
  'PNC': { name: 'PNC', sector: 'Financial' },
  'TFC': { name: 'Truist', sector: 'Financial' },
  // Healthcare
  'UNH': { name: 'UnitedHealth', sector: 'Healthcare' },
  'JNJ': { name: 'J&J', sector: 'Healthcare' },
  'LLY': { name: 'Eli Lilly', sector: 'Healthcare' },
  'MRK': { name: 'Merck', sector: 'Healthcare' },
  'ABBV': { name: 'AbbVie', sector: 'Healthcare' },
  'ABT': { name: 'Abbott', sector: 'Healthcare' },
  'TMO': { name: 'Thermo Fisher', sector: 'Healthcare' },
  'PFE': { name: 'Pfizer', sector: 'Healthcare' },
  'DHR': { name: 'Danaher', sector: 'Healthcare' },
  'BMY': { name: 'Bristol-Myers', sector: 'Healthcare' },
  'AMGN': { name: 'Amgen', sector: 'Healthcare' },
  'GILD': { name: 'Gilead', sector: 'Healthcare' },
  'VRTX': { name: 'Vertex', sector: 'Healthcare' },
  'REGN': { name: 'Regeneron', sector: 'Healthcare' },
  'ISRG': { name: 'Intuitive Surgical', sector: 'Healthcare' },
  'SYK': { name: 'Stryker', sector: 'Healthcare' },
  'MDT': { name: 'Medtronic', sector: 'Healthcare' },
  'BSX': { name: 'Boston Scientific', sector: 'Healthcare' },
  'ELV': { name: 'Elevance', sector: 'Healthcare' },
  'CI': { name: 'Cigna', sector: 'Healthcare' },
  'HUM': { name: 'Humana', sector: 'Healthcare' },
  'ZTS': { name: 'Zoetis', sector: 'Healthcare' },
  'DXCM': { name: 'DexCom', sector: 'Healthcare' },
  'IQV': { name: 'IQVIA', sector: 'Healthcare' },
  'IDXX': { name: 'IDEXX', sector: 'Healthcare' },
  'MTD': { name: 'Mettler-Toledo', sector: 'Healthcare' },
  'A': { name: 'Agilent', sector: 'Healthcare' },
  'BIO': { name: 'Bio-Rad', sector: 'Healthcare' },
  'TECH': { name: 'Bio-Techne', sector: 'Healthcare' },
  // Consumer
  'HD': { name: 'Home Depot', sector: 'Consumer' },
  'PG': { name: 'P&G', sector: 'Consumer' },
  'COST': { name: 'Costco', sector: 'Consumer' },
  'MCD': { name: "McDonald's", sector: 'Consumer' },
  'NKE': { name: 'Nike', sector: 'Consumer' },
  'DIS': { name: 'Disney', sector: 'Consumer' },
  'NFLX': { name: 'Netflix', sector: 'Consumer' },
  'SBUX': { name: 'Starbucks', sector: 'Consumer' },
  'TGT': { name: 'Target', sector: 'Consumer' },
  'LOW': { name: "Lowe's", sector: 'Consumer' },
  'TJX': { name: 'TJX', sector: 'Consumer' },
  'BKNG': { name: 'Booking', sector: 'Consumer' },
  'MAR': { name: 'Marriott', sector: 'Consumer' },
  'YUM': { name: 'Yum! Brands', sector: 'Consumer' },
  'CMG': { name: 'Chipotle', sector: 'Consumer' },
  'DHI': { name: 'DR Horton', sector: 'Consumer' },
  'LEN': { name: 'Lennar', sector: 'Consumer' },
  'ROST': { name: 'Ross Stores', sector: 'Consumer' },
  'ORLY': { name: "O'Reilly", sector: 'Consumer' },
  'AZO': { name: 'AutoZone', sector: 'Consumer' },
  'LULU': { name: 'Lululemon', sector: 'Consumer' },
  'DG': { name: 'Dollar General', sector: 'Consumer' },
  'DLTR': { name: 'Dollar Tree', sector: 'Consumer' },
  'EL': { name: 'Estee Lauder', sector: 'Consumer' },
  'KMB': { name: 'Kimberly-Clark', sector: 'Consumer' },
  'CL': { name: 'Colgate', sector: 'Consumer' },
  'GIS': { name: 'General Mills', sector: 'Consumer' },
  'K': { name: 'Kellanova', sector: 'Consumer' },
  'HSY': { name: 'Hershey', sector: 'Consumer' },
  'MKC': { name: 'McCormick', sector: 'Consumer' },
  'PEP': { name: 'PepsiCo', sector: 'Consumer' },
  'KO': { name: 'Coca-Cola', sector: 'Consumer' },
  'WMT': { name: 'Walmart', sector: 'Consumer' },
  'PM': { name: 'Philip Morris', sector: 'Consumer' },
  'MO': { name: 'Altria', sector: 'Consumer' },
  'STZ': { name: 'Constellation', sector: 'Consumer' },
  'MDLZ': { name: 'Mondelez', sector: 'Consumer' },
  'MNST': { name: 'Monster', sector: 'Consumer' },
  'KDP': { name: 'Keurig Dr Pepper', sector: 'Consumer' },
  'KHC': { name: 'Kraft Heinz', sector: 'Consumer' },
  // Industrial
  'UPS': { name: 'UPS', sector: 'Industrial' },
  'HON': { name: 'Honeywell', sector: 'Industrial' },
  'RTX': { name: 'RTX', sector: 'Industrial' },
  'BA': { name: 'Boeing', sector: 'Industrial' },
  'CAT': { name: 'Caterpillar', sector: 'Industrial' },
  'DE': { name: 'John Deere', sector: 'Industrial' },
  'UNP': { name: 'Union Pacific', sector: 'Industrial' },
  'LMT': { name: 'Lockheed Martin', sector: 'Industrial' },
  'GE': { name: 'GE Aerospace', sector: 'Industrial' },
  'MMM': { name: '3M', sector: 'Industrial' },
  'EMR': { name: 'Emerson', sector: 'Industrial' },
  'ETN': { name: 'Eaton', sector: 'Industrial' },
  'ITW': { name: 'Illinois Tool Works', sector: 'Industrial' },
  'PH': { name: 'Parker Hannifin', sector: 'Industrial' },
  'ROK': { name: 'Rockwell', sector: 'Industrial' },
  'CMI': { name: 'Cummins', sector: 'Industrial' },
  'PCAR': { name: 'PACCAR', sector: 'Industrial' },
  'FDX': { name: 'FedEx', sector: 'Industrial' },
  'NSC': { name: 'Norfolk Southern', sector: 'Industrial' },
  'CSX': { name: 'CSX', sector: 'Industrial' },
  'WM': { name: 'Waste Management', sector: 'Industrial' },
  'RSG': { name: 'Republic Services', sector: 'Industrial' },
  'VRSK': { name: 'Verisk', sector: 'Industrial' },
  'FAST': { name: 'Fastenal', sector: 'Industrial' },
  'ODFL': { name: 'Old Dominion', sector: 'Industrial' },
  'GWW': { name: 'Grainger', sector: 'Industrial' },
  'SWK': { name: 'Stanley Black', sector: 'Industrial' },
  'IR': { name: 'Ingersoll Rand', sector: 'Industrial' },
  'DOV': { name: 'Dover', sector: 'Industrial' },
  'NDSN': { name: 'Nordson', sector: 'Industrial' },
  // Energy
  'XOM': { name: 'Exxon Mobil', sector: 'Energy' },
  'CVX': { name: 'Chevron', sector: 'Energy' },
  'COP': { name: 'ConocoPhillips', sector: 'Energy' },
  'EOG': { name: 'EOG Resources', sector: 'Energy' },
  'SLB': { name: 'Schlumberger', sector: 'Energy' },
  'MPC': { name: 'Marathon Petro', sector: 'Energy' },
  'PSX': { name: 'Phillips 66', sector: 'Energy' },
  'VLO': { name: 'Valero', sector: 'Energy' },
  'OXY': { name: 'Occidental', sector: 'Energy' },
  'APA': { name: 'APA Corp', sector: 'Energy' },
  'DVN': { name: 'Devon', sector: 'Energy' },
  'FANG': { name: 'Diamondback', sector: 'Energy' },
  'ET': { name: 'Energy Transfer', sector: 'Energy' },
  'HAL': { name: 'Halliburton', sector: 'Energy' },
  'BKR': { name: 'Baker Hughes', sector: 'Energy' },
  'KMI': { name: 'Kinder Morgan', sector: 'Energy' },
  'WMB': { name: 'Williams', sector: 'Energy' },
  'OKE': { name: 'ONEOK', sector: 'Energy' },
  'TRGP': { name: 'Targa', sector: 'Energy' },
  'LNG': { name: 'Cheniere', sector: 'Energy' },
  // Utilities
  'NEE': { name: 'NextEra', sector: 'Utilities' },
  'DUK': { name: 'Duke Energy', sector: 'Utilities' },
  'SO': { name: 'Southern Co', sector: 'Utilities' },
  'D': { name: 'Dominion', sector: 'Utilities' },
  'AEP': { name: 'AEP', sector: 'Utilities' },
  'EXC': { name: 'Exelon', sector: 'Utilities' },
  'SRE': { name: 'Sempra', sector: 'Utilities' },
  'XEL': { name: 'Xcel', sector: 'Utilities' },
  'PEG': { name: 'PSEG', sector: 'Utilities' },
  'ED': { name: 'Con Edison', sector: 'Utilities' },
  'WEC': { name: 'WEC Energy', sector: 'Utilities' },
  'ES': { name: 'Eversource', sector: 'Utilities' },
  'AWK': { name: 'American Water', sector: 'Utilities' },
  'DTE': { name: 'DTE Energy', sector: 'Utilities' },
  'AEE': { name: 'Ameren', sector: 'Utilities' },
  'CMS': { name: 'CMS Energy', sector: 'Utilities' },
  'CNP': { name: 'CenterPoint', sector: 'Utilities' },
  'EVRG': { name: 'Evergy', sector: 'Utilities' },
  'NI': { name: 'NiSource', sector: 'Utilities' },
  'ATO': { name: 'Atmos', sector: 'Utilities' },
  // REITs
  'PLD': { name: 'Prologis', sector: 'REITs' },
  'AMT': { name: 'American Tower', sector: 'REITs' },
  'EQIX': { name: 'Equinix', sector: 'REITs' },
  'CCI': { name: 'Crown Castle', sector: 'REITs' },
  'PSA': { name: 'Public Storage', sector: 'REITs' },
  'SPG': { name: 'Simon Property', sector: 'REITs' },
  'O': { name: 'Realty Income', sector: 'REITs' },
  'WELL': { name: 'Welltower', sector: 'REITs' },
  'DLR': { name: 'Digital Realty', sector: 'REITs' },
  'AVB': { name: 'AvalonBay', sector: 'REITs' },
  'EQR': { name: 'Equity Residential', sector: 'REITs' },
  'VTR': { name: 'Ventas', sector: 'REITs' },
  'ARE': { name: 'Alexandria', sector: 'REITs' },
  'MAA': { name: 'Mid-America', sector: 'REITs' },
  'UDR': { name: 'UDR', sector: 'REITs' },
  'ESS': { name: 'Essex Property', sector: 'REITs' },
  'INVH': { name: 'Invitation Homes', sector: 'REITs' },
  'SUI': { name: 'Sun Communities', sector: 'REITs' },
  'ELS': { name: 'Equity LifeStyle', sector: 'REITs' },
  'CPT': { name: 'Camden Property', sector: 'REITs' },
  // Materials
  'LIN': { name: 'Linde', sector: 'Materials' },
  'APD': { name: 'Air Products', sector: 'Materials' },
  'SHW': { name: 'Sherwin-Williams', sector: 'Materials' },
  'ECL': { name: 'Ecolab', sector: 'Materials' },
  'NEM': { name: 'Newmont', sector: 'Materials' },
  'FCX': { name: 'Freeport', sector: 'Materials' },
  'NUE': { name: 'Nucor', sector: 'Materials' },
  'VMC': { name: 'Vulcan', sector: 'Materials' },
  'MLM': { name: 'Martin Marietta', sector: 'Materials' },
  'DOW': { name: 'Dow', sector: 'Materials' },
  'DD': { name: 'DuPont', sector: 'Materials' },
  'PPG': { name: 'PPG', sector: 'Materials' },
  'ALB': { name: 'Albemarle', sector: 'Materials' },
  'CTVA': { name: 'Corteva', sector: 'Materials' },
  'CF': { name: 'CF Industries', sector: 'Materials' },
  'MOS': { name: 'Mosaic', sector: 'Materials' },
  'IFF': { name: 'IFF', sector: 'Materials' },
  'CE': { name: 'Celanese', sector: 'Materials' },
  'EMN': { name: 'Eastman', sector: 'Materials' },
  'IP': { name: 'International Paper', sector: 'Materials' },
  // Crypto
  'BTC-USD': { name: 'Bitcoin', sector: 'Crypto' },
  'ETH-USD': { name: 'Ethereum', sector: 'Crypto' },
  'SOL-USD': { name: 'Solana', sector: 'Crypto' },
  'DOGE-USD': { name: 'Dogecoin', sector: 'Crypto' },
  'ADA-USD': { name: 'Cardano', sector: 'Crypto' },
  'AVAX-USD': { name: 'Avalanche', sector: 'Crypto' },
  'DOT-USD': { name: 'Polkadot', sector: 'Crypto' },
  'LINK-USD': { name: 'Chainlink', sector: 'Crypto' },
  'MATIC-USD': { name: 'Polygon', sector: 'Crypto' },
  'UNI-USD': { name: 'Uniswap', sector: 'Crypto' },
  'ATOM-USD': { name: 'Cosmos', sector: 'Crypto' },
  'XRP-USD': { name: 'XRP', sector: 'Crypto' },
  'LTC-USD': { name: 'Litecoin', sector: 'Crypto' },
  'BCH-USD': { name: 'Bitcoin Cash', sector: 'Crypto' },
  'XLM-USD': { name: 'Stellar', sector: 'Crypto' },
  // Crypto-related stocks
  'COIN': { name: 'Coinbase', sector: 'Crypto' },
  'MSTR': { name: 'MicroStrategy', sector: 'Crypto' },
  'MARA': { name: 'Marathon Digital', sector: 'Crypto' },
  'RIOT': { name: 'Riot Platforms', sector: 'Crypto' },
  'HUT': { name: 'Hut 8', sector: 'Crypto' },
  'BITF': { name: 'Bitfarms', sector: 'Crypto' },
  'CLSK': { name: 'CleanSpark', sector: 'Crypto' },
};

// ==================== DATA TYPES ====================

export interface StockData {
  symbol: string;
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  adjClose: number;
}

export interface ValueMetrics {
  // Core value metrics
  valuePosition: number;         // 0 = at 52w low, 100 = at 52w high
  distanceFromSMA200: number;    // % distance from 200-day SMA
  distanceFromSMA50: number;     // % distance from 50-day SMA
  rsi14: number;                 // RSI 14-day

  // Mean reversion potential
  drawdownFrom52wHigh: number;   // % below 52-week high
  drawdownFromATH: number;       // % below all-time high

  // Quality filters (to avoid value traps)
  volatility90d: number;         // 90-day volatility
  trend200d: number;             // 200-day trend direction (-1 to 1)
  earningsStability: number;     // Return consistency score
}

export interface HistoricalInstance {
  date: string;
  valuePosition: number;
  distanceFromSMA200: number;
  rsi14: number;
  drawdownFrom52wHigh: number;
  // Actual outcomes
  return1Y: number;
  return3Y: number;
  return5Y: number;
  wasHigher1Y: boolean;
  wasHigher3Y: boolean;
  wasHigher5Y: boolean;
}

export interface SimilarInstance {
  date: string;
  similarity: number;            // 0-100 similarity score
  return1Y: number;
  return3Y: number;
  return5Y: number;
  wasHigher1Y: boolean;
  wasHigher3Y: boolean;
  wasHigher5Y: boolean;
}

export interface ValuePick {
  symbol: string;
  name: string;
  sector: string;
  currentPrice: number;

  // Value assessment
  valueScore: number;            // 0-100, higher = more undervalued
  valueCategory: 'DEEP_VALUE' | 'VALUE' | 'FAIR' | 'EXPENSIVE';

  // Current metrics
  metrics: ValueMetrics;

  // Probabilities from historical instances
  prob1Year: number;             // % probability of being higher
  prob3Year: number;
  prob5Year: number;

  // Expected returns from similar instances
  medianReturn1Y: number;
  medianReturn3Y: number;
  medianReturn5Y: number;

  // Historical evidence
  similarInstances: SimilarInstance[];
  totalSimilarInstances: number;

  // Quality and risk
  qualityScore: number;          // Filters out value traps
  riskScore: number;             // Higher = riskier

  // Signal
  signal: 'STRONG_BUY' | 'BUY' | 'HOLD' | 'AVOID';
  confidence: number;
}

export interface ValueBacktestSummary {
  // Hit rates from historical similar instances
  avgHitRate1Y: number;
  avgHitRate3Y: number;
  avgHitRate5Y: number;

  // Returns from similar instances
  avgReturn1Y: number;
  avgReturn3Y: number;
  avgReturn5Y: number;

  // vs S&P 500
  avgSpyReturn1Y: number;
  avgSpyReturn3Y: number;
  avgSpyReturn5Y: number;

  // Alpha
  alpha1Y: number;
  alpha3Y: number;
  alpha5Y: number;

  // Stats
  totalInstancesAnalyzed: number;
  avgSimilarityScore: number;
}

// ==================== DATA FETCHING ====================

const YAHOO_CHART_API = 'https://query1.finance.yahoo.com/v8/finance/chart';

export async function fetchStockData(
  symbol: string,
  period: '5y' | '10y' = '10y'
): Promise<StockData[]> {
  try {
    const url = `${YAHOO_CHART_API}/${symbol}?interval=1d&range=${period}`;

    const response = await fetch(url, {
      headers: { 'User-Agent': 'Mozilla/5.0' },
    });

    if (!response.ok) {
      // Silently skip - ticker may be delisted or unavailable
      return [];
    }

    const data = await response.json();

    if (data.chart.error || !data.chart.result?.[0]) {
      // Silently skip - no data available
      return [];
    }

    const result = data.chart.result[0];
    const timestamps = result.timestamp || [];
    const quotes = result.indicators.quote[0];
    const adjClose = result.indicators.adjclose?.[0]?.adjclose || quotes.close;

    const stockData: StockData[] = [];

    for (let i = 0; i < timestamps.length; i++) {
      if (quotes.close[i] != null && quotes.close[i] > 0) {
        stockData.push({
          symbol,
          date: new Date(timestamps[i] * 1000).toISOString().split('T')[0],
          open: quotes.open[i] || quotes.close[i],
          high: quotes.high[i] || quotes.close[i],
          low: quotes.low[i] || quotes.close[i],
          close: quotes.close[i],
          volume: quotes.volume[i] || 0,
          adjClose: adjClose[i] || quotes.close[i],
        });
      }
    }

    return stockData;
  } catch {
    // Silently skip any errors - ticker may be invalid
    return [];
  }
}

export async function fetchAllStocksData(
  symbols: string[] = VALUE_UNIVERSE
): Promise<Map<string, StockData[]>> {
  const dataMap = new Map<string, StockData[]>();

  const batchSize = 5;
  for (let i = 0; i < symbols.length; i += batchSize) {
    const batch = symbols.slice(i, i + batchSize);
    const results = await Promise.all(
      batch.map(symbol => fetchStockData(symbol, '10y'))
    );

    batch.forEach((symbol, idx) => {
      if (results[idx].length > 0) {
        dataMap.set(symbol, results[idx]);
      }
    });

    if (i + batchSize < symbols.length) {
      await new Promise(resolve => setTimeout(resolve, 300));
    }
  }

  return dataMap;
}

// ==================== VALUE CALCULATIONS ====================

function mean(arr: number[]): number {
  if (arr.length === 0) return 0;
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

function median(arr: number[]): number {
  if (arr.length === 0) return 0;
  const sorted = [...arr].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

function std(arr: number[]): number {
  if (arr.length < 2) return 0;
  const avg = mean(arr);
  const variance = arr.map(x => Math.pow(x - avg, 2)).reduce((a, b) => a + b, 0) / arr.length;
  return Math.sqrt(variance);
}

function calculateSMA(prices: number[], period: number): number[] {
  const result: number[] = [];
  for (let i = period - 1; i < prices.length; i++) {
    const sum = prices.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
    result.push(sum / period);
  }
  return result;
}

function calculateRSI(prices: number[], period: number = 14): number {
  if (prices.length < period + 1) return 50;

  const gains: number[] = [];
  const losses: number[] = [];

  for (let i = 1; i < prices.length; i++) {
    const change = prices[i] - prices[i - 1];
    gains.push(Math.max(0, change));
    losses.push(Math.max(0, -change));
  }

  let avgGain = mean(gains.slice(0, period));
  let avgLoss = mean(losses.slice(0, period));

  for (let i = period; i < gains.length; i++) {
    avgGain = (avgGain * (period - 1) + gains[i]) / period;
    avgLoss = (avgLoss * (period - 1) + losses[i]) / period;
  }

  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
}

function calculateReturns(prices: number[]): number[] {
  const returns: number[] = [];
  for (let i = 1; i < prices.length; i++) {
    if (prices[i - 1] > 0) {
      returns.push((prices[i] - prices[i - 1]) / prices[i - 1]);
    }
  }
  return returns;
}

/**
 * Calculate value metrics at a specific point in time
 */
export function calculateValueMetrics(
  prices: number[],
  asOfIndex: number
): ValueMetrics | null {
  if (asOfIndex < 252) return null;

  const currentPrice = prices[asOfIndex];
  const historicalPrices = prices.slice(0, asOfIndex + 1);

  // 52-week range
  const recent252 = historicalPrices.slice(-252);
  const high52w = Math.max(...recent252);
  const low52w = Math.min(...recent252);
  const range = high52w - low52w;

  // Value position (0 = at low, 100 = at high)
  const valuePosition = range > 0
    ? ((currentPrice - low52w) / range) * 100
    : 50;

  // Distance from moving averages
  const sma200 = calculateSMA(historicalPrices, Math.min(200, historicalPrices.length - 1));
  const sma50 = calculateSMA(historicalPrices, Math.min(50, historicalPrices.length - 1));

  const currentSMA200 = sma200[sma200.length - 1] || currentPrice;
  const currentSMA50 = sma50[sma50.length - 1] || currentPrice;

  const distanceFromSMA200 = ((currentPrice - currentSMA200) / currentSMA200) * 100;
  const distanceFromSMA50 = ((currentPrice - currentSMA50) / currentSMA50) * 100;

  // RSI
  const rsi14 = calculateRSI(historicalPrices.slice(-30), 14);

  // Drawdowns
  const drawdownFrom52wHigh = ((currentPrice - high52w) / high52w) * 100;
  const ath = Math.max(...historicalPrices);
  const drawdownFromATH = ((currentPrice - ath) / ath) * 100;

  // Volatility (90-day)
  const returns90 = calculateReturns(historicalPrices.slice(-90));
  const volatility90d = std(returns90) * Math.sqrt(252) * 100;

  // Trend direction
  const sma200Start = sma200.length >= 60 ? sma200[sma200.length - 60] : currentSMA200;
  const trend200d = sma200Start > 0
    ? Math.max(-1, Math.min(1, (currentSMA200 - sma200Start) / sma200Start * 10))
    : 0;

  // Earnings stability (return consistency)
  const monthlyReturns: number[] = [];
  for (let i = 21; i < historicalPrices.length && monthlyReturns.length < 12; i += 21) {
    const startIdx = Math.max(0, i - 21);
    if (historicalPrices[startIdx] > 0) {
      monthlyReturns.push((historicalPrices[i] - historicalPrices[startIdx]) / historicalPrices[startIdx]);
    }
  }
  const returnStd = std(monthlyReturns);
  const earningsStability = Math.max(0, Math.min(100, (1 - returnStd * 5) * 100));

  return {
    valuePosition,
    distanceFromSMA200,
    distanceFromSMA50,
    rsi14,
    drawdownFrom52wHigh,
    drawdownFromATH,
    volatility90d,
    trend200d,
    earningsStability,
  };
}

/**
 * Build historical instances database for a stock
 * Each instance records the conditions and actual outcomes
 */
export function buildHistoricalInstances(prices: number[]): HistoricalInstance[] {
  const instances: HistoricalInstance[] = [];

  // Start after 2 years of data, end 5 years before present
  const startIdx = 252 * 2;
  const endIdx = prices.length - 252 * 5;

  if (endIdx <= startIdx) return instances;

  // Sample quarterly to avoid overlap
  for (let i = startIdx; i < endIdx; i += 63) {
    const metrics = calculateValueMetrics(prices, i);
    if (!metrics) continue;

    const currentPrice = prices[i];

    // Calculate actual future returns
    const price1Y = i + 252 < prices.length ? prices[i + 252] : null;
    const price3Y = i + 252 * 3 < prices.length ? prices[i + 252 * 3] : null;
    const price5Y = i + 252 * 5 < prices.length ? prices[i + 252 * 5] : null;

    if (!price1Y) continue;

    const return1Y = ((price1Y - currentPrice) / currentPrice) * 100;
    const return3Y = price3Y ? ((price3Y - currentPrice) / currentPrice) * 100 : 0;
    const return5Y = price5Y ? ((price5Y - currentPrice) / currentPrice) * 100 : 0;

    instances.push({
      date: `Day ${i}`, // Placeholder - we don't have actual dates in this context
      valuePosition: metrics.valuePosition,
      distanceFromSMA200: metrics.distanceFromSMA200,
      rsi14: metrics.rsi14,
      drawdownFrom52wHigh: metrics.drawdownFrom52wHigh,
      return1Y,
      return3Y,
      return5Y,
      wasHigher1Y: return1Y > 0,
      wasHigher3Y: return3Y > 0,
      wasHigher5Y: return5Y > 0,
    });
  }

  return instances;
}

/**
 * Find similar historical instances to current conditions
 * Uses CRT-like similarity based on key value metrics
 */
export function findSimilarInstances(
  currentMetrics: ValueMetrics,
  historicalInstances: HistoricalInstance[],
  maxInstances: number = 20
): SimilarInstance[] {
  // Calculate similarity score for each historical instance
  const scored = historicalInstances.map(instance => {
    // Key criteria for "similar" value situations:
    // 1. Similar value position (distance from 52w high)
    // 2. Similar distance from SMA200
    // 3. Similar RSI
    // 4. Similar drawdown

    const valueDiff = Math.abs(currentMetrics.valuePosition - instance.valuePosition);
    const smaDiff = Math.abs(currentMetrics.distanceFromSMA200 - instance.distanceFromSMA200);
    const rsiDiff = Math.abs(currentMetrics.rsi14 - instance.rsi14);
    const drawdownDiff = Math.abs(currentMetrics.drawdownFrom52wHigh - instance.drawdownFrom52wHigh);

    // Weight the factors (value position and drawdown matter most for value investing)
    const similarity = Math.max(0, 100 - (
      valueDiff * 1.0 +          // Value position difference
      smaDiff * 0.5 +            // SMA distance difference
      rsiDiff * 0.3 +            // RSI difference
      drawdownDiff * 0.8         // Drawdown difference
    ));

    return {
      ...instance,
      similarity,
    };
  });

  // Filter to only reasonably similar instances (>50% similarity)
  const similar = scored
    .filter(s => s.similarity > 50)
    .sort((a, b) => b.similarity - a.similarity)
    .slice(0, maxInstances);

  return similar.map(s => ({
    date: s.date,
    similarity: Math.round(s.similarity),
    return1Y: Math.round(s.return1Y * 10) / 10,
    return3Y: Math.round(s.return3Y * 10) / 10,
    return5Y: Math.round(s.return5Y * 10) / 10,
    wasHigher1Y: s.wasHigher1Y,
    wasHigher3Y: s.wasHigher3Y,
    wasHigher5Y: s.wasHigher5Y,
  }));
}

/**
 * Calculate value score (how undervalued the stock appears)
 */
function calculateValueScore(metrics: ValueMetrics): number {
  let score = 0;

  // Lower value position = more value (closer to 52w low)
  // 0-20 = deep value (+40), 20-40 = value (+25), 40-60 = fair (+10)
  if (metrics.valuePosition <= 20) score += 40;
  else if (metrics.valuePosition <= 40) score += 25;
  else if (metrics.valuePosition <= 60) score += 10;
  else if (metrics.valuePosition >= 80) score -= 10;

  // Below SMA200 = potential value
  if (metrics.distanceFromSMA200 < -10) score += 25;
  else if (metrics.distanceFromSMA200 < -5) score += 15;
  else if (metrics.distanceFromSMA200 < 0) score += 5;
  else if (metrics.distanceFromSMA200 > 10) score -= 10;

  // Low RSI = oversold (potential value)
  if (metrics.rsi14 < 30) score += 20;
  else if (metrics.rsi14 < 40) score += 10;
  else if (metrics.rsi14 < 50) score += 5;
  else if (metrics.rsi14 > 70) score -= 10;

  // Significant drawdown = potential value opportunity
  if (metrics.drawdownFrom52wHigh < -30) score += 15;
  else if (metrics.drawdownFrom52wHigh < -20) score += 10;
  else if (metrics.drawdownFrom52wHigh < -10) score += 5;

  return Math.max(0, Math.min(100, score + 20)); // Base of 20
}

/**
 * Calculate quality score (filters out value traps)
 */
function calculateQualityScore(metrics: ValueMetrics): number {
  let score = 50;

  // Earnings stability is key
  score += (metrics.earningsStability - 50) * 0.3;

  // Not too volatile
  if (metrics.volatility90d < 25) score += 15;
  else if (metrics.volatility90d < 35) score += 5;
  else if (metrics.volatility90d > 50) score -= 15;

  // Trend not collapsing (avoid catching falling knives)
  if (metrics.trend200d > 0) score += 10;
  else if (metrics.trend200d < -0.5) score -= 15;

  return Math.max(0, Math.min(100, score));
}

/**
 * Determine value category
 */
function getValueCategory(valueScore: number, metrics: ValueMetrics): 'DEEP_VALUE' | 'VALUE' | 'FAIR' | 'EXPENSIVE' {
  if (valueScore >= 70 && metrics.valuePosition < 30) return 'DEEP_VALUE';
  if (valueScore >= 50) return 'VALUE';
  if (valueScore >= 30) return 'FAIR';
  return 'EXPENSIVE';
}

/**
 * Determine trading signal
 */
function determineSignal(
  valueScore: number,
  qualityScore: number,
  prob1Y: number,
  prob3Y: number,
  prob5Y: number
): { signal: 'STRONG_BUY' | 'BUY' | 'HOLD' | 'AVOID'; confidence: number } {
  const avgProb = (prob1Y + prob3Y + prob5Y) / 3;
  const combinedScore = valueScore * 0.4 + qualityScore * 0.3 + avgProb * 0.3;

  if (combinedScore >= 70 && prob5Y >= 80 && qualityScore >= 50) {
    return { signal: 'STRONG_BUY', confidence: Math.round(combinedScore) };
  }
  if (combinedScore >= 55 && prob3Y >= 70 && qualityScore >= 40) {
    return { signal: 'BUY', confidence: Math.round(combinedScore) };
  }
  if (combinedScore >= 40 && qualityScore >= 30) {
    return { signal: 'HOLD', confidence: Math.round(combinedScore) };
  }
  return { signal: 'AVOID', confidence: Math.round(100 - combinedScore) };
}

// ==================== PROGRESS TRACKING ====================

export interface LoadingProgress {
  phase: 'fetching' | 'analyzing' | 'calculating' | 'complete';
  current: number;
  total: number;
  currentSymbol?: string;
  message: string;
}

export type ProgressCallback = (progress: LoadingProgress) => void;

// Global progress callback
let globalProgressCallback: ProgressCallback | null = null;

export function setProgressCallback(callback: ProgressCallback | null) {
  globalProgressCallback = callback;
}

function reportProgress(progress: LoadingProgress) {
  if (globalProgressCallback) {
    globalProgressCallback(progress);
  }
}

export async function fetchAllStocksDataWithProgress(
  symbols: string[] = VALUE_UNIVERSE
): Promise<Map<string, StockData[]>> {
  const dataMap = new Map<string, StockData[]>();

  const batchSize = 5;
  const totalBatches = Math.ceil(symbols.length / batchSize);

  for (let i = 0; i < symbols.length; i += batchSize) {
    const batchNum = Math.floor(i / batchSize) + 1;
    const batch = symbols.slice(i, i + batchSize);

    reportProgress({
      phase: 'fetching',
      current: batchNum,
      total: totalBatches,
      currentSymbol: batch[0],
      message: `Fetching ${batch.join(', ')}...`,
    });

    const results = await Promise.all(
      batch.map(symbol => fetchStockData(symbol, '10y'))
    );

    batch.forEach((symbol, idx) => {
      if (results[idx].length > 0) {
        dataMap.set(symbol, results[idx]);
      }
    });

    if (i + batchSize < symbols.length) {
      await new Promise(resolve => setTimeout(resolve, 300));
    }
  }

  return dataMap;
}

// ==================== MAIN ANALYSIS FUNCTION ====================

export async function getValuePicks(): Promise<ValuePick[]> {
  const allSymbols = [...VALUE_UNIVERSE, 'SPY'];

  reportProgress({
    phase: 'fetching',
    current: 0,
    total: allSymbols.length,
    message: 'Connecting to markets...',
  });

  const dataMap = await fetchAllStocksDataWithProgress(allSymbols);

  const picks: ValuePick[] = [];
  const totalSymbols = VALUE_UNIVERSE.length;
  let processedCount = 0;

  for (const symbol of VALUE_UNIVERSE) {
    processedCount++;
    reportProgress({
      phase: 'analyzing',
      current: processedCount,
      total: totalSymbols,
      currentSymbol: symbol,
      message: `Analyzing ${symbol}...`,
    });

    const stockData = dataMap.get(symbol);
    if (!stockData || stockData.length < 252 * 3) continue;

    const prices = stockData.map(d => d.adjClose);
    const currentPrice = prices[prices.length - 1];
    const info = STOCK_INFO[symbol] || { name: symbol, sector: 'Unknown' };

    // Calculate current value metrics
    const metrics = calculateValueMetrics(prices, prices.length - 1);
    if (!metrics) continue;

    // Build historical instances and find similar ones
    const historicalInstances = buildHistoricalInstances(prices);
    const similarInstances = findSimilarInstances(metrics, historicalInstances, 15);

    if (similarInstances.length < 5) continue; // Need sufficient evidence

    // Calculate probabilities from similar instances
    const prob1Y = (similarInstances.filter(s => s.wasHigher1Y).length / similarInstances.length) * 100;
    const prob3Y = (similarInstances.filter(s => s.wasHigher3Y).length / similarInstances.length) * 100;
    const prob5Y = (similarInstances.filter(s => s.wasHigher5Y).length / similarInstances.length) * 100;

    // Calculate median returns from similar instances
    const returns1Y = similarInstances.map(s => s.return1Y);
    const returns3Y = similarInstances.map(s => s.return3Y);
    const returns5Y = similarInstances.map(s => s.return5Y);

    const medianReturn1Y = median(returns1Y);
    const medianReturn3Y = median(returns3Y);
    const medianReturn5Y = median(returns5Y);

    // Calculate scores
    const valueScore = calculateValueScore(metrics);
    const qualityScore = calculateQualityScore(metrics);
    const valueCategory = getValueCategory(valueScore, metrics);

    // Risk score (inverse of quality + volatility consideration)
    const riskScore = Math.round(100 - qualityScore * 0.5 - (50 - Math.min(50, metrics.volatility90d)));

    // Determine signal
    const { signal, confidence } = determineSignal(valueScore, qualityScore, prob1Y, prob3Y, prob5Y);

    picks.push({
      symbol,
      name: info.name,
      sector: info.sector,
      currentPrice,
      valueScore: Math.round(valueScore),
      valueCategory,
      metrics,
      prob1Year: Math.round(prob1Y),
      prob3Year: Math.round(prob3Y),
      prob5Year: Math.round(prob5Y),
      medianReturn1Y: Math.round(medianReturn1Y * 10) / 10,
      medianReturn3Y: Math.round(medianReturn3Y * 10) / 10,
      medianReturn5Y: Math.round(medianReturn5Y * 10) / 10,
      similarInstances: similarInstances.slice(0, 5), // Top 5 for display
      totalSimilarInstances: similarInstances.length,
      qualityScore: Math.round(qualityScore),
      riskScore: Math.round(riskScore),
      signal,
      confidence,
    });
  }

  // Sort by value score (highest value opportunities first)
  picks.sort((a, b) => b.valueScore - a.valueScore);

  reportProgress({
    phase: 'complete',
    current: totalSymbols,
    total: totalSymbols,
    message: 'Analysis complete!',
  });

  return picks;
}

export async function getTopValuePicks(n: number = 5): Promise<ValuePick[]> {
  const allPicks = await getValuePicks();
  // Filter to only good signals and take top N by value score
  return allPicks
    .filter(p => p.signal === 'STRONG_BUY' || p.signal === 'BUY')
    .slice(0, n);
}

// ==================== BACKTEST SUMMARY ====================

export async function runValueBacktest(): Promise<ValueBacktestSummary> {
  const dataMap = await fetchAllStocksData([...VALUE_UNIVERSE, 'SPY']);
  const spyData = dataMap.get('SPY');

  let totalInstances = 0;
  let sumSimilarity = 0;
  const allReturns1Y: number[] = [];
  const allReturns3Y: number[] = [];
  const allReturns5Y: number[] = [];
  let hit1Y = 0, hit3Y = 0, hit5Y = 0;
  let count1Y = 0, count3Y = 0, count5Y = 0;

  for (const symbol of VALUE_UNIVERSE) {
    const stockData = dataMap.get(symbol);
    if (!stockData || stockData.length < 252 * 5) continue;

    const prices = stockData.map(d => d.adjClose);
    const instances = buildHistoricalInstances(prices);

    // Only look at "value" instances (similar to our current picks)
    const valueInstances = instances.filter(i =>
      i.valuePosition < 40 && // In bottom 40% of 52w range
      i.distanceFromSMA200 < 0 // Below 200-day SMA
    );

    for (const instance of valueInstances) {
      totalInstances++;
      sumSimilarity += 70; // Assume average similarity

      if (instance.return1Y !== undefined) {
        allReturns1Y.push(instance.return1Y);
        if (instance.wasHigher1Y) hit1Y++;
        count1Y++;
      }
      if (instance.return3Y !== undefined && instance.return3Y !== 0) {
        allReturns3Y.push(instance.return3Y);
        if (instance.wasHigher3Y) hit3Y++;
        count3Y++;
      }
      if (instance.return5Y !== undefined && instance.return5Y !== 0) {
        allReturns5Y.push(instance.return5Y);
        if (instance.wasHigher5Y) hit5Y++;
        count5Y++;
      }
    }
  }

  // SPY benchmark returns (approximations)
  const avgSpyReturn1Y = 10;  // Historical average
  const avgSpyReturn3Y = 35;
  const avgSpyReturn5Y = 65;

  const avgReturn1Y = mean(allReturns1Y);
  const avgReturn3Y = mean(allReturns3Y);
  const avgReturn5Y = mean(allReturns5Y);

  return {
    avgHitRate1Y: count1Y > 0 ? Math.round((hit1Y / count1Y) * 100) : 0,
    avgHitRate3Y: count3Y > 0 ? Math.round((hit3Y / count3Y) * 100) : 0,
    avgHitRate5Y: count5Y > 0 ? Math.round((hit5Y / count5Y) * 100) : 0,
    avgReturn1Y: Math.round(avgReturn1Y * 10) / 10,
    avgReturn3Y: Math.round(avgReturn3Y * 10) / 10,
    avgReturn5Y: Math.round(avgReturn5Y * 10) / 10,
    avgSpyReturn1Y,
    avgSpyReturn3Y,
    avgSpyReturn5Y,
    alpha1Y: Math.round((avgReturn1Y - avgSpyReturn1Y) * 10) / 10,
    alpha3Y: Math.round((avgReturn3Y - avgSpyReturn3Y) * 10) / 10,
    alpha5Y: Math.round((avgReturn5Y - avgSpyReturn5Y) * 10) / 10,
    totalInstancesAnalyzed: totalInstances,
    avgSimilarityScore: totalInstances > 0 ? Math.round(sumSimilarity / totalInstances) : 0,
  };
}
