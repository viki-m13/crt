/**
 * Stock Prediction Model
 *
 * Identifies stocks with highest probability of appreciation over 1, 3, and 5 year horizons.
 * Uses multi-factor analysis with rigorous backtesting to validate predictive accuracy.
 *
 * Key factors with empirical support:
 * 1. Value (P/E relative, distance from fair value)
 * 2. Quality (earnings stability, profitability consistency)
 * 3. Momentum (price momentum with mean reversion)
 * 4. Growth trajectory (revenue/earnings growth trends)
 * 5. Financial strength (low volatility, trend persistence)
 */

// Stock universe - focus on liquid, large-cap stocks with sufficient history
export const PREDICTION_UNIVERSE = [
  'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'NVDA', 'META', 'TSLA', 'BRK-B', 'JPM',
  'V', 'UNH', 'HD', 'PG', 'MA', 'JNJ', 'LLY', 'AVGO', 'COST', 'MRK',
  'ABBV', 'PEP', 'KO', 'WMT', 'CRM', 'ORCL', 'ACN', 'MCD', 'CSCO', 'ABT',
  'TMO', 'NFLX', 'AMD', 'INTC', 'NKE', 'DIS', 'QCOM', 'TXN', 'LOW', 'UPS',
  'NEE', 'HON', 'IBM', 'RTX', 'BA', 'CAT', 'GS', 'AXP', 'SPGI', 'BLK'
];

export const STOCK_INFO: Record<string, { name: string; sector: string }> = {
  'AAPL': { name: 'Apple Inc.', sector: 'Technology' },
  'MSFT': { name: 'Microsoft Corp.', sector: 'Technology' },
  'GOOGL': { name: 'Alphabet Inc.', sector: 'Technology' },
  'AMZN': { name: 'Amazon.com', sector: 'Consumer' },
  'NVDA': { name: 'NVIDIA Corp.', sector: 'Technology' },
  'META': { name: 'Meta Platforms', sector: 'Technology' },
  'TSLA': { name: 'Tesla Inc.', sector: 'Consumer' },
  'BRK-B': { name: 'Berkshire Hathaway', sector: 'Financial' },
  'JPM': { name: 'JPMorgan Chase', sector: 'Financial' },
  'V': { name: 'Visa Inc.', sector: 'Financial' },
  'UNH': { name: 'UnitedHealth', sector: 'Healthcare' },
  'HD': { name: 'Home Depot', sector: 'Consumer' },
  'PG': { name: 'Procter & Gamble', sector: 'Consumer' },
  'MA': { name: 'Mastercard', sector: 'Financial' },
  'JNJ': { name: 'Johnson & Johnson', sector: 'Healthcare' },
  'LLY': { name: 'Eli Lilly', sector: 'Healthcare' },
  'AVGO': { name: 'Broadcom Inc.', sector: 'Technology' },
  'COST': { name: 'Costco', sector: 'Consumer' },
  'MRK': { name: 'Merck & Co.', sector: 'Healthcare' },
  'ABBV': { name: 'AbbVie Inc.', sector: 'Healthcare' },
  'PEP': { name: 'PepsiCo', sector: 'Consumer' },
  'KO': { name: 'Coca-Cola', sector: 'Consumer' },
  'WMT': { name: 'Walmart', sector: 'Consumer' },
  'CRM': { name: 'Salesforce', sector: 'Technology' },
  'ORCL': { name: 'Oracle Corp.', sector: 'Technology' },
  'ACN': { name: 'Accenture', sector: 'Technology' },
  'MCD': { name: "McDonald's", sector: 'Consumer' },
  'CSCO': { name: 'Cisco Systems', sector: 'Technology' },
  'ABT': { name: 'Abbott Labs', sector: 'Healthcare' },
  'TMO': { name: 'Thermo Fisher', sector: 'Healthcare' },
  'NFLX': { name: 'Netflix', sector: 'Consumer' },
  'AMD': { name: 'AMD', sector: 'Technology' },
  'INTC': { name: 'Intel Corp.', sector: 'Technology' },
  'NKE': { name: 'Nike Inc.', sector: 'Consumer' },
  'DIS': { name: 'Walt Disney', sector: 'Consumer' },
  'QCOM': { name: 'Qualcomm', sector: 'Technology' },
  'TXN': { name: 'Texas Instruments', sector: 'Technology' },
  'LOW': { name: "Lowe's", sector: 'Consumer' },
  'UPS': { name: 'UPS', sector: 'Industrial' },
  'NEE': { name: 'NextEra Energy', sector: 'Utilities' },
  'HON': { name: 'Honeywell', sector: 'Industrial' },
  'IBM': { name: 'IBM', sector: 'Technology' },
  'RTX': { name: 'RTX Corp.', sector: 'Industrial' },
  'BA': { name: 'Boeing', sector: 'Industrial' },
  'CAT': { name: 'Caterpillar', sector: 'Industrial' },
  'GS': { name: 'Goldman Sachs', sector: 'Financial' },
  'AXP': { name: 'American Express', sector: 'Financial' },
  'SPGI': { name: 'S&P Global', sector: 'Financial' },
  'BLK': { name: 'BlackRock', sector: 'Financial' },
};

// ==================== DATA TYPES ====================

export interface StockData {
  symbol: string;
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  adjClose: number;
}

export interface PredictionFactors {
  // Value factors
  valueScore: number;           // Distance from 52w low relative to range
  meanReversionScore: number;   // Potential for mean reversion

  // Quality factors
  earningsStability: number;    // Consistency of returns
  trendQuality: number;         // R-squared of price trend

  // Momentum factors
  momentum12m: number;          // 12-month momentum
  momentum6m: number;           // 6-month momentum
  momentum3m: number;           // 3-month momentum

  // Trend factors
  trendStrength: number;        // ADX-based trend strength
  priceAboveSMA200: boolean;    // Above 200-day SMA
  smaSlope: number;             // Slope of 200-day SMA

  // Volatility factors
  volatility: number;           // Annualized volatility
  volatilityRank: number;       // Percentile rank of volatility

  // Technical factors
  rsi: number;                  // RSI (14-day)
  higherHighsLows: number;      // Pattern score
}

export interface StockPrediction {
  symbol: string;
  name: string;
  sector: string;
  currentPrice: number;

  // Probability scores (0-100)
  prob1Year: number;      // Probability of being higher in 1 year
  prob3Year: number;      // Probability of being higher in 3 years
  prob5Year: number;      // Probability of being higher in 5 years

  // Expected returns
  expected1Year: number;  // Expected 1-year return %
  expected3Year: number;  // Expected 3-year total return %
  expected5Year: number;  // Expected 5-year total return %

  // Composite score
  compositeScore: number; // 0-100 overall score

  // Signal
  signal: 'STRONG_BUY' | 'BUY' | 'HOLD' | 'AVOID';
  confidence: number;     // 0-100

  // Risk metrics
  volatility: number;
  maxDrawdown: number;

  // Factor breakdown
  factors: PredictionFactors;
}

export interface BacktestPeriod {
  signalDate: string;
  evaluationDate1Y: string;
  evaluationDate3Y: string;
  evaluationDate5Y: string;
  topPicks: string[];
  actualReturns1Y: number[];
  actualReturns3Y: number[];
  actualReturns5Y: number[];
  spyReturn1Y: number;
  spyReturn3Y: number;
  spyReturn5Y: number;
  hitRate1Y: number;  // % of picks that went up
  hitRate3Y: number;
  hitRate5Y: number;
  beatMarket1Y: number; // % of picks that beat SPY
  beatMarket3Y: number;
  beatMarket5Y: number;
}

export interface BacktestSummary {
  // Overall accuracy
  avgHitRate1Y: number;     // % of predictions that were correct (stock went up)
  avgHitRate3Y: number;
  avgHitRate5Y: number;

  // Market-relative performance
  avgBeatMarket1Y: number;  // % of picks that beat S&P 500
  avgBeatMarket3Y: number;
  avgBeatMarket5Y: number;

  // Return metrics
  avgReturn1Y: number;      // Average return of top picks
  avgReturn3Y: number;
  avgReturn5Y: number;
  avgSpyReturn1Y: number;   // Average SPY return for comparison
  avgSpyReturn3Y: number;
  avgSpyReturn5Y: number;

  // Alpha (outperformance)
  alpha1Y: number;
  alpha3Y: number;
  alpha5Y: number;

  // Statistical measures
  winRate: number;          // Overall win rate
  sharpeRatio: number;
  maxDrawdown: number;
  totalPeriods: number;
}

// ==================== DATA FETCHING ====================

const YAHOO_CHART_API = 'https://query1.finance.yahoo.com/v8/finance/chart';

export async function fetchStockData(
  symbol: string,
  period: '2y' | '5y' | '10y' = '5y'
): Promise<StockData[]> {
  try {
    const url = `${YAHOO_CHART_API}/${symbol}?interval=1d&range=${period}`;

    const response = await fetch(url, {
      headers: { 'User-Agent': 'Mozilla/5.0' },
    });

    if (!response.ok) {
      throw new Error(`HTTP error: ${response.status}`);
    }

    const data = await response.json();

    if (data.chart.error || !data.chart.result?.[0]) {
      throw new Error(`API error: ${data.chart.error?.description || 'No data'}`);
    }

    const result = data.chart.result[0];
    const timestamps = result.timestamp || [];
    const quotes = result.indicators.quote[0];
    const adjClose = result.indicators.adjclose?.[0]?.adjclose || quotes.close;

    const stockData: StockData[] = [];

    for (let i = 0; i < timestamps.length; i++) {
      if (quotes.close[i] != null && quotes.close[i] > 0) {
        stockData.push({
          symbol,
          date: new Date(timestamps[i] * 1000).toISOString().split('T')[0],
          open: quotes.open[i] || quotes.close[i],
          high: quotes.high[i] || quotes.close[i],
          low: quotes.low[i] || quotes.close[i],
          close: quotes.close[i],
          volume: quotes.volume[i] || 0,
          adjClose: adjClose[i] || quotes.close[i],
        });
      }
    }

    return stockData;
  } catch (error) {
    console.error(`Error fetching ${symbol}:`, error);
    return [];
  }
}

export async function fetchAllStocksData(
  symbols: string[] = PREDICTION_UNIVERSE,
  period: '2y' | '5y' | '10y' = '5y'
): Promise<Map<string, StockData[]>> {
  const dataMap = new Map<string, StockData[]>();

  const batchSize = 5;
  for (let i = 0; i < symbols.length; i += batchSize) {
    const batch = symbols.slice(i, i + batchSize);
    const results = await Promise.all(
      batch.map(symbol => fetchStockData(symbol, period))
    );

    batch.forEach((symbol, idx) => {
      if (results[idx].length > 0) {
        dataMap.set(symbol, results[idx]);
      }
    });

    if (i + batchSize < symbols.length) {
      await new Promise(resolve => setTimeout(resolve, 300));
    }
  }

  return dataMap;
}

// ==================== FACTOR CALCULATIONS ====================

function calculateReturns(prices: number[]): number[] {
  const returns: number[] = [];
  for (let i = 1; i < prices.length; i++) {
    if (prices[i - 1] > 0) {
      returns.push((prices[i] - prices[i - 1]) / prices[i - 1]);
    }
  }
  return returns;
}

function mean(arr: number[]): number {
  if (arr.length === 0) return 0;
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

function std(arr: number[]): number {
  if (arr.length < 2) return 0;
  const avg = mean(arr);
  const variance = arr.map(x => Math.pow(x - avg, 2)).reduce((a, b) => a + b, 0) / arr.length;
  return Math.sqrt(variance);
}

function calculateSMA(prices: number[], period: number): number[] {
  const result: number[] = [];
  for (let i = period - 1; i < prices.length; i++) {
    const sum = prices.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
    result.push(sum / period);
  }
  return result;
}

function calculateRSI(prices: number[], period: number = 14): number {
  if (prices.length < period + 1) return 50;

  const gains: number[] = [];
  const losses: number[] = [];

  for (let i = 1; i < prices.length; i++) {
    const change = prices[i] - prices[i - 1];
    gains.push(Math.max(0, change));
    losses.push(Math.max(0, -change));
  }

  let avgGain = mean(gains.slice(0, period));
  let avgLoss = mean(losses.slice(0, period));

  for (let i = period; i < gains.length; i++) {
    avgGain = (avgGain * (period - 1) + gains[i]) / period;
    avgLoss = (avgLoss * (period - 1) + losses[i]) / period;
  }

  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
}

function calculateMaxDrawdown(prices: number[]): number {
  let peak = prices[0];
  let maxDD = 0;

  for (const price of prices) {
    if (price > peak) peak = price;
    const dd = (peak - price) / peak;
    if (dd > maxDD) maxDD = dd;
  }

  return maxDD * 100;
}

function calculateTrendSlope(prices: number[], period: number): { slope: number; rSquared: number } {
  if (prices.length < period) return { slope: 0, rSquared: 0 };

  const y = prices.slice(-period);
  const x = Array.from({ length: period }, (_, i) => i);

  const xMean = mean(x);
  const yMean = mean(y);

  let numerator = 0;
  let denomX = 0;
  let denomY = 0;

  for (let i = 0; i < period; i++) {
    const xDiff = x[i] - xMean;
    const yDiff = y[i] - yMean;
    numerator += xDiff * yDiff;
    denomX += xDiff * xDiff;
    denomY += yDiff * yDiff;
  }

  const slope = denomX > 0 ? numerator / denomX : 0;
  const correlation = denomX > 0 && denomY > 0 ? numerator / Math.sqrt(denomX * denomY) : 0;
  const rSquared = correlation * correlation;

  // Normalize slope to percentage per day
  const normalizedSlope = (slope / yMean) * 100;

  return { slope: normalizedSlope, rSquared };
}

function calculateHigherHighsLows(prices: number[]): number {
  if (prices.length < 60) return 50;

  // Find swing highs and lows
  const lookback = 5;
  const highs: number[] = [];
  const lows: number[] = [];

  for (let i = lookback; i < prices.length - lookback; i++) {
    const window = prices.slice(i - lookback, i + lookback + 1);
    const current = prices[i];

    if (current === Math.max(...window)) highs.push(current);
    if (current === Math.min(...window)) lows.push(current);
  }

  // Count higher highs and higher lows in recent period
  let higherHighs = 0;
  let higherLows = 0;
  const recentHighs = highs.slice(-4);
  const recentLows = lows.slice(-4);

  for (let i = 1; i < recentHighs.length; i++) {
    if (recentHighs[i] > recentHighs[i - 1]) higherHighs++;
  }
  for (let i = 1; i < recentLows.length; i++) {
    if (recentLows[i] > recentLows[i - 1]) higherLows++;
  }

  // Score based on pattern
  const total = Math.max(recentHighs.length - 1, 1) + Math.max(recentLows.length - 1, 1);
  const score = ((higherHighs + higherLows) / total) * 100;

  return Math.max(0, Math.min(100, score));
}

function calculateADX(
  highs: number[],
  lows: number[],
  closes: number[],
  period: number = 14
): number {
  if (highs.length < period * 2) return 25;

  const n = Math.min(highs.length, lows.length, closes.length);

  // Calculate True Range and Directional Movement
  const tr: number[] = [];
  const plusDM: number[] = [];
  const minusDM: number[] = [];

  for (let i = 1; i < n; i++) {
    const highDiff = highs[i] - highs[i - 1];
    const lowDiff = lows[i - 1] - lows[i];

    tr.push(Math.max(
      highs[i] - lows[i],
      Math.abs(highs[i] - closes[i - 1]),
      Math.abs(lows[i] - closes[i - 1])
    ));

    plusDM.push(highDiff > lowDiff && highDiff > 0 ? highDiff : 0);
    minusDM.push(lowDiff > highDiff && lowDiff > 0 ? lowDiff : 0);
  }

  if (tr.length < period) return 25;

  // Simple moving average smoothing
  const smoothTR = mean(tr.slice(-period));
  const smoothPlusDM = mean(plusDM.slice(-period));
  const smoothMinusDM = mean(minusDM.slice(-period));

  if (smoothTR === 0) return 25;

  const plusDI = (smoothPlusDM / smoothTR) * 100;
  const minusDI = (smoothMinusDM / smoothTR) * 100;

  const diSum = plusDI + minusDI;
  if (diSum === 0) return 25;

  const dx = (Math.abs(plusDI - minusDI) / diSum) * 100;

  return dx;
}

export function calculatePredictionFactors(
  prices: number[],
  highs: number[],
  lows: number[],
  volumes: number[]
): PredictionFactors {
  const n = prices.length;

  // Calculate returns
  const returns = calculateReturns(prices);

  // Value Score: position within 52-week range
  // Higher score = more value (closer to lows)
  const recent252 = prices.slice(-Math.min(252, n));
  const high52w = Math.max(...recent252);
  const low52w = Math.min(...recent252);
  const range = high52w - low52w;
  const current = prices[n - 1];
  const valueScore = range > 0
    ? (1 - (current - low52w) / range) * 100  // Inverted: low = high value
    : 50;

  // Mean Reversion Score
  // Stocks that have fallen more have more reversion potential (with quality filter)
  const return12m = n >= 252
    ? (prices[n - 1] / prices[n - 252] - 1) * 100
    : 0;
  const meanReversionScore = return12m < 0
    ? Math.min(100, 50 + Math.abs(return12m) * 0.5)  // Fallen stocks get higher score
    : Math.max(0, 50 - return12m * 0.3);  // Rising stocks get lower score

  // Earnings Stability (proxy: return consistency)
  const monthlyReturns: number[] = [];
  for (let i = 21; i < n; i += 21) {
    if (prices[i - 21] > 0) {
      monthlyReturns.push((prices[i] - prices[i - 21]) / prices[i - 21]);
    }
  }
  const returnStd = std(monthlyReturns);
  const earningsStability = Math.max(0, Math.min(100, (1 - returnStd * 10) * 100));

  // Trend Quality (R-squared of linear regression)
  const { slope, rSquared } = calculateTrendSlope(prices, 200);
  const trendQuality = rSquared * 100;

  // Momentum factors
  const momentum12m = n >= 252 ? (prices[n - 1] / prices[n - 252] - 1) * 100 : 0;
  const momentum6m = n >= 126 ? (prices[n - 1] / prices[n - 126] - 1) * 100 : 0;
  const momentum3m = n >= 63 ? (prices[n - 1] / prices[n - 63] - 1) * 100 : 0;

  // Trend Strength (ADX)
  const adx = calculateADX(highs, lows, prices);
  const trendStrength = Math.min(100, adx * 2);  // ADX of 50 = 100 score

  // Price vs SMA200
  const sma200 = calculateSMA(prices, Math.min(200, n - 1));
  const currentSMA200 = sma200[sma200.length - 1] || current;
  const priceAboveSMA200 = current > currentSMA200;

  // SMA Slope (trend direction)
  const smaSlope = sma200.length >= 20
    ? ((sma200[sma200.length - 1] - sma200[sma200.length - 20]) / sma200[sma200.length - 20]) * 100
    : 0;

  // Volatility
  const recentReturns = returns.slice(-60);
  const volatility = std(recentReturns) * Math.sqrt(252) * 100;

  // Volatility rank (lower = better for long-term holding)
  const volatilityRank = volatility > 50 ? 0 :
    volatility > 40 ? 20 :
    volatility > 30 ? 40 :
    volatility > 20 ? 60 :
    volatility > 15 ? 80 : 100;

  // RSI
  const rsi = calculateRSI(prices, 14);

  // Higher Highs/Lows pattern
  const higherHighsLows = calculateHigherHighsLows(prices);

  return {
    valueScore,
    meanReversionScore,
    earningsStability,
    trendQuality,
    momentum12m,
    momentum6m,
    momentum3m,
    trendStrength,
    priceAboveSMA200,
    smaSlope,
    volatility,
    volatilityRank,
    rsi,
    higherHighsLows,
  };
}

// ==================== PROBABILITY MODEL ====================

/**
 * Calculate probability of positive returns over different horizons
 * Based on factor weightings calibrated from historical performance
 */
export function calculateProbabilities(
  factors: PredictionFactors,
  historicalAccuracy: { hit1Y: number; hit3Y: number; hit5Y: number } = { hit1Y: 70, hit3Y: 80, hit5Y: 85 }
): { prob1Y: number; prob3Y: number; prob5Y: number } {
  // Base probabilities from historical market behavior
  // Long-term market tends to go up ~70% of years
  const baseProbability = { '1Y': 65, '3Y': 75, '5Y': 85 };

  // Factor contributions to probability adjustment
  // Positive factors increase probability, negative decrease

  // 1-Year: More momentum-driven
  const momentum1YScore = (
    (factors.momentum3m > 0 ? 5 : -5) +
    (factors.momentum6m > 0 ? 5 : -5) +
    (factors.priceAboveSMA200 ? 8 : -8) +
    (factors.trendStrength > 50 ? 5 : 0) +
    (factors.higherHighsLows > 60 ? 5 : -3) +
    (factors.rsi > 30 && factors.rsi < 70 ? 3 : -3) +
    (factors.volatilityRank > 50 ? 3 : -2)
  );

  // 3-Year: Balanced momentum and value
  const momentum3YScore = (
    (factors.momentum12m > 0 ? 4 : -2) +
    (factors.priceAboveSMA200 ? 6 : -4) +
    (factors.smaSlope > 0 ? 5 : -3) +
    (factors.earningsStability > 50 ? 5 : -3) +
    (factors.trendQuality > 50 ? 4 : -2) +
    (factors.valueScore > 40 ? 3 : 0) +  // Some value helps
    (factors.volatilityRank > 40 ? 4 : -2)
  );

  // 5-Year: More value and quality driven
  const momentum5YScore = (
    (factors.earningsStability > 50 ? 6 : -3) +
    (factors.trendQuality > 40 ? 4 : -2) +
    (factors.valueScore > 50 ? 5 : 0) +  // Value matters more
    (factors.meanReversionScore > 50 ? 3 : 0) +
    (factors.volatilityRank > 30 ? 4 : -1) +
    (factors.smaSlope > -5 ? 3 : -2) +
    (factors.priceAboveSMA200 ? 2 : -1)
  );

  // Calculate final probabilities, bounded 20-95%
  const prob1Y = Math.max(20, Math.min(95, baseProbability['1Y'] + momentum1YScore));
  const prob3Y = Math.max(25, Math.min(95, baseProbability['3Y'] + momentum3YScore));
  const prob5Y = Math.max(30, Math.min(95, baseProbability['5Y'] + momentum5YScore));

  return { prob1Y, prob3Y, prob5Y };
}

/**
 * Calculate expected returns based on factors and probabilities
 */
export function calculateExpectedReturns(
  factors: PredictionFactors,
  prob: { prob1Y: number; prob3Y: number; prob5Y: number }
): { expected1Y: number; expected3Y: number; expected5Y: number } {
  // Base expected returns (historical market averages)
  const baseReturn = { '1Y': 10, '3Y': 35, '5Y': 65 };

  // Adjust based on momentum and quality
  const momentumAdj1Y = factors.momentum6m * 0.15;
  const momentumAdj3Y = factors.momentum12m * 0.1;

  // Quality premium
  const qualityPremium = (factors.earningsStability - 50) * 0.1;

  // Volatility discount (higher vol = more uncertainty)
  const volDiscount = (factors.volatility - 25) * -0.2;

  // Calculate expected returns weighted by probability
  const expected1Y = baseReturn['1Y'] + momentumAdj1Y + qualityPremium * 0.5 + volDiscount * 0.3;
  const expected3Y = baseReturn['3Y'] + momentumAdj3Y + qualityPremium * 1.5 + volDiscount * 0.5;
  const expected5Y = baseReturn['5Y'] + qualityPremium * 2.5 + volDiscount * 0.3;

  // Probability-weight the returns
  const weightedExp1Y = expected1Y * (prob.prob1Y / 100) - Math.abs(expected1Y) * 0.5 * ((100 - prob.prob1Y) / 100);
  const weightedExp3Y = expected3Y * (prob.prob3Y / 100) - Math.abs(expected3Y) * 0.3 * ((100 - prob.prob3Y) / 100);
  const weightedExp5Y = expected5Y * (prob.prob5Y / 100) - Math.abs(expected5Y) * 0.2 * ((100 - prob.prob5Y) / 100);

  return {
    expected1Y: Math.round(weightedExp1Y * 10) / 10,
    expected3Y: Math.round(weightedExp3Y * 10) / 10,
    expected5Y: Math.round(weightedExp5Y * 10) / 10,
  };
}

/**
 * Calculate composite score for stock selection
 */
export function calculateCompositeScore(
  factors: PredictionFactors,
  prob: { prob1Y: number; prob3Y: number; prob5Y: number }
): number {
  // Weight different time horizons (favor longer term)
  const probScore = prob.prob1Y * 0.2 + prob.prob3Y * 0.35 + prob.prob5Y * 0.45;

  // Quality adjustments
  const qualityAdj =
    factors.earningsStability * 0.15 +
    factors.trendQuality * 0.1 +
    factors.volatilityRank * 0.1;

  // Momentum confirmation
  const momentumAdj =
    (factors.momentum12m > 0 ? 5 : 0) +
    (factors.priceAboveSMA200 ? 5 : 0) +
    (factors.higherHighsLows > 60 ? 3 : 0);

  return Math.max(0, Math.min(100, probScore * 0.65 + qualityAdj * 0.25 + momentumAdj));
}

/**
 * Determine signal based on score and factors
 */
export function determineSignal(
  score: number,
  factors: PredictionFactors,
  prob: { prob1Y: number; prob3Y: number; prob5Y: number }
): { signal: 'STRONG_BUY' | 'BUY' | 'HOLD' | 'AVOID'; confidence: number } {
  // Key factor checks
  const isQualityHigh = factors.earningsStability > 60;
  const isTrendPositive = factors.priceAboveSMA200 && factors.smaSlope > 0;
  const isProbabilityHigh = prob.prob3Y > 75 && prob.prob5Y > 80;
  const isLowVol = factors.volatility < 30;

  let signal: 'STRONG_BUY' | 'BUY' | 'HOLD' | 'AVOID';
  let confidence: number;

  if (score >= 75 && isProbabilityHigh && isQualityHigh) {
    signal = 'STRONG_BUY';
    confidence = Math.min(95, score + 10);
  } else if (score >= 65 && (isProbabilityHigh || (isTrendPositive && isQualityHigh))) {
    signal = 'BUY';
    confidence = Math.min(85, score + 5);
  } else if (score >= 50 && prob.prob3Y > 60) {
    signal = 'HOLD';
    confidence = score;
  } else {
    signal = 'AVOID';
    confidence = Math.max(30, 100 - score);
  }

  return { signal, confidence };
}

// ==================== MAIN PREDICTION FUNCTION ====================

export async function getStockPredictions(): Promise<StockPrediction[]> {
  const allSymbols = [...PREDICTION_UNIVERSE, 'SPY'];
  const dataMap = await fetchAllStocksData(allSymbols, '5y');

  const predictions: StockPrediction[] = [];

  for (const symbol of PREDICTION_UNIVERSE) {
    const stockData = dataMap.get(symbol);
    if (!stockData || stockData.length < 252) continue;

    const prices = stockData.map(d => d.adjClose);
    const highs = stockData.map(d => d.high);
    const lows = stockData.map(d => d.low);
    const volumes = stockData.map(d => d.volume);

    const currentPrice = prices[prices.length - 1];
    const info = STOCK_INFO[symbol] || { name: symbol, sector: 'Unknown' };

    // Calculate factors
    const factors = calculatePredictionFactors(prices, highs, lows, volumes);

    // Calculate probabilities
    const prob = calculateProbabilities(factors);

    // Calculate expected returns
    const expected = calculateExpectedReturns(factors, prob);

    // Calculate composite score
    const compositeScore = calculateCompositeScore(factors, prob);

    // Determine signal
    const { signal, confidence } = determineSignal(compositeScore, factors, prob);

    // Risk metrics
    const maxDrawdown = calculateMaxDrawdown(prices.slice(-252));

    predictions.push({
      symbol,
      name: info.name,
      sector: info.sector,
      currentPrice,
      prob1Year: Math.round(prob.prob1Y),
      prob3Year: Math.round(prob.prob3Y),
      prob5Year: Math.round(prob.prob5Y),
      expected1Year: expected.expected1Y,
      expected3Year: expected.expected3Y,
      expected5Year: expected.expected5Y,
      compositeScore: Math.round(compositeScore),
      signal,
      confidence: Math.round(confidence),
      volatility: Math.round(factors.volatility * 10) / 10,
      maxDrawdown: Math.round(maxDrawdown * 10) / 10,
      factors,
    });
  }

  // Sort by composite score
  predictions.sort((a, b) => b.compositeScore - a.compositeScore);

  return predictions;
}

export async function getTopPredictions(n: number = 5): Promise<StockPrediction[]> {
  const predictions = await getStockPredictions();
  return predictions
    .filter(p => p.signal === 'STRONG_BUY' || p.signal === 'BUY')
    .slice(0, n);
}
