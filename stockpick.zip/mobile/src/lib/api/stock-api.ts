/**
 * Stock API Service - Multi-Factor Alpha Strategy
 *
 * Uses Alpha Vantage for real-time quotes and historical daily data
 * Falls back to Yahoo Finance for bulk historical data (due to rate limits)
 */

import {
  StockData,
  AlphaScore,
  FactorScores,
  BacktestResult,
  BacktestSummary,
  MarketRegime,
  STOCK_UNIVERSE,
  STOCK_NAMES,
  calculateReturns,
  calculateMomentum,
  calculateValueScore,
  calculateQualityScore,
  calculateLowVolScore,
  calculateTrendScore,
  calculateRelativeStrength,
  calculateBeta,
  calculateMaxDrawdown,
  calculateSharpeRatio,
  detectMarketRegime,
  getFactorWeights,
  calculateAlphaScore,
  getSignal,
  calculateExpectedReturn,
  calculateConviction,
} from './stock-model';

import {
  calculate52WeekHighScore,
  calculateVolumeAccumulationScore,
  calculateADXScore,
  calculateRSITrendScore,
  calculateHigherLowsScore,
  calculateBreakoutScore,
  calculateVolatilityRegimeScore,
  calculateEarningsMomentumScore,
  calculateSectorStrength,
  calculateAlphaScoreV2,
  AlphaFactorsV2,
  SECTOR_MAP,
} from './alpha-model-v2';

const ALPHA_VANTAGE_BASE = 'https://www.alphavantage.co/query';
const ALPHA_VANTAGE_API_KEY = process.env.EXPO_PUBLIC_VIBECODE_ALPHA_VANTAGE_API_KEY;

// Yahoo Finance as fallback for bulk data
const YAHOO_CHART_API = 'https://query1.finance.yahoo.com/v8/finance/chart';

interface AlphaVantageTimeSeries {
  'Time Series (Daily)': {
    [date: string]: {
      '1. open': string;
      '2. high': string;
      '3. low': string;
      '4. close': string;
      '5. volume': string;
    };
  };
}

interface AlphaVantageQuote {
  'Global Quote': {
    '01. symbol': string;
    '02. open': string;
    '03. high': string;
    '04. low': string;
    '05. price': string;
    '06. volume': string;
    '07. latest trading day': string;
    '08. previous close': string;
    '09. change': string;
    '10. change percent': string;
  };
}

// Utility functions
function mean(arr: number[]): number {
  if (arr.length === 0) return 0;
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

function std(arr: number[]): number {
  if (arr.length < 2) return 0;
  const avg = mean(arr);
  const variance = arr.map(x => Math.pow(x - avg, 2)).reduce((a, b) => a + b, 0) / arr.length;
  return Math.sqrt(variance);
}

function zScore(value: number, values: number[]): number {
  const avg = mean(values);
  const stdDev = std(values);
  if (stdDev === 0) return 0;
  return Math.max(-3, Math.min(3, (value - avg) / stdDev));
}

/**
 * Fetch historical stock data from Alpha Vantage
 */
export async function fetchStockDataAlphaVantage(
  symbol: string,
  outputSize: 'compact' | 'full' = 'full'
): Promise<StockData[]> {
  try {
    const url = `${ALPHA_VANTAGE_BASE}?function=TIME_SERIES_DAILY&symbol=${symbol}&outputsize=${outputSize}&apikey=${ALPHA_VANTAGE_API_KEY}`;

    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`Alpha Vantage API error: ${response.status}`);
    }

    const data: AlphaVantageTimeSeries = await response.json();

    if (!data['Time Series (Daily)']) {
      console.warn(`Alpha Vantage: No data for ${symbol}, may be rate limited`);
      return [];
    }

    const timeSeries = data['Time Series (Daily)'];
    const stockData: StockData[] = Object.entries(timeSeries)
      .map(([date, values]) => ({
        symbol,
        date,
        open: parseFloat(values['1. open']),
        high: parseFloat(values['2. high']),
        low: parseFloat(values['3. low']),
        close: parseFloat(values['4. close']),
        volume: parseInt(values['5. volume']),
        adjClose: parseFloat(values['4. close']),
      }))
      .sort((a, b) => a.date.localeCompare(b.date));

    return stockData;
  } catch (error) {
    console.error(`Error fetching Alpha Vantage data for ${symbol}:`, error);
    return [];
  }
}

/**
 * Fetch real-time quote from Alpha Vantage
 */
export async function fetchQuoteAlphaVantage(symbol: string): Promise<{
  price: number;
  change: number;
  changePercent: string;
} | null> {
  try {
    const url = `${ALPHA_VANTAGE_BASE}?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${ALPHA_VANTAGE_API_KEY}`;

    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`Alpha Vantage API error: ${response.status}`);
    }

    const data: AlphaVantageQuote = await response.json();

    if (!data['Global Quote'] || !data['Global Quote']['05. price']) {
      return null;
    }

    const quote = data['Global Quote'];
    return {
      price: parseFloat(quote['05. price']),
      change: parseFloat(quote['09. change']),
      changePercent: quote['10. change percent'],
    };
  } catch (error) {
    console.error(`Error fetching Alpha Vantage quote for ${symbol}:`, error);
    return null;
  }
}

/**
 * Fetch historical stock data from Yahoo Finance
 */
export async function fetchStockDataYahoo(
  symbol: string,
  period: '1mo' | '3mo' | '6mo' | '1y' | '2y' | '5y' = '2y'
): Promise<StockData[]> {
  try {
    const url = `${YAHOO_CHART_API}/${symbol}?interval=1d&range=${period}`;

    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0',
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();

    if (data.chart.error || !data.chart.result?.[0]) {
      throw new Error(`Yahoo API error: ${data.chart.error?.description || 'No data'}`);
    }

    const result = data.chart.result[0];
    const timestamps = result.timestamp || [];
    const quotes = result.indicators.quote[0];
    const adjClose = result.indicators.adjclose?.[0]?.adjclose || quotes.close;

    const stockData: StockData[] = [];

    for (let i = 0; i < timestamps.length; i++) {
      if (quotes.close[i] != null) {
        stockData.push({
          symbol,
          date: new Date(timestamps[i] * 1000).toISOString().split('T')[0],
          open: quotes.open[i] || 0,
          high: quotes.high[i] || 0,
          low: quotes.low[i] || 0,
          close: quotes.close[i],
          volume: quotes.volume[i] || 0,
          adjClose: adjClose[i] || quotes.close[i],
        });
      }
    }

    return stockData;
  } catch (error) {
    console.error(`Error fetching Yahoo data for ${symbol}:`, error);
    return [];
  }
}

/**
 * Fetch stock data - tries Alpha Vantage first, falls back to Yahoo
 */
export async function fetchStockData(
  symbol: string,
  useAlphaVantage: boolean = false
): Promise<StockData[]> {
  if (useAlphaVantage && ALPHA_VANTAGE_API_KEY) {
    const data = await fetchStockDataAlphaVantage(symbol, 'full');
    if (data.length > 0) return data;
  }

  return fetchStockDataYahoo(symbol, '2y');
}

/**
 * Fetch data for all stocks
 */
export async function fetchAllStocksData(
  symbols: string[] = STOCK_UNIVERSE
): Promise<Map<string, StockData[]>> {
  const dataMap = new Map<string, StockData[]>();

  const batchSize = 5;
  for (let i = 0; i < symbols.length; i += batchSize) {
    const batch = symbols.slice(i, i + batchSize);
    const results = await Promise.all(
      batch.map(symbol => fetchStockDataYahoo(symbol, '2y'))
    );

    batch.forEach((symbol, index) => {
      if (results[index].length > 0) {
        dataMap.set(symbol, results[index]);
      }
    });

    if (i + batchSize < symbols.length) {
      await new Promise(resolve => setTimeout(resolve, 300));
    }
  }

  return dataMap;
}

/**
 * Calculate factor scores for a single stock
 */
function calculateFactorScoresForStock(
  prices: number[],
  marketPrices: number[]
): FactorScores {
  const momentum12m = calculateMomentum(prices, 12, 1) / 100; // z-score scale
  const momentum6m = calculateMomentum(prices, 6, 0) / 100;
  const momentum1m = calculateMomentum(prices, 1, 0) / 100;
  const valueScore = calculateValueScore(prices);
  const qualityScore = calculateQualityScore(prices);
  const lowVolScore = calculateLowVolScore(prices);
  const trendScore = calculateTrendScore(prices);
  const relStrength = calculateRelativeStrength(prices, marketPrices, 63);

  return {
    momentum12m,
    momentum6m,
    momentum1m,
    valueScore,
    qualityScore,
    lowVolScore,
    trendScore,
    relStrength,
  };
}

/**
 * Calculate alpha scores for all stocks using Proprietary Model V2
 */
export async function getStockScores(): Promise<AlphaScore[]> {
  const allSymbols = [...STOCK_UNIVERSE, 'SPY'];
  const dataMap = await fetchAllStocksData(allSymbols);

  const spyData = dataMap.get('SPY') || [];
  const spyPrices = spyData.map(d => d.adjClose);
  const spyReturns = calculateReturns(spyPrices);

  // Detect market regime
  const regime = detectMarketRegime(spyPrices);
  const weights = getFactorWeights(regime);

  const scores: AlphaScore[] = [];

  // Calculate 1-month returns for all stocks (for sector strength calculation)
  const allStockReturns: Map<string, number> = new Map();
  for (const symbol of STOCK_UNIVERSE) {
    const stockData = dataMap.get(symbol);
    if (!stockData || stockData.length < 21) continue;

    const prices = stockData.map(d => d.adjClose);
    const startPrice = prices[prices.length - 22] || prices[0];
    const endPrice = prices[prices.length - 1];
    if (startPrice > 0) {
      allStockReturns.set(symbol, (endPrice - startPrice) / startPrice);
    }
  }

  // First pass: calculate raw factors for cross-sectional normalization
  const allFactors: Map<string, FactorScores> = new Map();
  const allProprietaryFactors: Map<string, AlphaFactorsV2> = new Map();
  const allMomentum12m: number[] = [];
  const allMomentum6m: number[] = [];
  const allRelStrength: number[] = [];

  for (const symbol of STOCK_UNIVERSE) {
    const stockData = dataMap.get(symbol);
    if (!stockData || stockData.length < 252) continue;

    const prices = stockData.map(d => d.adjClose);
    const highs = stockData.map(d => d.high);
    const lows = stockData.map(d => d.low);
    const volumes = stockData.map(d => d.volume);

    // Legacy factors for display
    const factors = calculateFactorScoresForStock(prices, spyPrices);
    allFactors.set(symbol, factors);
    allMomentum12m.push(factors.momentum12m);
    allMomentum6m.push(factors.momentum6m);
    allRelStrength.push(factors.relStrength);

    // Proprietary V2 factors
    const propFactors = calculateProprietaryFactors(
      prices, highs, lows, volumes, allStockReturns, symbol
    );
    allProprietaryFactors.set(symbol, propFactors);
  }

  // Second pass: calculate final scores
  for (const symbol of STOCK_UNIVERSE) {
    const stockData = dataMap.get(symbol);
    if (!stockData || stockData.length < 252) continue;

    const factors = allFactors.get(symbol);
    const propFactors = allProprietaryFactors.get(symbol);
    if (!factors || !propFactors) continue;

    const prices = stockData.map(d => d.adjClose);
    const stockReturns = calculateReturns(prices);
    const currentPrice = prices[prices.length - 1];

    // Z-normalize momentum factors for display
    const normalizedFactors: FactorScores = {
      ...factors,
      momentum12m: zScore(factors.momentum12m, allMomentum12m),
      momentum6m: zScore(factors.momentum6m, allMomentum6m),
      relStrength: zScore(factors.relStrength, allRelStrength),
    };

    // Calculate composites using legacy factors for display
    const momentumComposite = normalizedFactors.momentum12m * 0.6 + normalizedFactors.momentum6m * 0.3;
    const qualityValue = (normalizedFactors.qualityScore + normalizedFactors.valueScore) / 2;
    const riskAdjusted = (normalizedFactors.lowVolScore + normalizedFactors.qualityScore) / 2;

    // Use Proprietary V2 model for alpha score and signal
    const { score: alphaScore, signal, confidence } = calculateAlphaScoreV2(propFactors);

    // Risk metrics
    const volatility = std(stockReturns.slice(-63)) * Math.sqrt(252) * 100;
    const beta = calculateBeta(stockReturns, spyReturns);
    const maxDrawdown = calculateMaxDrawdown(prices.slice(-252));
    const sharpeRatio = calculateSharpeRatio(stockReturns.slice(-252));

    // Expected return based on proprietary factors
    const expectedReturn = calculateExpectedReturnV2(propFactors, regime);

    scores.push({
      symbol,
      name: STOCK_NAMES[symbol] || symbol,
      currentPrice,
      factors: normalizedFactors,
      momentumComposite,
      qualityValue,
      riskAdjusted,
      alphaScore,
      regimeScore: regime.score,
      regimeType: regime.type,
      volatility,
      beta,
      maxDrawdown,
      sharpeRatio,
      signal,
      conviction: confidence,
      expectedReturn,
    });
  }

  // Sort by alpha score (descending)
  scores.sort((a, b) => b.alphaScore - a.alphaScore);

  return scores;
}

/**
 * Calculate expected return using V2 model
 */
function calculateExpectedReturnV2(
  factors: AlphaFactorsV2,
  regime: MarketRegime
): number {
  // Base expected return from proprietary factors
  const high52wContrib = (factors.highScore52w - 50) * 0.3;
  const breakoutContrib = (factors.breakout - 50) * 0.2;
  const adxContrib = (factors.adxTrend - 50) * 0.15;
  const volRegimeAdj = factors.volRegime > 60 ? 1.1 : (factors.volRegime < 40 ? 0.8 : 1.0);

  const rawExpected = (high52wContrib + breakoutContrib + adxContrib) * volRegimeAdj;

  // Regime adjustment
  const regimeAdj = regime.type === 'BULL' ? 1.3 : (regime.type === 'BEAR' ? 0.6 : 1.0);

  return Math.max(-15, Math.min(25, rawExpected * regimeAdj / 10));
}

/**
 * Get top N stock recommendations with real-time prices
 */
export async function getTopRecommendations(n: number = 3): Promise<AlphaScore[]> {
  const scores = await getStockScores();

  // Filter for actionable signals
  const candidates = scores.filter(s =>
    s.signal === 'STRONG_BUY' || s.signal === 'BUY'
  );

  // If not enough buy signals, take top by alpha score
  const topPicks = candidates.length >= n
    ? candidates.slice(0, n)
    : scores.slice(0, n);

  // Get real-time prices from Alpha Vantage
  if (ALPHA_VANTAGE_API_KEY) {
    for (let i = 0; i < topPicks.length; i++) {
      if (i > 0) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }

      const quote = await fetchQuoteAlphaVantage(topPicks[i].symbol);
      if (quote) {
        topPicks[i].currentPrice = quote.price;
      }
    }
  }

  return topPicks;
}

/**
 * Calculate proprietary V2 factors for a stock
 */
function calculateProprietaryFactors(
  prices: number[],
  highs: number[],
  lows: number[],
  volumes: number[],
  allStockReturns: Map<string, number>,
  symbol: string
): AlphaFactorsV2 {
  return {
    highScore52w: calculate52WeekHighScore(prices),
    volumeAccum: calculateVolumeAccumulationScore(prices, volumes),
    adxTrend: calculateADXScore(highs, lows, prices, 14),
    rsiTrend: calculateRSITrendScore(prices),
    higherLows: calculateHigherLowsScore(prices),
    breakout: calculateBreakoutScore(prices, volumes),
    volRegime: calculateVolatilityRegimeScore(prices),
    earningsMomentum: calculateEarningsMomentumScore(prices),
    sectorStrength: calculateSectorStrength(symbol, allStockReturns),
  };
}

/**
 * Run comprehensive backtest using Proprietary Alpha Model V2
 *
 * Key improvements:
 * 1. 52-week high proximity (George & Hwang factor)
 * 2. Volume accumulation detection
 * 3. ADX trend strength filter
 * 4. RSI mean-reversion with trend confirmation
 * 5. Higher lows pattern recognition
 * 6. Breakout confirmation
 * 7. Volatility regime filter
 * 8. Earnings momentum proxy
 * 9. Sector rotation
 */
export async function runBacktest(): Promise<{
  results: BacktestResult[];
  summary: BacktestSummary;
}> {
  const allSymbols = [...STOCK_UNIVERSE, 'SPY'];
  const dataMap = await fetchAllStocksData(allSymbols);

  const spyData = dataMap.get('SPY') || [];

  if (spyData.length < 252) {
    throw new Error('Insufficient data for backtesting');
  }

  // Store full daily data for each symbol
  interface DailyData {
    prices: number[];
    highs: number[];
    lows: number[];
    volumes: number[];
    dates: string[];
  }

  const fullData: Map<string, DailyData> = new Map();

  for (const [symbol, data] of dataMap.entries()) {
    fullData.set(symbol, {
      prices: data.map(d => d.adjClose),
      highs: data.map(d => d.high),
      lows: data.map(d => d.low),
      volumes: data.map(d => d.volume),
      dates: data.map(d => d.date),
    });
  }

  // Get unique months
  const allDates = spyData.map(d => d.date);
  const monthEndDates: string[] = [];
  let currentMonth = '';

  for (let i = 0; i < allDates.length; i++) {
    const month = allDates[i].substring(0, 7);
    if (month !== currentMonth) {
      if (currentMonth !== '' && i > 0) {
        monthEndDates.push(allDates[i - 1]);
      }
      currentMonth = month;
    }
  }
  // Add last date
  if (allDates.length > 0) {
    monthEndDates.push(allDates[allDates.length - 1]);
  }

  const results: BacktestResult[] = [];
  const backtestStartIdx = 12; // Need 12 months of history

  let cumulativeModelReturn = 0;
  let cumulativeSp500Return = 0;
  let wins = 0;
  let losses = 0;
  let totalWinReturn = 0;
  let totalLossReturn = 0;
  let outperformancePeriods = 0;
  let maxCumulativeReturn = 0;
  let maxDrawdown = 0;

  const monthlyModelReturns: number[] = [];
  const monthlySpReturns: number[] = [];
  const excessReturns: number[] = [];
  const negativeReturns: number[] = [];

  for (let i = backtestStartIdx; i < monthEndDates.length - 1; i++) {
    const signalDate = monthEndDates[i];
    const evalDate = monthEndDates[i + 1];

    // Find data indices
    const spyFullData = fullData.get('SPY');
    if (!spyFullData) continue;

    const signalIdx = spyFullData.dates.indexOf(signalDate);
    const evalIdx = spyFullData.dates.indexOf(evalDate);

    if (signalIdx < 252 || evalIdx <= signalIdx) continue;

    // Detect market regime
    const spyPricesForRegime = spyFullData.prices.slice(0, signalIdx + 1);
    const regime = detectMarketRegime(spyPricesForRegime);

    // Calculate 1-month returns for all stocks (for sector strength)
    const allStockReturns: Map<string, number> = new Map();
    for (const symbol of STOCK_UNIVERSE) {
      const stockData = fullData.get(symbol);
      if (!stockData || signalIdx >= stockData.prices.length) continue;

      const lookback = Math.min(21, signalIdx);
      const startPrice = stockData.prices[signalIdx - lookback];
      const endPrice = stockData.prices[signalIdx];
      if (startPrice > 0) {
        allStockReturns.set(symbol, (endPrice - startPrice) / startPrice);
      }
    }

    // Calculate proprietary scores for each stock
    const stockScores: Array<{ symbol: string; score: number; signal: string }> = [];

    for (const symbol of STOCK_UNIVERSE) {
      const stockData = fullData.get(symbol);
      if (!stockData || signalIdx >= stockData.prices.length) continue;

      // Get historical data up to signal date
      const prices = stockData.prices.slice(0, signalIdx + 1);
      const highs = stockData.highs.slice(0, signalIdx + 1);
      const lows = stockData.lows.slice(0, signalIdx + 1);
      const volumes = stockData.volumes.slice(0, signalIdx + 1);

      if (prices.length < 252) continue;

      // Calculate proprietary factors
      const factors = calculateProprietaryFactors(
        prices, highs, lows, volumes, allStockReturns, symbol
      );

      const { score, signal } = calculateAlphaScoreV2(factors);

      // Only consider stocks with BUY or STRONG_BUY signals
      if (signal === 'STRONG_BUY' || signal === 'BUY') {
        stockScores.push({ symbol, score, signal });
      }
    }

    // Sort by score and pick top 3
    stockScores.sort((a, b) => b.score - a.score);

    // If not enough buy signals, take top 3 from all stocks
    let topPicks: string[];
    if (stockScores.length >= 3) {
      topPicks = stockScores.slice(0, 3).map(s => s.symbol);
    } else {
      // Fallback: calculate scores for all stocks
      const allScores: Array<{ symbol: string; score: number }> = [];
      for (const symbol of STOCK_UNIVERSE) {
        const stockData = fullData.get(symbol);
        if (!stockData || signalIdx >= stockData.prices.length) continue;

        const prices = stockData.prices.slice(0, signalIdx + 1);
        const highs = stockData.highs.slice(0, signalIdx + 1);
        const lows = stockData.lows.slice(0, signalIdx + 1);
        const volumes = stockData.volumes.slice(0, signalIdx + 1);

        if (prices.length < 252) continue;

        const factors = calculateProprietaryFactors(
          prices, highs, lows, volumes, allStockReturns, symbol
        );
        const { score } = calculateAlphaScoreV2(factors);
        allScores.push({ symbol, score });
      }
      allScores.sort((a, b) => b.score - a.score);
      topPicks = allScores.slice(0, 3).map(s => s.symbol);
    }

    // Calculate forward returns
    let modelReturn = 0;
    let validPicks = 0;

    for (const symbol of topPicks) {
      const stockData = fullData.get(symbol);
      if (!stockData || evalIdx >= stockData.prices.length) continue;

      const startPrice = stockData.prices[signalIdx];
      const endPrice = stockData.prices[evalIdx];

      if (startPrice > 0) {
        const stockReturn = ((endPrice - startPrice) / startPrice) * 100;
        // Apply transaction cost (0.1% round trip)
        const netReturn = stockReturn - 0.1;
        modelReturn += netReturn;
        validPicks++;
      }
    }

    if (validPicks > 0) {
      modelReturn /= validPicks;
    }

    // SPY return
    const spyStart = spyFullData.prices[signalIdx];
    const spyEnd = spyFullData.prices[evalIdx];
    const sp500Return = spyStart > 0 ? ((spyEnd - spyStart) / spyStart) * 100 : 0;

    // Track returns
    monthlyModelReturns.push(modelReturn);
    monthlySpReturns.push(sp500Return);
    excessReturns.push(modelReturn - sp500Return);
    if (modelReturn < 0) negativeReturns.push(modelReturn);

    // Compound returns
    cumulativeModelReturn = (1 + cumulativeModelReturn / 100) * (1 + modelReturn / 100) * 100 - 100;
    cumulativeSp500Return = (1 + cumulativeSp500Return / 100) * (1 + sp500Return / 100) * 100 - 100;

    // Drawdown tracking
    maxCumulativeReturn = Math.max(maxCumulativeReturn, cumulativeModelReturn);
    const drawdown = maxCumulativeReturn - cumulativeModelReturn;
    maxDrawdown = Math.max(maxDrawdown, drawdown);

    // Win/loss tracking
    const excessReturn = modelReturn - sp500Return;
    if (excessReturn > 0) {
      wins++;
      totalWinReturn += excessReturn;
      outperformancePeriods++;
    } else {
      losses++;
      totalLossReturn += Math.abs(excessReturn);
    }

    results.push({
      date: evalDate.substring(0, 7),
      modelReturn,
      sp500Return,
      cumulativeModelReturn,
      cumulativeSp500Return,
      topPicks,
      regime: regime.type,
    });
  }

  // Calculate summary statistics
  const totalPeriods = results.length;
  const years = Math.max(totalPeriods / 12, 0.5);

  const annualizedModelReturn = totalPeriods > 0
    ? Math.pow(1 + cumulativeModelReturn / 100, 1 / years) * 100 - 100
    : 0;
  const annualizedSp500Return = totalPeriods > 0
    ? Math.pow(1 + cumulativeSp500Return / 100, 1 / years) * 100 - 100
    : 0;

  // Sharpe Ratio
  const avgMonthlyReturn = mean(monthlyModelReturns);
  const monthlyStdDev = std(monthlyModelReturns);
  const sharpeRatio = monthlyStdDev > 0
    ? ((avgMonthlyReturn * 12 - 4) / (monthlyStdDev * Math.sqrt(12)))
    : 0;

  // Sortino Ratio
  const downsideDeviation = std(negativeReturns.length > 0 ? negativeReturns : [0]);
  const sortinoRatio = downsideDeviation > 0
    ? ((avgMonthlyReturn * 12 - 4) / (downsideDeviation * Math.sqrt(12)))
    : sharpeRatio;

  // Calmar Ratio
  const calmarRatio = maxDrawdown > 0
    ? annualizedModelReturn / maxDrawdown
    : 0;

  // Information Ratio
  const trackingError = std(excessReturns) * Math.sqrt(12);
  const informationRatio = trackingError > 0
    ? (annualizedModelReturn - annualizedSp500Return) / trackingError
    : 0;

  // Profit Factor
  const profitFactor = totalLossReturn > 0
    ? totalWinReturn / totalLossReturn
    : totalWinReturn > 0 ? 999 : 0;

  const summary: BacktestSummary = {
    totalModelReturn: cumulativeModelReturn,
    totalSp500Return: cumulativeSp500Return,
    annualizedModelReturn,
    annualizedSp500Return,
    alpha: annualizedModelReturn - annualizedSp500Return,
    sharpeRatio,
    sortinoRatio,
    maxDrawdown,
    calmarRatio,
    winRate: totalPeriods > 0 ? (wins / totalPeriods) * 100 : 0,
    avgWin: wins > 0 ? totalWinReturn / wins : 0,
    avgLoss: losses > 0 ? totalLossReturn / losses : 0,
    profitFactor,
    totalTrades: totalPeriods * 3,
    outperformancePeriods,
    totalPeriods,
    informationRatio,
    trackingError,
  };

  return { results, summary };
}
