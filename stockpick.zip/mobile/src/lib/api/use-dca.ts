import { useQuery } from '@tanstack/react-query';
import {
  runDCAComparison,
  getTopDCAPerformers,
  DCAResult,
  DCAComparisonSummary,
} from './dca-engine';

/**
 * Hook to fetch DCA comparison results
 */
export function useDCAComparison(monthlyAmount: number = 500) {
  return useQuery<{ results: DCAResult[]; summary: DCAComparisonSummary }>({
    queryKey: ['dca-comparison', monthlyAmount],
    queryFn: () => runDCAComparison(monthlyAmount, '2y'),
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 30 * 60 * 1000,   // 30 minutes
  });
}

/**
 * Hook to fetch top DCA performers
 */
export function useTopDCAPerformers(monthlyAmount: number = 500, limit: number = 5) {
  return useQuery<DCAResult[]>({
    queryKey: ['dca-top-performers', monthlyAmount, limit],
    queryFn: () => getTopDCAPerformers(monthlyAmount, limit),
    staleTime: 5 * 60 * 1000,
    gcTime: 30 * 60 * 1000,
  });
}
