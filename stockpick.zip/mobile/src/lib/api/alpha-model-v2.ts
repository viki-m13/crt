/**
 * Proprietary Alpha Model v2
 *
 * Focuses on signals with empirically-proven edge:
 * 1. 52-Week High Breakout - Stocks at/near new highs continue outperforming
 * 2. Volume Accumulation - Institutional buying patterns
 * 3. Trend Strength (ADX) - Strong trends persist
 * 4. RSI Mean Reversion - Oversold bounces in uptrends
 * 5. Price Pattern - Higher lows + breakout confirmation
 * 6. Sector Rotation - Favor strong sectors
 * 7. Volatility Regime - Avoid vol expansion
 */

import {
  StockData,
  calculateReturns,
  calculateMaxDrawdown,
} from './stock-model';

// ==================== PROPRIETARY SIGNALS ====================

/**
 * 52-Week High Proximity Score
 * Stocks within 5% of 52-week high have strong momentum continuation
 * Research: George & Hwang (2004) - Near 52-week high predicts returns
 */
export function calculate52WeekHighScore(prices: number[]): number {
  if (prices.length < 252) return 50;

  const recent252 = prices.slice(-252);
  const high52w = Math.max(...recent252);
  const current = prices[prices.length - 1];

  if (high52w === 0) return 50;

  const distanceFromHigh = (current - high52w) / high52w; // -1 to 0

  // Score: At high = 100, 5% below = 80, 10% below = 60, etc.
  // Key insight: Being NEAR the high is bullish, not bearish
  if (distanceFromHigh >= -0.02) return 100; // Within 2% of high
  if (distanceFromHigh >= -0.05) return 90;  // Within 5%
  if (distanceFromHigh >= -0.10) return 75;  // Within 10%
  if (distanceFromHigh >= -0.15) return 60;  // Within 15%
  if (distanceFromHigh >= -0.20) return 45;  // Within 20%
  if (distanceFromHigh >= -0.30) return 30;  // Within 30%
  return 15; // More than 30% below high
}

/**
 * Volume Accumulation Score
 * Detects institutional buying: price up on higher volume
 * Based on On-Balance Volume concept but more refined
 */
export function calculateVolumeAccumulationScore(
  prices: number[],
  volumes: number[]
): number {
  if (prices.length < 63 || volumes.length < 63) return 50;

  const lookback = 63; // 3 months
  const recentPrices = prices.slice(-lookback);
  const recentVolumes = volumes.slice(-lookback);

  // Calculate average volume
  const avgVolume = recentVolumes.reduce((a, b) => a + b, 0) / recentVolumes.length;
  if (avgVolume === 0) return 50;

  // Count up days vs down days on above-average volume
  let upVolumeScore = 0;
  let downVolumeScore = 0;

  for (let i = 1; i < recentPrices.length; i++) {
    const priceChange = recentPrices[i] - recentPrices[i - 1];
    const volumeRatio = recentVolumes[i] / avgVolume;

    if (volumeRatio > 1.2) { // Above average volume
      if (priceChange > 0) {
        upVolumeScore += volumeRatio;
      } else if (priceChange < 0) {
        downVolumeScore += volumeRatio;
      }
    }
  }

  // Accumulation ratio
  const totalScore = upVolumeScore + downVolumeScore;
  if (totalScore === 0) return 50;

  const accumulationRatio = upVolumeScore / totalScore;

  // Convert to 0-100 score
  return Math.max(0, Math.min(100, accumulationRatio * 100));
}

/**
 * ADX Trend Strength Score
 * Average Directional Index measures trend strength
 * ADX > 25 indicates strong trend
 */
export function calculateADXScore(
  highs: number[],
  lows: number[],
  closes: number[],
  period: number = 14
): number {
  if (highs.length < period * 2 || lows.length < period * 2 || closes.length < period * 2) {
    return 50;
  }

  const n = Math.min(highs.length, lows.length, closes.length);
  const h = highs.slice(-n);
  const l = lows.slice(-n);
  const c = closes.slice(-n);

  // Calculate True Range, +DM, -DM
  const tr: number[] = [];
  const plusDM: number[] = [];
  const minusDM: number[] = [];

  for (let i = 1; i < n; i++) {
    const highDiff = h[i] - h[i - 1];
    const lowDiff = l[i - 1] - l[i];

    // True Range
    const trValue = Math.max(
      h[i] - l[i],
      Math.abs(h[i] - c[i - 1]),
      Math.abs(l[i] - c[i - 1])
    );
    tr.push(trValue);

    // Directional Movement
    if (highDiff > lowDiff && highDiff > 0) {
      plusDM.push(highDiff);
    } else {
      plusDM.push(0);
    }

    if (lowDiff > highDiff && lowDiff > 0) {
      minusDM.push(lowDiff);
    } else {
      minusDM.push(0);
    }
  }

  if (tr.length < period) return 50;

  // Smoothed averages (Wilder's smoothing)
  const smoothTR = wilderSmooth(tr, period);
  const smoothPlusDM = wilderSmooth(plusDM, period);
  const smoothMinusDM = wilderSmooth(minusDM, period);

  if (smoothTR.length === 0) return 50;

  // Calculate +DI and -DI
  const plusDI: number[] = [];
  const minusDI: number[] = [];

  for (let i = 0; i < smoothTR.length; i++) {
    if (smoothTR[i] > 0) {
      plusDI.push((smoothPlusDM[i] / smoothTR[i]) * 100);
      minusDI.push((smoothMinusDM[i] / smoothTR[i]) * 100);
    }
  }

  if (plusDI.length === 0) return 50;

  // Calculate DX
  const dx: number[] = [];
  for (let i = 0; i < plusDI.length; i++) {
    const sum = plusDI[i] + minusDI[i];
    if (sum > 0) {
      dx.push((Math.abs(plusDI[i] - minusDI[i]) / sum) * 100);
    }
  }

  if (dx.length < period) return 50;

  // ADX is smoothed DX
  const adx = wilderSmooth(dx, period);
  const currentADX = adx[adx.length - 1] || 0;

  // Current trend direction
  const currentPlusDI = plusDI[plusDI.length - 1] || 0;
  const currentMinusDI = minusDI[minusDI.length - 1] || 0;
  const isBullish = currentPlusDI > currentMinusDI;

  // Score: Strong bullish trend = high, strong bearish = low, weak = middle
  if (currentADX >= 25) {
    // Strong trend
    if (isBullish) {
      return Math.min(100, 60 + currentADX);
    } else {
      return Math.max(0, 40 - currentADX * 0.5);
    }
  } else {
    // Weak trend - neutral
    return 50 + (isBullish ? 5 : -5);
  }
}

function wilderSmooth(data: number[], period: number): number[] {
  if (data.length < period) return [];

  const result: number[] = [];
  let sum = 0;

  for (let i = 0; i < period; i++) {
    sum += data[i];
  }
  result.push(sum);

  for (let i = period; i < data.length; i++) {
    result.push(result[result.length - 1] - (result[result.length - 1] / period) + data[i]);
  }

  return result;
}

/**
 * RSI with Trend Confirmation
 * Oversold RSI in uptrend = buy signal
 * Overbought RSI in downtrend = avoid
 */
export function calculateRSITrendScore(prices: number[]): number {
  if (prices.length < 50) return 50;

  const rsi = calculateRSI(prices, 14);
  const sma50 = calculateSMA(prices, 50);

  const currentRSI = rsi[rsi.length - 1] || 50;
  const currentPrice = prices[prices.length - 1];
  const currentSMA50 = sma50[sma50.length - 1] || currentPrice;

  const isUptrend = currentPrice > currentSMA50;

  // Scoring logic
  if (isUptrend) {
    // In uptrend: oversold = opportunity, overbought = caution
    if (currentRSI < 30) return 95;      // Oversold in uptrend - strong buy
    if (currentRSI < 40) return 85;      // Approaching oversold
    if (currentRSI < 50) return 70;      // Neutral-low
    if (currentRSI < 60) return 60;      // Neutral
    if (currentRSI < 70) return 55;      // Slightly overbought
    if (currentRSI < 80) return 45;      // Overbought
    return 35;                           // Very overbought - caution
  } else {
    // In downtrend: even oversold is risky, overbought = avoid
    if (currentRSI < 30) return 55;      // Oversold but downtrend
    if (currentRSI < 40) return 45;
    if (currentRSI < 50) return 40;
    if (currentRSI < 60) return 35;
    if (currentRSI < 70) return 25;
    return 15;                           // Overbought in downtrend - avoid
  }
}

function calculateRSI(prices: number[], period: number = 14): number[] {
  if (prices.length < period + 1) return [50];

  const changes = calculateReturns(prices).map((r, i) => prices[i + 1] - prices[i]);
  const gains: number[] = [];
  const losses: number[] = [];

  for (const change of changes) {
    gains.push(Math.max(0, change));
    losses.push(Math.max(0, -change));
  }

  // Initial average
  let avgGain = gains.slice(0, period).reduce((a, b) => a + b, 0) / period;
  let avgLoss = losses.slice(0, period).reduce((a, b) => a + b, 0) / period;

  const rsi: number[] = [];

  for (let i = period; i < gains.length; i++) {
    avgGain = (avgGain * (period - 1) + gains[i]) / period;
    avgLoss = (avgLoss * (period - 1) + losses[i]) / period;

    if (avgLoss === 0) {
      rsi.push(100);
    } else {
      const rs = avgGain / avgLoss;
      rsi.push(100 - (100 / (1 + rs)));
    }
  }

  return rsi;
}

function calculateSMA(prices: number[], period: number): number[] {
  const result: number[] = [];
  for (let i = period - 1; i < prices.length; i++) {
    const sum = prices.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
    result.push(sum / period);
  }
  return result;
}

/**
 * Higher Lows Pattern Score
 * Identifies accumulation pattern: consecutive higher lows
 */
export function calculateHigherLowsScore(prices: number[]): number {
  if (prices.length < 60) return 50;

  // Find local lows (swing lows)
  const lows: { idx: number; price: number }[] = [];
  const lookback = 5;

  for (let i = lookback; i < prices.length - lookback; i++) {
    const window = prices.slice(i - lookback, i + lookback + 1);
    const current = prices[i];

    if (current === Math.min(...window)) {
      lows.push({ idx: i, price: current });
    }
  }

  if (lows.length < 3) return 50;

  // Check recent lows for higher-low pattern
  const recentLows = lows.slice(-4);
  let higherLowCount = 0;
  let lowerLowCount = 0;

  for (let i = 1; i < recentLows.length; i++) {
    if (recentLows[i].price > recentLows[i - 1].price) {
      higherLowCount++;
    } else if (recentLows[i].price < recentLows[i - 1].price) {
      lowerLowCount++;
    }
  }

  // Also check if current price is above recent lows
  const current = prices[prices.length - 1];
  const mostRecentLow = recentLows[recentLows.length - 1]?.price || current;
  const aboveLow = current > mostRecentLow;

  // Score
  if (higherLowCount >= 2 && aboveLow) return 90; // Strong higher low pattern
  if (higherLowCount >= 1 && aboveLow) return 75; // Good pattern
  if (aboveLow && lowerLowCount === 0) return 60; // Neutral-positive
  if (lowerLowCount >= 2) return 25; // Lower lows - bearish
  return 50;
}

/**
 * Breakout Confirmation Score
 * Checks for breakouts above resistance with volume
 */
export function calculateBreakoutScore(
  prices: number[],
  volumes: number[]
): number {
  if (prices.length < 30 || volumes.length < 30) return 50;

  const current = prices[prices.length - 1];
  const currentVol = volumes[volumes.length - 1];

  // Calculate recent range (last 20 days)
  const range20 = prices.slice(-20);
  const high20 = Math.max(...range20.slice(0, -1)); // Exclude current
  const avgVol20 = volumes.slice(-21, -1).reduce((a, b) => a + b, 0) / 20;

  // Calculate previous high (days 21-40)
  const prevRange = prices.slice(-40, -20);
  const prevHigh = prevRange.length > 0 ? Math.max(...prevRange) : high20;

  // Is this a breakout?
  const isNewHigh = current > high20 && current > prevHigh;
  const isNearHigh = current > high20 * 0.98;
  const isVolumeExpansion = currentVol > avgVol20 * 1.5;

  // 5-day momentum
  const price5dAgo = prices[prices.length - 6] || current;
  const momentum5d = (current - price5dAgo) / price5dAgo;

  // Score
  if (isNewHigh && isVolumeExpansion) return 95; // Strong breakout
  if (isNewHigh) return 85; // Breakout without volume
  if (isNearHigh && momentum5d > 0.02) return 75; // Near breakout with momentum
  if (isNearHigh) return 65; // Near breakout
  if (momentum5d > 0.03) return 60; // Good momentum
  if (momentum5d < -0.03) return 35; // Negative momentum
  return 50;
}

/**
 * Volatility Regime Score
 * Avoid stocks in volatility expansion (often precedes drops)
 */
export function calculateVolatilityRegimeScore(prices: number[]): number {
  if (prices.length < 63) return 50;

  const returns = calculateReturns(prices);

  // Recent volatility (20 days)
  const recentReturns = returns.slice(-20);
  const recentVol = standardDeviation(recentReturns) * Math.sqrt(252) * 100;

  // Historical volatility (60 days)
  const histReturns = returns.slice(-60);
  const histVol = standardDeviation(histReturns) * Math.sqrt(252) * 100;

  // Volatility ratio
  const volRatio = recentVol / (histVol || 1);

  // Score: low vol ratio = favorable, high = unfavorable
  if (volRatio < 0.7) return 85;  // Vol contraction - bullish
  if (volRatio < 0.9) return 75;  // Stable vol
  if (volRatio < 1.1) return 60;  // Normal
  if (volRatio < 1.3) return 45;  // Slight expansion
  if (volRatio < 1.5) return 30;  // Vol expansion - caution
  return 20;                       // High vol expansion - avoid
}

function standardDeviation(arr: number[]): number {
  if (arr.length < 2) return 0;
  const avg = arr.reduce((a, b) => a + b, 0) / arr.length;
  const variance = arr.map(x => Math.pow(x - avg, 2)).reduce((a, b) => a + b, 0) / arr.length;
  return Math.sqrt(variance);
}

/**
 * Earnings Momentum Proxy
 * Use price action around earnings-like events (big moves)
 * Positive earnings surprises lead to drift
 */
export function calculateEarningsMomentumScore(prices: number[]): number {
  if (prices.length < 90) return 50;

  const returns = calculateReturns(prices);

  // Find "earnings-like" days (big moves > 3%)
  const bigMoves: { idx: number; ret: number }[] = [];

  for (let i = 0; i < returns.length; i++) {
    if (Math.abs(returns[i]) > 0.03) {
      bigMoves.push({ idx: i, ret: returns[i] });
    }
  }

  if (bigMoves.length === 0) return 50;

  // Look at recent big moves (last 60 days)
  const recentBigMoves = bigMoves.filter(m => m.idx > returns.length - 60);

  if (recentBigMoves.length === 0) return 50;

  // Check if recent big moves were positive and held
  let positiveHeld = 0;
  let negativeHeld = 0;

  for (const move of recentBigMoves) {
    const daysAfter = Math.min(10, returns.length - move.idx - 1);
    if (daysAfter < 5) continue;

    // Sum of returns 5-10 days after the big move
    const followThrough = returns.slice(move.idx + 1, move.idx + daysAfter + 1)
      .reduce((a, b) => a + b, 0);

    if (move.ret > 0 && followThrough > -0.02) {
      positiveHeld++; // Positive move that held
    } else if (move.ret < 0 && followThrough < 0.02) {
      negativeHeld++; // Negative move that continued
    }
  }

  // Score
  const total = positiveHeld + negativeHeld;
  if (total === 0) return 50;

  const positiveRatio = positiveHeld / total;
  return Math.max(0, Math.min(100, positiveRatio * 100));
}

// ==================== SECTOR ROTATION ====================

export const SECTOR_MAP: Record<string, string> = {
  'AAPL': 'Tech', 'MSFT': 'Tech', 'GOOGL': 'Tech', 'AMZN': 'Consumer', 'NVDA': 'Tech',
  'META': 'Tech', 'TSLA': 'Consumer', 'BRK-B': 'Financial', 'JPM': 'Financial', 'JNJ': 'Healthcare',
  'V': 'Financial', 'UNH': 'Healthcare', 'HD': 'Consumer', 'PG': 'Consumer', 'MA': 'Financial',
  'DIS': 'Consumer', 'ADBE': 'Tech', 'NFLX': 'Consumer', 'CRM': 'Tech', 'PYPL': 'Financial',
  'INTC': 'Tech', 'CSCO': 'Tech', 'PEP': 'Consumer', 'ABT': 'Healthcare', 'TMO': 'Healthcare',
  'COST': 'Consumer', 'AVGO': 'Tech', 'ACN': 'Tech', 'MRK': 'Healthcare', 'NKE': 'Consumer',
  'WMT': 'Consumer', 'LLY': 'Healthcare', 'BAC': 'Financial', 'KO': 'Consumer', 'PFE': 'Healthcare',
  'ABBV': 'Healthcare', 'CVX': 'Energy', 'XOM': 'Energy', 'MCD': 'Consumer', 'T': 'Telecom',
  'ORCL': 'Tech', 'AMD': 'Tech', 'QCOM': 'Tech', 'TXN': 'Tech', 'LOW': 'Consumer',
  'UPS': 'Industrial', 'NEE': 'Utility', 'RTX': 'Industrial', 'HON': 'Industrial', 'IBM': 'Tech'
};

export function calculateSectorStrength(
  symbol: string,
  allStockReturns: Map<string, number>
): number {
  const sector = SECTOR_MAP[symbol];
  if (!sector) return 50;

  // Get returns for all stocks in same sector
  const sectorReturns: number[] = [];
  const otherSectorReturns: number[] = [];

  for (const [sym, ret] of allStockReturns.entries()) {
    if (SECTOR_MAP[sym] === sector) {
      sectorReturns.push(ret);
    } else {
      otherSectorReturns.push(ret);
    }
  }

  if (sectorReturns.length === 0 || otherSectorReturns.length === 0) return 50;

  const sectorAvg = sectorReturns.reduce((a, b) => a + b, 0) / sectorReturns.length;
  const otherAvg = otherSectorReturns.reduce((a, b) => a + b, 0) / otherSectorReturns.length;

  // Relative sector strength
  const relStrength = sectorAvg - otherAvg;

  // Convert to score
  if (relStrength > 0.02) return 85;
  if (relStrength > 0.01) return 70;
  if (relStrength > -0.01) return 55;
  if (relStrength > -0.02) return 40;
  return 25;
}

// ==================== COMPOSITE ALPHA SCORE V2 ====================

export interface AlphaFactorsV2 {
  highScore52w: number;
  volumeAccum: number;
  adxTrend: number;
  rsiTrend: number;
  higherLows: number;
  breakout: number;
  volRegime: number;
  earningsMomentum: number;
  sectorStrength: number;
}

export function calculateAlphaScoreV2(factors: AlphaFactorsV2): {
  score: number;
  signal: 'STRONG_BUY' | 'BUY' | 'HOLD' | 'AVOID';
  confidence: number;
} {
  // Weighted composite - heavily emphasize 52W high proximity (academic evidence)
  // and breakout patterns (momentum continuation)
  const weights = {
    highScore52w: 0.25,      // Primary driver - George & Hwang momentum anomaly
    breakout: 0.18,          // Momentum continuation catalyst
    adxTrend: 0.14,          // Strong trends persist
    volumeAccum: 0.12,       // Institutional buying patterns
    higherLows: 0.10,        // Price structure confirmation
    volRegime: 0.08,         // Risk filter
    rsiTrend: 0.06,          // Mean reversion timing
    sectorStrength: 0.04,    // Sector rotation
    earningsMomentum: 0.03,  // Earnings drift proxy
  };

  const score =
    factors.highScore52w * weights.highScore52w +
    factors.volumeAccum * weights.volumeAccum +
    factors.adxTrend * weights.adxTrend +
    factors.rsiTrend * weights.rsiTrend +
    factors.higherLows * weights.higherLows +
    factors.breakout * weights.breakout +
    factors.volRegime * weights.volRegime +
    factors.earningsMomentum * weights.earningsMomentum +
    factors.sectorStrength * weights.sectorStrength;

  // Key factor checks for signal quality
  const is52wHighStrong = factors.highScore52w >= 75; // Near 52-week high
  const isBreakoutStrong = factors.breakout >= 70;     // Breakout confirmed
  const isTrendStrong = factors.adxTrend >= 60;        // Strong trend
  const isVolFavorable = factors.volRegime >= 50;      // No vol expansion
  const isVolumePositive = factors.volumeAccum >= 55;  // Accumulation

  // Count strong signals
  const strongSignals = [
    is52wHighStrong,
    isBreakoutStrong,
    isTrendStrong,
    isVolFavorable,
    isVolumePositive
  ].filter(Boolean).length;

  // Factor alignment for confidence
  const factorValues = Object.values(factors);
  const bullishFactors = factorValues.filter(f => f >= 60).length;
  const bearishFactors = factorValues.filter(f => f <= 40).length;

  const confidence = Math.min(100, Math.max(0,
    40 + strongSignals * 12
  ));

  // Signal determination - require strong conviction
  let signal: 'STRONG_BUY' | 'BUY' | 'HOLD' | 'AVOID';

  // STRONG_BUY: High score + 52W high + trend or breakout + vol favorable
  if (score >= 70 && is52wHighStrong && (isTrendStrong || isBreakoutStrong) && isVolFavorable) {
    signal = 'STRONG_BUY';
  }
  // BUY: Good score + either 52W high OR breakout + vol favorable
  else if (score >= 60 && (is52wHighStrong || isBreakoutStrong) && strongSignals >= 3) {
    signal = 'BUY';
  }
  // HOLD: Moderate score without strong negatives
  else if (score >= 50 && bearishFactors <= 3) {
    signal = 'HOLD';
  }
  // AVOID: Low score or too many bearish signals
  else {
    signal = 'AVOID';
  }

  return { score, signal, confidence };
}

// ==================== BACKTEST V2 ====================

export interface BacktestResultV2 {
  date: string;
  modelReturn: number;
  sp500Return: number;
  cumulativeModelReturn: number;
  cumulativeSp500Return: number;
  topPicks: string[];
  avgScore: number;
}

export interface BacktestSummaryV2 {
  totalModelReturn: number;
  totalSp500Return: number;
  annualizedModelReturn: number;
  annualizedSp500Return: number;
  alpha: number;
  sharpeRatio: number;
  sortinoRatio: number;
  maxDrawdown: number;
  calmarRatio: number;
  winRate: number;
  avgWin: number;
  avgLoss: number;
  profitFactor: number;
  totalTrades: number;
  outperformancePeriods: number;
  totalPeriods: number;
  informationRatio: number;
  trackingError: number;
  hitRate: number; // % of picks that beat market
  avgAlpha: number; // Average monthly alpha
}
