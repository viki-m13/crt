import { useQuery } from '@tanstack/react-query';
import { getTopRecommendations, getStockScores, runBacktest } from './stock-api';
import { fetchPrecomputedData, isPrecomputedDataAvailable, getDataAge } from './precomputed-data';
import type { AlphaScore, BacktestResult, BacktestSummary } from './stock-model';

/**
 * Smart data fetching strategy:
 * 1. If pre-computed data URL is configured, fetch that (instant)
 * 2. If pre-computed data is stale (>24h old), fall back to live calculation
 * 3. If no pre-computed URL, always use live calculation (slow)
 */

async function getStockScoresSmart(): Promise<AlphaScore[]> {
  // Try pre-computed data first
  if (isPrecomputedDataAvailable()) {
    const precomputed = await fetchPrecomputedData();

    if (precomputed) {
      const ageHours = getDataAge(precomputed);

      // Use pre-computed if less than 24 hours old
      if (ageHours < 24) {
        console.log(`Using pre-computed data (${ageHours.toFixed(1)}h old)`);
        return precomputed.stockScores;
      }

      console.log(`Pre-computed data is stale (${ageHours.toFixed(1)}h old), fetching live...`);
    }
  }

  // Fall back to live calculation
  console.log('Fetching live stock data...');
  return getStockScores();
}

async function getTopRecommendationsSmart(count: number): Promise<AlphaScore[]> {
  const scores = await getStockScoresSmart();

  // Filter for actionable signals
  const candidates = scores.filter(s =>
    s.signal === 'STRONG_BUY' || s.signal === 'BUY'
  );

  // If not enough buy signals, take top by alpha score
  return candidates.length >= count
    ? candidates.slice(0, count)
    : scores.slice(0, count);
}

export function useTopRecommendations(count: number = 3) {
  return useQuery<AlphaScore[], Error>({
    queryKey: ['topRecommendations', count],
    queryFn: () => getTopRecommendationsSmart(count),
    staleTime: 1000 * 60 * 60, // 1 hour
    gcTime: 1000 * 60 * 60 * 24, // 24 hours cache
    retry: 2,
  });
}

export function useAllStockScores() {
  return useQuery<AlphaScore[], Error>({
    queryKey: ['allStockScores'],
    queryFn: () => getStockScoresSmart(),
    staleTime: 1000 * 60 * 60,
    gcTime: 1000 * 60 * 60 * 24,
    retry: 2,
  });
}

export function useBacktest() {
  return useQuery<{ results: BacktestResult[]; summary: BacktestSummary }, Error>({
    queryKey: ['backtest'],
    queryFn: () => runBacktest(),
    staleTime: 1000 * 60 * 60 * 24,
    gcTime: 1000 * 60 * 60 * 24 * 7,
    retry: 1,
  });
}

/**
 * Hook to check data source status
 */
export function useDataSourceInfo() {
  return useQuery({
    queryKey: ['dataSourceInfo'],
    queryFn: async () => {
      if (!isPrecomputedDataAvailable()) {
        return {
          source: 'live' as const,
          message: 'Using live data (slower)',
          isPrecomputed: false,
          ageHours: 0,
        };
      }

      const precomputed = await fetchPrecomputedData();
      if (!precomputed) {
        return {
          source: 'live' as const,
          message: 'Pre-computed data unavailable',
          isPrecomputed: false,
          ageHours: 0,
        };
      }

      const ageHours = getDataAge(precomputed);
      return {
        source: ageHours < 24 ? 'precomputed' as const : 'live' as const,
        message: ageHours < 24
          ? `Data updated ${ageHours.toFixed(1)}h ago`
          : 'Using live data (pre-computed expired)',
        isPrecomputed: ageHours < 24,
        ageHours,
        generatedAt: precomputed.generatedAt,
      };
    },
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
}
