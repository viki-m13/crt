/**
 * React Query hooks for Value Stock Picker
 */

import { useQuery } from '@tanstack/react-query';
import {
  getValuePicks,
  getTopValuePicks,
  runValueBacktest,
  ValuePick,
  ValueBacktestSummary,
  setProgressCallback,
  LoadingProgress,
} from './value-model';

export function useValuePicks() {
  return useQuery<ValuePick[], Error>({
    queryKey: ['valuePicks'],
    queryFn: getValuePicks,
    staleTime: 1000 * 60 * 30, // 30 minutes
    gcTime: 1000 * 60 * 60 * 2, // 2 hours
  });
}

export function useTopValuePicks(n: number = 5) {
  return useQuery<ValuePick[], Error>({
    queryKey: ['topValuePicks', n],
    queryFn: () => getTopValuePicks(n),
    staleTime: 1000 * 60 * 30,
    gcTime: 1000 * 60 * 60 * 2,
  });
}

export function useValueBacktest() {
  return useQuery<ValueBacktestSummary, Error>({
    queryKey: ['valueBacktest'],
    queryFn: runValueBacktest,
    staleTime: 1000 * 60 * 60, // 1 hour
    gcTime: 1000 * 60 * 60 * 24, // 24 hours
  });
}

// Re-export types and progress functions
export type { ValuePick, ValueBacktestSummary, LoadingProgress } from './value-model';
export { setProgressCallback } from './value-model';
