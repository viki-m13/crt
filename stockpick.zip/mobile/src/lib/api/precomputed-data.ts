/**
 * Pre-computed Stock Data Service
 *
 * Instead of calculating all factor scores on every app load (slow),
 * we fetch pre-computed data from a hosted JSON file.
 *
 * The data can be generated daily using the generate-stock-data.ts script
 * and hosted on:
 * - GitHub Gist (free, easy)
 * - GitHub Pages
 * - Any static file host
 */

import type { AlphaScore, BacktestResult, BacktestSummary } from './stock-model';

export interface PrecomputedData {
  generatedAt: string;
  expiresAt: string;
  stockScores: AlphaScore[];
  backtestResults: BacktestResult[];
  backtestSummary: BacktestSummary;
}

// Default URL - user should replace with their own hosted JSON
// Can be a GitHub Gist raw URL, GitHub Pages URL, or any static host
const DEFAULT_DATA_URL = process.env.EXPO_PUBLIC_PRECOMPUTED_DATA_URL || '';

// Cache the data in memory
let cachedData: PrecomputedData | null = null;
let cacheTimestamp: number = 0;
const CACHE_DURATION = 1000 * 60 * 30; // 30 minutes memory cache

/**
 * Fetch pre-computed stock data from hosted JSON
 */
export async function fetchPrecomputedData(
  dataUrl: string = DEFAULT_DATA_URL
): Promise<PrecomputedData | null> {
  // Return cached data if still fresh
  if (cachedData && Date.now() - cacheTimestamp < CACHE_DURATION) {
    return cachedData;
  }

  if (!dataUrl) {
    console.warn('No pre-computed data URL configured. Set EXPO_PUBLIC_PRECOMPUTED_DATA_URL');
    return null;
  }

  try {
    const response = await fetch(dataUrl, {
      headers: {
        'Cache-Control': 'no-cache',
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch pre-computed data: ${response.status}`);
    }

    const data: PrecomputedData = await response.json();

    // Validate the data structure
    if (!data.stockScores || !Array.isArray(data.stockScores)) {
      throw new Error('Invalid pre-computed data format');
    }

    // Check if data is expired
    const expiresAt = new Date(data.expiresAt).getTime();
    if (Date.now() > expiresAt) {
      console.warn('Pre-computed data is expired. Consider regenerating.');
    }

    // Cache the data
    cachedData = data;
    cacheTimestamp = Date.now();

    return data;
  } catch (error) {
    console.error('Error fetching pre-computed data:', error);
    return null;
  }
}

/**
 * Check if pre-computed data is available and fresh
 */
export function isPrecomputedDataAvailable(): boolean {
  return !!DEFAULT_DATA_URL;
}

/**
 * Get the age of cached data in hours
 */
export function getDataAge(data: PrecomputedData): number {
  const generatedAt = new Date(data.generatedAt).getTime();
  return (Date.now() - generatedAt) / (1000 * 60 * 60);
}

/**
 * Clear the in-memory cache
 */
export function clearPrecomputedCache(): void {
  cachedData = null;
  cacheTimestamp = 0;
}
