import React from 'react';
import {
  View,
  Text,
  ScrollView,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {
  BarChart3,
  TrendingUp,
  History,
  Target,
  CheckCircle2,
  XCircle,
  Clock,
  Database,
} from 'lucide-react-native';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import { useValueBacktest, ValueBacktestSummary } from '@/lib/api/use-value';
import { HelpButton } from '@/components/HelpTooltip';

export default function EvidenceScreen() {
  const { data: backtest, isLoading, error, refetch, isFetching } = useValueBacktest();

  if (isLoading) {
    return (
      <View className="flex-1 bg-zinc-950 items-center justify-center">
        <ActivityIndicator size="large" color="#3B82F6" />
        <Text className="text-zinc-400 mt-4">Analyzing historical data...</Text>
        <Text className="text-zinc-500 text-sm mt-1">
          Finding similar past instances
        </Text>
      </View>
    );
  }

  if (error) {
    return (
      <View className="flex-1 bg-zinc-950 items-center justify-center p-6">
        <Text className="text-red-500 text-lg font-bold mb-2">Error loading data</Text>
        <Text className="text-zinc-400 text-center">
          {error.message || 'Please try again later.'}
        </Text>
      </View>
    );
  }

  if (!backtest) {
    return (
      <View className="flex-1 bg-zinc-950 items-center justify-center p-6">
        <Text className="text-zinc-400 text-center">
          No historical data available
        </Text>
      </View>
    );
  }

  // Validation thresholds
  const isValid1Y = backtest.avgHitRate1Y >= 65;
  const isValid3Y = backtest.avgHitRate3Y >= 75;
  const isValid5Y = backtest.avgHitRate5Y >= 80;
  const hasAlpha = backtest.alpha1Y > 0;
  const overallValid = isValid1Y && isValid3Y && hasAlpha;

  return (
    <ScrollView
      className="flex-1 bg-zinc-950"
      contentContainerStyle={{ paddingBottom: 32 }}
      refreshControl={
        <RefreshControl
          refreshing={isFetching && !isLoading}
          onRefresh={refetch}
          tintColor="#3B82F6"
        />
      }
    >
      {/* Header */}
      <LinearGradient
        colors={['#1E40AF', '#3B82F6', '#60A5FA'] as const}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{ padding: 20, paddingTop: 8 }}
      >
        <Animated.View entering={FadeIn.delay(100)}>
          <View className="flex-row items-center mb-2">
            <History size={20} color="rgba(255,255,255,0.9)" />
            <Text className="text-white/90 text-sm font-medium ml-2">Historical Evidence</Text>
          </View>
          <Text className="text-white text-2xl font-bold mb-2">Model Validation</Text>
          <Text className="text-white/80 text-sm">
            Evidence from {backtest.totalInstancesAnalyzed} similar historical instances
          </Text>
        </Animated.View>
      </LinearGradient>

      {/* Validation Status */}
      <Animated.View entering={FadeInDown.delay(150)} className="px-4 -mt-3">
        <View className={`rounded-xl p-4 border ${
          overallValid
            ? 'bg-emerald-900/20 border-emerald-800/50'
            : 'bg-amber-900/20 border-amber-800/50'
        }`}>
          <View className="flex-row items-center">
            {overallValid ? (
              <CheckCircle2 size={24} color="#10B981" />
            ) : (
              <XCircle size={24} color="#F59E0B" />
            )}
            <View className="ml-3 flex-1">
              <Text className={`font-bold text-lg ${
                overallValid
                  ? 'text-emerald-400'
                  : 'text-amber-400'
              }`}>
                {overallValid ? 'Strong Historical Edge' : 'Moderate Edge'}
              </Text>
              <Text className={`text-sm ${
                overallValid
                  ? 'text-emerald-500'
                  : 'text-amber-500'
              }`}>
                {overallValid
                  ? 'Value approach shows consistent outperformance'
                  : 'Some metrics below optimal thresholds'}
              </Text>
            </View>
          </View>
        </View>
      </Animated.View>

      {/* Key Insight */}
      <Animated.View entering={FadeInDown.delay(200)} className="px-4 mt-4">
        <View className="bg-zinc-900 rounded-2xl p-4 border border-zinc-800">
          <View className="flex-row items-center mb-3">
            <Database size={18} color="#3B82F6" />
            <Text className="text-white font-semibold ml-2">Key Insight</Text>
          </View>
          <Text className="text-zinc-300 text-sm leading-5">
            When stocks were in similar undervalued conditions (below 52-week average,
            below 200-day SMA), they were{' '}
            <Text className="text-emerald-400 font-semibold">
              higher {backtest.avgHitRate5Y}% of the time
            </Text>
            {' '}after 5 years, with a median return of{' '}
            <Text className="text-emerald-400 font-semibold">
              +{backtest.avgReturn5Y}%
            </Text>.
          </Text>
        </View>
      </Animated.View>

      {/* Hit Rate Cards */}
      <Animated.View entering={FadeInDown.delay(250)} className="px-4 mt-4">
        <View className="flex-row items-center mb-3">
          <Text className="text-lg font-bold text-white">
            Probability of Being Higher
          </Text>
          <HelpButton metricKey="hitRate" />
        </View>

        <View className="bg-zinc-900 rounded-2xl p-4 border border-zinc-800">
          <Text className="text-zinc-400 text-xs mb-4">
            Based on historical instances where stocks had similar value metrics
          </Text>

          <HitRateCard
            label="After 1 Year"
            hitRate={backtest.avgHitRate1Y}
            target={65}
            color="#3B82F6"
          />
          <HitRateCard
            label="After 3 Years"
            hitRate={backtest.avgHitRate3Y}
            target={75}
            color="#8B5CF6"
          />
          <HitRateCard
            label="After 5 Years"
            hitRate={backtest.avgHitRate5Y}
            target={80}
            color="#10B981"
          />
        </View>
      </Animated.View>

      {/* Returns Comparison */}
      <Animated.View entering={FadeInDown.delay(300)} className="px-4 mt-4">
        <View className="flex-row items-center mb-3">
          <Text className="text-lg font-bold text-white">
            Average Returns vs S&P 500
          </Text>
          <HelpButton metricKey="alpha" />
        </View>

        <View className="bg-zinc-900 rounded-2xl p-4 border border-zinc-800">
          <View className="flex-row mb-4">
            <View className="flex-1 mr-2">
              <Text className="text-zinc-500 text-xs mb-1">
                Value Picks Avg Return
              </Text>
              <Text className="text-emerald-400 text-2xl font-bold">
                +{backtest.avgReturn1Y}%
              </Text>
              <Text className="text-zinc-500 text-xs">per year</Text>
            </View>
            <View className="flex-1 ml-2">
              <Text className="text-zinc-500 text-xs mb-1">
                S&P 500 Avg Return
              </Text>
              <Text className="text-blue-400 text-2xl font-bold">
                +{backtest.avgSpyReturn1Y}%
              </Text>
              <Text className="text-zinc-500 text-xs">per year</Text>
            </View>
          </View>

          {/* Alpha cards */}
          <Text className="text-zinc-400 text-xs mb-2">Outperformance (Alpha)</Text>
          <View className="flex-row">
            <AlphaCard period="1Y" alpha={backtest.alpha1Y} />
            <AlphaCard period="3Y" alpha={backtest.alpha3Y} />
            <AlphaCard period="5Y" alpha={backtest.alpha5Y} />
          </View>
        </View>
      </Animated.View>

      {/* Time Horizon Comparison */}
      <Animated.View entering={FadeInDown.delay(350)} className="px-4 mt-4">
        <Text className="text-lg font-bold text-white mb-3">
          Median Returns by Horizon
        </Text>

        <View className="bg-zinc-900 rounded-2xl p-4 border border-zinc-800">
          <View className="flex-row">
            <TimeHorizonCard
              horizon="1 Year"
              valueReturn={backtest.avgReturn1Y}
              spyReturn={backtest.avgSpyReturn1Y}
            />
            <TimeHorizonCard
              horizon="3 Years"
              valueReturn={backtest.avgReturn3Y}
              spyReturn={backtest.avgSpyReturn3Y}
            />
            <TimeHorizonCard
              horizon="5 Years"
              valueReturn={backtest.avgReturn5Y}
              spyReturn={backtest.avgSpyReturn5Y}
            />
          </View>
        </View>
      </Animated.View>

      {/* Methodology */}
      <Animated.View entering={FadeInDown.delay(400)} className="px-4 mt-4">
        <View className="bg-zinc-900/50 rounded-2xl p-4 border border-zinc-800/50">
          <Text className="text-sm font-semibold text-white mb-3">
            How We Calculated This
          </Text>
          <View className="space-y-2">
            <MethodRow
              text="Identified historical instances where stocks had similar value characteristics"
            />
            <MethodRow
              text="Measured actual returns 1, 3, and 5 years after each instance"
            />
            <MethodRow
              text="No look-ahead bias - only used data available at the time"
            />
            <MethodRow
              text="Similarity based on: 52-week position, distance from SMA, RSI, drawdown"
            />
          </View>
        </View>
      </Animated.View>

      {/* Disclaimer */}
      <Animated.View entering={FadeInDown.delay(450)} className="px-4 mt-4">
        <View className="bg-amber-900/20 rounded-xl p-4 border border-amber-800/30">
          <Text className="text-amber-300 text-xs leading-4">
            Historical patterns may not repeat. Past performance does not guarantee
            future results. Market conditions change and value traps exist. This
            analysis is for educational purposes only.
          </Text>
        </View>
      </Animated.View>
    </ScrollView>
  );
}

function HitRateCard({
  label,
  hitRate,
  target,
  color,
}: {
  label: string;
  hitRate: number;
  target: number;
  color: string;
}) {
  const isValid = hitRate >= target;

  return (
    <View className="mb-3 last:mb-0">
      <View className="flex-row items-center justify-between mb-2">
        <View className="flex-row items-center">
          <Clock size={16} color={color} />
          <Text className="text-zinc-300 font-medium ml-2">{label}</Text>
        </View>
        <View className="flex-row items-center">
          <Text style={{ color: isValid ? '#10B981' : '#F59E0B' }} className="text-lg font-bold">
            {hitRate}%
          </Text>
          <Text className="text-zinc-500 text-xs ml-1">
            / {target}% target
          </Text>
        </View>
      </View>
      <View className="h-2 bg-zinc-800 rounded-full overflow-hidden">
        <View
          style={{
            width: `${Math.min(100, hitRate)}%`,
            backgroundColor: isValid ? '#10B981' : '#F59E0B'
          }}
          className="h-full rounded-full"
        />
      </View>
    </View>
  );
}

function AlphaCard({ period, alpha }: { period: string; alpha: number }) {
  const isPositive = alpha > 0;

  return (
    <View className={`flex-1 mx-1 p-3 rounded-xl ${
      isPositive
        ? 'bg-emerald-900/20'
        : 'bg-red-900/20'
    }`}>
      <Text className="text-zinc-400 text-xs text-center mb-1">
        {period} Alpha
      </Text>
      <Text className={`text-lg font-bold text-center ${
        isPositive
          ? 'text-emerald-400'
          : 'text-red-400'
      }`}>
        {isPositive ? '+' : ''}{alpha}%
      </Text>
    </View>
  );
}

function TimeHorizonCard({
  horizon,
  valueReturn,
  spyReturn,
}: {
  horizon: string;
  valueReturn: number;
  spyReturn: number;
}) {
  const outperformance = valueReturn - spyReturn;
  const isOutperforming = outperformance > 0;

  return (
    <View className="flex-1 mx-1">
      <View className="bg-zinc-800 rounded-lg p-3">
        <Text className="text-zinc-400 text-xs text-center mb-2">{horizon}</Text>
        <View className="items-center">
          <Text className="text-emerald-400 font-bold">
            +{valueReturn}%
          </Text>
          <Text className="text-zinc-500 text-xs">value</Text>
        </View>
        <View className="items-center mt-1">
          <Text className="text-blue-400 font-bold">
            +{spyReturn}%
          </Text>
          <Text className="text-zinc-500 text-xs">S&P 500</Text>
        </View>
        <View className={`mt-2 pt-2 border-t border-zinc-700 items-center`}>
          <Text className={`text-xs font-medium ${
            isOutperforming ? 'text-emerald-400' : 'text-red-400'
          }`}>
            {isOutperforming ? '+' : ''}{outperformance.toFixed(1)}% α
          </Text>
        </View>
      </View>
    </View>
  );
}

function MethodRow({ text }: { text: string }) {
  return (
    <View className="flex-row items-start py-1">
      <View className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5 mr-2" />
      <Text className="text-zinc-400 text-sm flex-1">{text}</Text>
    </View>
  );
}
