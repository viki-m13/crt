import React from 'react';
import { Tabs } from 'expo-router';
import { TrendingDown, BarChart3, List } from 'lucide-react-native';
import { useColorScheme } from '@/lib/useColorScheme';

export default function TabLayout() {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: '#3B82F6',
        tabBarInactiveTintColor: isDark ? '#71717A' : '#A1A1AA',
        tabBarStyle: {
          backgroundColor: isDark ? '#18181B' : '#FFFFFF',
          borderTopColor: isDark ? '#27272A' : '#E4E4E7',
          paddingTop: 8,
          height: 88,
        },
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: '600',
        },
        headerStyle: {
          backgroundColor: isDark ? '#09090B' : '#FAFAFA',
        },
        headerTitleStyle: {
          fontWeight: '700',
          color: isDark ? '#FFFFFF' : '#18181B',
        },
        headerShadowVisible: false,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Value Picks',
          headerTitle: 'Value Finder',
          tabBarIcon: ({ color, focused }) => (
            <TrendingDown size={focused ? 26 : 24} color={color} strokeWidth={focused ? 2.5 : 2} />
          ),
        }}
      />
      <Tabs.Screen
        name="backtest"
        options={{
          title: 'Evidence',
          headerTitle: 'Historical Evidence',
          tabBarIcon: ({ color, focused }) => (
            <BarChart3 size={focused ? 26 : 24} color={color} strokeWidth={focused ? 2.5 : 2} />
          ),
        }}
      />
      <Tabs.Screen
        name="all-stocks"
        options={{
          title: 'All Stocks',
          headerTitle: 'Stock Universe',
          tabBarIcon: ({ color, focused }) => (
            <List size={focused ? 26 : 24} color={color} strokeWidth={focused ? 2.5 : 2} />
          ),
        }}
      />
    </Tabs>
  );
}
