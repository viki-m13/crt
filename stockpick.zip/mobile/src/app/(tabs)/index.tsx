import React from 'react';
import {
  View,
  Text,
  ScrollView,
  RefreshControl,
  Pressable,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {
  TrendingDown,
  Target,
  History,
  Shield,
  BarChart3,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ChevronRight,
} from 'lucide-react-native';
import Animated, { FadeIn, FadeInDown, FadeInUp } from 'react-native-reanimated';
import { useTopValuePicks, useValueBacktest, ValuePick } from '@/lib/api/use-value';
import { HelpButton, LabelWithHelp } from '@/components/HelpTooltip';
import { LoadingStatus } from '@/components/LoadingStatus';
import { router } from 'expo-router';

export default function ValuePicksScreen() {
  const { data: picks, isLoading, error, refetch, isFetching } = useTopValuePicks(5);
  const { data: backtest } = useValueBacktest();

  if (isLoading) {
    return <LoadingStatus />;
  }

  if (error) {
    return (
      <View className="flex-1 bg-zinc-950 items-center justify-center p-6">
        <AlertTriangle size={32} color="#EF4444" />
        <Text className="text-red-500 text-lg font-bold mb-2 mt-3">Error loading data</Text>
        <Text className="text-zinc-400 text-center">
          {error.message || 'Please try again later.'}
        </Text>
        <Pressable
          onPress={() => refetch()}
          className="mt-4 bg-zinc-800 px-6 py-3 rounded-xl"
        >
          <Text className="text-white font-medium">Retry</Text>
        </Pressable>
      </View>
    );
  }

  const valuePicks = picks || [];

  return (
    <ScrollView
      className="flex-1 bg-zinc-950"
      contentContainerStyle={{ paddingBottom: 32 }}
      refreshControl={
        <RefreshControl
          refreshing={isFetching && !isLoading}
          onRefresh={refetch}
          tintColor="#3B82F6"
        />
      }
    >
      {/* Header */}
      <LinearGradient
        colors={['#1E40AF', '#3B82F6', '#60A5FA']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{ padding: 20, paddingTop: 8 }}
      >
        <Animated.View entering={FadeIn.delay(100)}>
          <View className="flex-row items-center mb-2">
            <TrendingDown size={20} color="rgba(255,255,255,0.9)" />
            <Text className="text-white/90 text-sm font-medium ml-2">Value Finder</Text>
          </View>
          <Text className="text-white text-2xl font-bold mb-2">Undervalued Assets</Text>
          <Text className="text-white/80 text-sm">
            Stocks & crypto trading below fair value
          </Text>
        </Animated.View>
      </LinearGradient>

      {/* Historical Evidence Card */}
      {backtest && (
        <Animated.View entering={FadeInDown.delay(150)} className="px-4 -mt-3">
          <View className="bg-zinc-900 rounded-xl p-4 border border-zinc-800">
            <View className="flex-row items-center mb-3">
              <History size={18} color="#3B82F6" />
              <Text className="text-white font-semibold ml-2">
                Historical Evidence
              </Text>
              <HelpButton metricKey="hitRate" />
            </View>
            <Text className="text-zinc-400 text-xs mb-3">
              When assets were in similar undervalued conditions, they were higher:
            </Text>
            <View className="flex-row">
              <EvidenceBadge
                label="After 1Y"
                value={backtest.avgHitRate1Y}
                suffix="% of time"
              />
              <EvidenceBadge
                label="After 3Y"
                value={backtest.avgHitRate3Y}
                suffix="% of time"
              />
              <EvidenceBadge
                label="After 5Y"
                value={backtest.avgHitRate5Y}
                suffix="% of time"
              />
            </View>
            <View className="mt-3 pt-3 border-t border-zinc-800">
              <View className="flex-row justify-between items-center">
                <View className="flex-row items-center">
                  <Text className="text-zinc-500 text-xs">
                    Avg Alpha: +{backtest.alpha1Y}% (1Y)
                  </Text>
                  <HelpButton metricKey="alpha" />
                </View>
                <Text className="text-zinc-500 text-xs">
                  {backtest.totalInstancesAnalyzed} instances
                </Text>
              </View>
            </View>
          </View>
        </Animated.View>
      )}

      {/* Value Picks */}
      <Animated.View entering={FadeInDown.delay(200)} className="px-4 mt-4">
        <View className="flex-row items-center mb-3">
          <Target size={18} color="#F59E0B" />
          <Text className="text-lg font-bold text-white ml-2">
            Top Value Opportunities
          </Text>
        </View>

        {valuePicks.length === 0 ? (
          <View className="bg-zinc-900 rounded-xl p-6 items-center">
            <CheckCircle2 size={32} color="#10B981" />
            <Text className="text-white font-medium mt-3">No Deep Value Found</Text>
            <Text className="text-zinc-400 text-sm text-center mt-1">
              Markets are fairly valued right now. Check back when there are pullbacks.
            </Text>
          </View>
        ) : (
          valuePicks.map((pick, index) => (
            <ValueCard key={pick.symbol} pick={pick} rank={index + 1} />
          ))
        )}
      </Animated.View>

      {/* Methodology */}
      <Animated.View entering={FadeInDown.delay(400)} className="px-4 mt-4">
        <View className="bg-zinc-900/50 rounded-2xl p-4 border border-zinc-800/50">
          <Text className="text-sm font-semibold text-white mb-3">
            How It Works
          </Text>
          <View className="space-y-2">
            <MethodRow
              icon={<TrendingDown size={16} color="#3B82F6" />}
              text="Finds assets trading below historical fair value"
            />
            <MethodRow
              icon={<History size={16} color="#3B82F6" />}
              text="Matches current conditions to similar past instances"
            />
            <MethodRow
              icon={<BarChart3 size={16} color="#3B82F6" />}
              text="Calculates probability from actual historical outcomes"
            />
            <MethodRow
              icon={<Shield size={16} color="#3B82F6" />}
              text="Quality filters to avoid value traps"
            />
          </View>
        </View>
      </Animated.View>

      {/* Disclaimer */}
      <Animated.View entering={FadeInDown.delay(500)} className="px-4 mt-4">
        <View className="bg-amber-900/20 rounded-xl p-4 border border-amber-800/30">
          <Text className="text-amber-300 text-xs leading-4">
            Past performance does not guarantee future results. Undervalued assets
            can remain undervalued or decline further. This analysis is for
            educational purposes only and not financial advice.
          </Text>
        </View>
      </Animated.View>
    </ScrollView>
  );
}

function EvidenceBadge({
  label,
  value,
  suffix,
}: {
  label: string;
  value: number;
  suffix: string;
}) {
  const color = value >= 80 ? '#10B981' : value >= 70 ? '#3B82F6' : '#F59E0B';

  return (
    <View className="flex-1 items-center">
      <Text className="text-zinc-500 text-xs mb-1">{label}</Text>
      <Text style={{ color }} className="text-xl font-bold">
        {value}
      </Text>
      <Text className="text-zinc-500 text-xs">{suffix}</Text>
    </View>
  );
}

function ValueCard({ pick, rank }: { pick: ValuePick; rank: number }) {
  const categoryColors: Record<string, { bg: string; text: string }> = {
    DEEP_VALUE: { bg: 'bg-blue-500/20', text: 'text-blue-400' },
    VALUE: { bg: 'bg-emerald-500/20', text: 'text-emerald-400' },
    FAIR: { bg: 'bg-zinc-500/20', text: 'text-zinc-400' },
    EXPENSIVE: { bg: 'bg-red-500/20', text: 'text-red-400' },
  };

  const catStyle = categoryColors[pick.valueCategory] || categoryColors.FAIR;
  const isCrypto = pick.sector === 'Crypto';

  const handlePress = () => {
    router.push({
      pathname: '/stock-detail',
      params: { symbol: pick.symbol },
    });
  };

  return (
    <Pressable onPress={handlePress}>
      <Animated.View
        entering={FadeInUp.delay(100 * rank)}
        className="bg-zinc-900 rounded-2xl mb-3 overflow-hidden border border-zinc-800"
      >
        {/* Header */}
        <View className="p-4 border-b border-zinc-800">
          <View className="flex-row items-center justify-between">
            <View className="flex-row items-center flex-1">
              <View className={`w-8 h-8 rounded-full items-center justify-center mr-3 ${
                isCrypto ? 'bg-orange-500/20' : 'bg-blue-500/20'
              }`}>
                <Text className={`font-bold text-sm ${
                  isCrypto ? 'text-orange-400' : 'text-blue-400'
                }`}>{rank}</Text>
              </View>
              <View className="flex-1">
                <View className="flex-row items-center">
                  <Text className="text-white font-bold text-lg">{pick.symbol}</Text>
                  {isCrypto && (
                    <View className="ml-2 px-1.5 py-0.5 bg-orange-500/20 rounded">
                      <Text className="text-orange-400 text-xs font-medium">CRYPTO</Text>
                    </View>
                  )}
                </View>
                <Text className="text-zinc-400 text-xs">{pick.name}</Text>
              </View>
            </View>
            <View className="items-end flex-row">
              <View className="items-end mr-2">
                <View className="flex-row items-center">
                  <View className={`px-2 py-1 rounded-full ${catStyle.bg}`}>
                    <Text className={`font-semibold text-xs ${catStyle.text}`}>
                      {pick.valueCategory.replace('_', ' ')}
                    </Text>
                  </View>
                  <HelpButton metricKey="valueCategory" />
                </View>
                <Text className="text-zinc-500 text-xs mt-1">${pick.currentPrice.toFixed(pick.currentPrice < 1 ? 4 : 0)}</Text>
              </View>
              <ChevronRight size={20} color="#71717A" />
            </View>
          </View>
        </View>

        {/* Value Metrics */}
      <View className="p-4 border-b border-zinc-800">
        <View className="flex-row items-center mb-2">
          <Text className="text-zinc-400 text-xs font-medium">VALUE METRICS</Text>
        </View>
        <View className="flex-row mb-2">
          <MetricPill
            label="Value Score"
            metricKey="valueScore"
            value={`${pick.valueScore}`}
            color={pick.valueScore >= 60 ? '#10B981' : '#3B82F6'}
          />
          <MetricPill
            label="Quality"
            metricKey="qualityScore"
            value={`${pick.qualityScore}`}
            color={pick.qualityScore >= 50 ? '#10B981' : '#F59E0B'}
          />
          <MetricPill
            label="52W Position"
            metricKey="valuePosition"
            value={`${pick.metrics.valuePosition.toFixed(0)}%`}
            color={pick.metrics.valuePosition < 40 ? '#10B981' : '#71717A'}
          />
        </View>
        <View className="flex-row">
          <MetricPill
            label="vs SMA200"
            metricKey="distanceFromSMA200"
            value={`${pick.metrics.distanceFromSMA200.toFixed(1)}%`}
            color={pick.metrics.distanceFromSMA200 < 0 ? '#10B981' : '#71717A'}
          />
          <MetricPill
            label="RSI"
            metricKey="rsi"
            value={`${pick.metrics.rsi14.toFixed(0)}`}
            color={pick.metrics.rsi14 < 40 ? '#10B981' : '#71717A'}
          />
          <MetricPill
            label="Drawdown"
            metricKey="drawdown"
            value={`${pick.metrics.drawdownFrom52wHigh.toFixed(0)}%`}
            color={pick.metrics.drawdownFrom52wHigh < -15 ? '#10B981' : '#71717A'}
          />
        </View>
      </View>

      {/* Historical Probability */}
      <View className="p-4 border-b border-zinc-800">
        <View className="flex-row items-center mb-2">
          <Clock size={14} color="#3B82F6" />
          <Text className="text-zinc-400 text-xs font-medium ml-1">
            PROBABILITY FROM {pick.totalSimilarInstances} SIMILAR INSTANCES
          </Text>
          <HelpButton metricKey="probability" />
        </View>

        <ProbabilityBar
          label="Higher in 1 Year"
          probability={pick.prob1Year}
          medianReturn={pick.medianReturn1Y}
        />
        <ProbabilityBar
          label="Higher in 3 Years"
          probability={pick.prob3Year}
          medianReturn={pick.medianReturn3Y}
        />
        <ProbabilityBar
          label="Higher in 5 Years"
          probability={pick.prob5Year}
          medianReturn={pick.medianReturn5Y}
        />
      </View>

      {/* Historical Evidence */}
      <View className="p-4">
        <View className="flex-row items-center mb-2">
          <Text className="text-zinc-400 text-xs font-medium">
            SIMILAR PAST INSTANCES
          </Text>
          <HelpButton metricKey="similarInstances" />
        </View>
        <View className="bg-zinc-800/50 rounded-lg p-3">
          {pick.similarInstances.slice(0, 3).map((instance, idx) => (
            <View
              key={idx}
              className={`flex-row items-center justify-between py-2 ${
                idx < 2 ? 'border-b border-zinc-700/50' : ''
              }`}
            >
              <View className="flex-row items-center">
                <View
                  className={`w-2 h-2 rounded-full mr-2 ${
                    instance.similarity >= 70 ? 'bg-emerald-500' : 'bg-blue-500'
                  }`}
                />
                <Text className="text-zinc-400 text-xs">
                  {instance.similarity}% match
                </Text>
              </View>
              <View className="flex-row items-center">
                <ReturnBadge label="1Y" value={instance.return1Y} />
                <ReturnBadge label="3Y" value={instance.return3Y} />
                <ReturnBadge label="5Y" value={instance.return5Y} />
              </View>
            </View>
          ))}
        </View>
      </View>
    </Animated.View>
    </Pressable>
  );
}

function MetricPill({
  label,
  metricKey,
  value,
  color,
}: {
  label: string;
  metricKey: string;
  value: string;
  color: string;
}) {
  return (
    <View className="flex-1 mr-2">
      <View className="flex-row items-center mb-1">
        <Text className="text-zinc-500 text-xs">{label}</Text>
        <HelpButton metricKey={metricKey} size={12} />
      </View>
      <View
        className="rounded-lg py-1 px-2"
        style={{ backgroundColor: `${color}20` }}
      >
        <Text style={{ color }} className="text-sm font-semibold text-center">
          {value}
        </Text>
      </View>
    </View>
  );
}

function ProbabilityBar({
  label,
  probability,
  medianReturn,
}: {
  label: string;
  probability: number;
  medianReturn: number;
}) {
  const barColor =
    probability >= 85 ? 'bg-emerald-500' :
    probability >= 75 ? 'bg-emerald-400' :
    probability >= 65 ? 'bg-blue-500' :
    probability >= 50 ? 'bg-amber-500' :
    'bg-red-500';

  return (
    <View className="mb-2">
      <View className="flex-row justify-between mb-1">
        <Text className="text-zinc-400 text-xs">{label}</Text>
        <View className="flex-row items-center">
          <Text className="text-white font-semibold text-xs">{probability}%</Text>
          <View className="flex-row items-center ml-2">
            <Text className="text-zinc-500 text-xs">
              (median: {medianReturn > 0 ? '+' : ''}{medianReturn}%)
            </Text>
            <HelpButton metricKey="medianReturn" size={12} />
          </View>
        </View>
      </View>
      <View className="h-2 bg-zinc-800 rounded-full overflow-hidden">
        <Animated.View
          entering={FadeIn.delay(200)}
          className={`h-full rounded-full ${barColor}`}
          style={{ width: `${probability}%` }}
        />
      </View>
    </View>
  );
}

function ReturnBadge({ label, value }: { label: string; value: number }) {
  const isPositive = value > 0;
  return (
    <View className="ml-2">
      <Text className="text-zinc-500 text-xs text-center">{label}</Text>
      <Text
        className={`text-xs font-medium ${
          isPositive ? 'text-emerald-400' : 'text-red-400'
        }`}
      >
        {isPositive ? '+' : ''}{value.toFixed(0)}%
      </Text>
    </View>
  );
}

function MethodRow({ icon, text }: { icon: React.ReactNode; text: string }) {
  return (
    <View className="flex-row items-center py-1">
      {icon}
      <Text className="text-zinc-400 text-sm ml-2">{text}</Text>
    </View>
  );
}
