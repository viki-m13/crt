import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import {
  List,
  Search,
  ArrowUpDown,
  TrendingDown,
  Filter,
} from 'lucide-react-native';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import { FlashList } from '@shopify/flash-list';
import { useValuePicks, ValuePick } from '@/lib/api/use-value';
import { HelpButton } from '@/components/HelpTooltip';

type SortOption = 'value' | 'prob1Y' | 'prob5Y' | 'name' | 'quality';
type FilterOption = 'all' | 'stocks' | 'crypto';

export default function AllStocksScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('value');
  const [filterBy, setFilterBy] = useState<FilterOption>('all');

  const { data: picks, isLoading, error, refetch, isFetching } = useValuePicks();

  const filteredAndSorted = useMemo(() => {
    if (!picks) return [];

    let filtered = picks;

    // Asset type filter
    if (filterBy === 'crypto') {
      filtered = filtered.filter(p => p.sector === 'Crypto');
    } else if (filterBy === 'stocks') {
      filtered = filtered.filter(p => p.sector !== 'Crypto');
    }

    // Search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        p =>
          p.symbol.toLowerCase().includes(query) ||
          p.name.toLowerCase().includes(query) ||
          p.sector.toLowerCase().includes(query)
      );
    }

    // Sort
    return [...filtered].sort((a, b) => {
      switch (sortBy) {
        case 'value':
          return b.valueScore - a.valueScore;
        case 'prob1Y':
          return b.prob1Year - a.prob1Year;
        case 'prob5Y':
          return b.prob5Year - a.prob5Year;
        case 'quality':
          return b.qualityScore - a.qualityScore;
        case 'name':
          return a.symbol.localeCompare(b.symbol);
        default:
          return 0;
      }
    });
  }, [picks, searchQuery, sortBy, filterBy]);

  const stockCount = picks?.filter(p => p.sector !== 'Crypto').length || 0;
  const cryptoCount = picks?.filter(p => p.sector === 'Crypto').length || 0;

  if (isLoading) {
    return (
      <View className="flex-1 bg-zinc-950 items-center justify-center">
        <ActivityIndicator size="large" color="#3B82F6" />
        <Text className="text-zinc-400 mt-4">Analyzing all stocks...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View className="flex-1 bg-zinc-950 items-center justify-center p-6">
        <Text className="text-red-500 text-lg font-bold mb-2">Error loading data</Text>
        <Text className="text-zinc-400 text-center">
          {error.message || 'Please try again later.'}
        </Text>
      </View>
    );
  }

  const renderItem = ({ item, index }: { item: ValuePick; index: number }) => (
    <StockRow pick={item} rank={index + 1} />
  );

  return (
    <View className="flex-1 bg-zinc-950">
      {/* Header */}
      <LinearGradient
        colors={['#1E40AF', '#3B82F6', '#60A5FA'] as const}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{ padding: 20, paddingTop: 8 }}
      >
        <Animated.View entering={FadeIn.delay(100)}>
          <View className="flex-row items-center mb-2">
            <List size={20} color="rgba(255,255,255,0.9)" />
            <Text className="text-white/90 text-sm font-medium ml-2">All Assets</Text>
          </View>
          <Text className="text-white text-2xl font-bold mb-2">Asset Universe</Text>
          <Text className="text-white/80 text-sm">
            {stockCount} stocks + {cryptoCount} crypto analyzed
          </Text>
        </Animated.View>
      </LinearGradient>

      {/* Search & Filter */}
      <Animated.View entering={FadeInDown.delay(150)} className="px-4 -mt-3">
        <View className="bg-zinc-900 rounded-xl p-3 border border-zinc-800">
          {/* Search */}
          <View className="flex-row items-center bg-zinc-800 rounded-lg px-3 py-2 mb-3">
            <Search size={18} color="#71717A" />
            <TextInput
              className="flex-1 ml-2 text-white"
              placeholder="Search by symbol, name, or sector..."
              placeholderTextColor="#71717A"
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
          </View>

          {/* Filter tabs */}
          <View className="flex-row items-center mb-3">
            <Filter size={14} color="#71717A" />
            <Text className="text-zinc-500 text-xs ml-1 mr-2">Filter:</Text>
            <FilterButton label="All" value="all" current={filterBy} onPress={setFilterBy} />
            <FilterButton label={`Stocks (${stockCount})`} value="stocks" current={filterBy} onPress={setFilterBy} />
            <FilterButton label={`Crypto (${cryptoCount})`} value="crypto" current={filterBy} onPress={setFilterBy} />
          </View>

          {/* Sort options */}
          <View className="flex-row items-center">
            <ArrowUpDown size={14} color="#71717A" />
            <Text className="text-zinc-500 text-xs ml-1 mr-2">Sort:</Text>
            <SortButton label="Value" value="value" current={sortBy} onPress={setSortBy} />
            <SortButton label="1Y Prob" value="prob1Y" current={sortBy} onPress={setSortBy} />
            <SortButton label="5Y Prob" value="prob5Y" current={sortBy} onPress={setSortBy} />
            <SortButton label="Quality" value="quality" current={sortBy} onPress={setSortBy} />
            <SortButton label="A-Z" value="name" current={sortBy} onPress={setSortBy} />
          </View>
        </View>
      </Animated.View>

      {/* Stock List */}
      <View className="flex-1 px-4 pt-4">
        <FlashList
          data={filteredAndSorted}
          renderItem={renderItem}
          estimatedItemSize={100}
          keyExtractor={(item) => item.symbol}
          showsVerticalScrollIndicator={false}
          onRefresh={refetch}
          refreshing={isFetching && !isLoading}
          ListEmptyComponent={
            <View className="py-8 items-center">
              <Text className="text-zinc-400">No stocks found</Text>
            </View>
          }
        />
      </View>
    </View>
  );
}

function SortButton({
  label,
  value,
  current,
  onPress,
}: {
  label: string;
  value: SortOption;
  current: SortOption;
  onPress: (value: SortOption) => void;
}) {
  const isActive = current === value;

  return (
    <Pressable
      onPress={() => onPress(value)}
      className={`px-2 py-1 rounded-md mr-1 ${
        isActive ? 'bg-blue-500' : 'bg-zinc-800'
      }`}
    >
      <Text
        className={`text-xs font-medium ${
          isActive ? 'text-white' : 'text-zinc-400'
        }`}
      >
        {label}
      </Text>
    </Pressable>
  );
}

function FilterButton({
  label,
  value,
  current,
  onPress,
}: {
  label: string;
  value: FilterOption;
  current: FilterOption;
  onPress: (value: FilterOption) => void;
}) {
  const isActive = current === value;

  return (
    <Pressable
      onPress={() => onPress(value)}
      className={`px-2 py-1 rounded-md mr-1 ${
        isActive ? 'bg-orange-500' : 'bg-zinc-800'
      }`}
    >
      <Text
        className={`text-xs font-medium ${
          isActive ? 'text-white' : 'text-zinc-400'
        }`}
      >
        {label}
      </Text>
    </Pressable>
  );
}

function StockRow({ pick, rank }: { pick: ValuePick; rank: number }) {
  const categoryColors: Record<string, string> = {
    DEEP_VALUE: 'bg-blue-500',
    VALUE: 'bg-emerald-500',
    FAIR: 'bg-zinc-500',
    EXPENSIVE: 'bg-red-500',
  };

  const signalTextColor: Record<string, string> = {
    STRONG_BUY: 'text-emerald-400',
    BUY: 'text-blue-400',
    HOLD: 'text-zinc-400',
    AVOID: 'text-red-400',
  };

  const isCrypto = pick.sector === 'Crypto';
  const priceDisplay = pick.currentPrice < 1
    ? pick.currentPrice.toFixed(4)
    : pick.currentPrice < 10
    ? pick.currentPrice.toFixed(2)
    : pick.currentPrice.toFixed(0);

  return (
    <View className="bg-zinc-900 rounded-xl p-3 mb-2 border border-zinc-800">
      <View className="flex-row items-center">
        {/* Rank */}
        <View className={`w-8 h-8 rounded-full items-center justify-center mr-3 ${
          isCrypto ? 'bg-orange-500/20' : 'bg-zinc-800'
        }`}>
          <Text className={`font-bold text-xs ${
            isCrypto ? 'text-orange-400' : 'text-zinc-400'
          }`}>{rank}</Text>
        </View>

        {/* Stock info */}
        <View className="flex-1">
          <View className="flex-row items-center">
            <Text className="text-white font-bold">{pick.symbol}</Text>
            <View className={`ml-2 w-2 h-2 rounded-full ${categoryColors[pick.valueCategory]}`} />
            {isCrypto && (
              <View className="ml-1.5 px-1 py-0.5 bg-orange-500/20 rounded">
                <Text className="text-orange-400 text-[10px] font-medium">CRYPTO</Text>
              </View>
            )}
          </View>
          <Text className="text-zinc-500 text-xs" numberOfLines={1}>
            {pick.name}
          </Text>
        </View>

        {/* Value Score */}
        <View className="items-center mr-4">
          <View className="flex-row items-center">
            <Text className="text-zinc-500 text-xs">Value</Text>
            <HelpButton metricKey="valueScore" size={10} />
          </View>
          <Text className={`font-bold ${
            pick.valueScore >= 60 ? 'text-emerald-400' :
            pick.valueScore >= 40 ? 'text-blue-400' : 'text-zinc-400'
          }`}>
            {pick.valueScore}
          </Text>
        </View>

        {/* Probabilities */}
        <View className="items-end">
          <View className="flex-row items-center">
            <Text className="text-zinc-500 text-xs mr-1">1Y:</Text>
            <Text className={`font-semibold text-sm ${
              pick.prob1Year >= 70
                ? 'text-emerald-400'
                : pick.prob1Year >= 50
                ? 'text-amber-400'
                : 'text-red-400'
            }`}>
              {pick.prob1Year}%
            </Text>
          </View>
          <View className="flex-row items-center">
            <Text className="text-zinc-500 text-xs mr-1">5Y:</Text>
            <Text className={`font-semibold text-sm ${
              pick.prob5Year >= 80
                ? 'text-emerald-400'
                : pick.prob5Year >= 60
                ? 'text-amber-400'
                : 'text-red-400'
            }`}>
              {pick.prob5Year}%
            </Text>
          </View>
        </View>
      </View>

      {/* Bottom row */}
      <View className="flex-row items-center mt-2 pt-2 border-t border-zinc-800">
        <Text className={`text-xs font-medium ${signalTextColor[pick.signal]}`}>
          {pick.signal.replace('_', ' ')}
        </Text>
        <Text className="text-zinc-600 text-xs mx-2">|</Text>
        <Text className="text-zinc-500 text-xs">
          {pick.valueCategory.replace('_', ' ')}
        </Text>
        <Text className="text-zinc-600 text-xs mx-2">|</Text>
        <Text className="text-zinc-500 text-xs">
          {pick.sector}
        </Text>
        <Text className="text-zinc-600 text-xs mx-2">|</Text>
        <View className="flex-row items-center">
          <Text className="text-zinc-500 text-xs">Q: {pick.qualityScore}</Text>
          <HelpButton metricKey="qualityScore" size={10} />
        </View>
        <Text className="text-zinc-600 text-xs mx-2">|</Text>
        <Text className="text-zinc-500 text-xs">
          ${priceDisplay}
        </Text>
      </View>
    </View>
  );
}
