import React, { useMemo } from 'react';
import {
  View,
  Text,
  ScrollView,
  Pressable,
  Dimensions,
} from 'react-native';
import { Stack, useLocalSearchParams, router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeInDown } from 'react-native-reanimated';
import Svg, { Path, Defs, LinearGradient as SvgGradient, Stop, Line, Circle, G } from 'react-native-svg';
import {
  ArrowLeft,
  Target,
  History,
  AlertCircle,
  ShoppingCart,
} from 'lucide-react-native';
import { useQuery } from '@tanstack/react-query';
import { HelpButton } from '@/components/HelpTooltip';
import {
  fetchStockData,
  STOCK_INFO,
  ValueMetrics,
  calculateValueMetrics as calcValueMetrics,
} from '@/lib/api/value-model';

const SCREEN_WIDTH = Dimensions.get('window').width;
const CHART_HEIGHT = 200;
const CHART_PADDING = 16;
const CHART_WIDTH = SCREEN_WIDTH - CHART_PADDING * 2;

interface HistoricalBuySignal {
  dateIndex: number;
  date: string;
  price: number;
  valueScore: number;
  return1Y: number | null;
  return3Y: number | null;
  return5Y: number | null;
}

// Helper function to calculate value score (same as in value-model)
function calculateValueScore(metrics: ValueMetrics): number {
  let score = 0;
  if (metrics.valuePosition <= 20) score += 40;
  else if (metrics.valuePosition <= 40) score += 25;
  else if (metrics.valuePosition <= 60) score += 10;
  else if (metrics.valuePosition >= 80) score -= 10;

  if (metrics.distanceFromSMA200 < -10) score += 25;
  else if (metrics.distanceFromSMA200 < -5) score += 15;
  else if (metrics.distanceFromSMA200 < 0) score += 5;
  else if (metrics.distanceFromSMA200 > 10) score -= 10;

  if (metrics.rsi14 < 30) score += 20;
  else if (metrics.rsi14 < 40) score += 10;
  else if (metrics.rsi14 < 50) score += 5;
  else if (metrics.rsi14 > 70) score -= 10;

  if (metrics.drawdownFrom52wHigh < -30) score += 15;
  else if (metrics.drawdownFrom52wHigh < -20) score += 10;
  else if (metrics.drawdownFrom52wHigh < -10) score += 5;

  return Math.max(0, Math.min(100, score + 20));
}

export default function StockDetailScreen() {
  const { symbol } = useLocalSearchParams<{ symbol: string }>();
  const stockInfo = STOCK_INFO[symbol || ''] || { name: symbol, sector: 'Unknown' };
  const isCrypto = stockInfo.sector === 'Crypto';

  // Fetch historical data
  const { data: stockData, isLoading, error } = useQuery({
    queryKey: ['stockDetail', symbol],
    queryFn: () => fetchStockData(symbol || '', '10y'),
    enabled: !!symbol,
    staleTime: 1000 * 60 * 30,
  });

  // Process data for chart and signals
  const { chartData, buySignals, currentMetrics } = useMemo(() => {
    if (!stockData || stockData.length < 252) {
      return { chartData: [], buySignals: [], currentMetrics: null };
    }

    const prices = stockData.map(d => d.adjClose);
    const dates = stockData.map(d => d.date);

    // Get last 2 years for chart display
    const displayStart = Math.max(0, prices.length - 504);
    const chartData = stockData.slice(displayStart).map((d, i) => ({
      date: d.date,
      price: d.adjClose,
      index: displayStart + i,
    }));

    // Find historical buy signals (when our model would have recommended)
    const buySignals: HistoricalBuySignal[] = [];
    const signalThreshold = 50; // Value score threshold for "buy" signal

    // Check every quarter for historical signals
    for (let i = 252 * 2; i < prices.length - 252; i += 63) {
      const metrics = calcValueMetrics(prices, i);
      if (!metrics) continue;

      const valueScore = calculateValueScore(metrics);

      // Also check for value conditions
      const isValueSignal = valueScore >= signalThreshold &&
        metrics.valuePosition < 40 &&
        metrics.distanceFromSMA200 < 5;

      if (isValueSignal) {
        const currentPrice = prices[i];
        const price1Y = i + 252 < prices.length ? prices[i + 252] : null;
        const price3Y = i + 252 * 3 < prices.length ? prices[i + 252 * 3] : null;
        const price5Y = i + 252 * 5 < prices.length ? prices[i + 252 * 5] : null;

        buySignals.push({
          dateIndex: i,
          date: dates[i],
          price: currentPrice,
          valueScore,
          return1Y: price1Y ? ((price1Y - currentPrice) / currentPrice) * 100 : null,
          return3Y: price3Y ? ((price3Y - currentPrice) / currentPrice) * 100 : null,
          return5Y: price5Y ? ((price5Y - currentPrice) / currentPrice) * 100 : null,
        });
      }
    }

    // Current metrics
    const currentMetrics = calcValueMetrics(prices, prices.length - 1);

    return { chartData, buySignals, currentMetrics };
  }, [stockData]);

  const currentPrice = stockData?.[stockData.length - 1]?.adjClose ?? 0;
  const priceMin = chartData.length > 0 ? Math.min(...chartData.map(d => d.price)) : 0;
  const priceMax = chartData.length > 0 ? Math.max(...chartData.map(d => d.price)) : 0;
  const priceRange = priceMax - priceMin || 1;

  // Calculate SVG path for price line
  const pricePath = useMemo(() => {
    if (chartData.length < 2) return '';

    const points = chartData.map((d, i) => {
      const x = (i / (chartData.length - 1)) * CHART_WIDTH;
      const y = CHART_HEIGHT - ((d.price - priceMin) / priceRange) * CHART_HEIGHT;
      return `${x},${y}`;
    });

    return `M ${points.join(' L ')}`;
  }, [chartData, priceMin, priceRange]);

  // Map buy signals to chart coordinates
  const chartBuySignals = useMemo(() => {
    if (!chartData.length || !buySignals.length) return [];

    const displayStart = chartData[0]?.index || 0;

    return buySignals
      .filter(signal => signal.dateIndex >= displayStart)
      .map(signal => {
        const chartIndex = signal.dateIndex - displayStart;
        if (chartIndex < 0 || chartIndex >= chartData.length) return null;

        const x = (chartIndex / (chartData.length - 1)) * CHART_WIDTH;
        const y = CHART_HEIGHT - ((signal.price - priceMin) / priceRange) * CHART_HEIGHT;

        return { ...signal, x, y };
      })
      .filter(Boolean) as Array<HistoricalBuySignal & { x: number; y: number }>;
  }, [chartData, buySignals, priceMin, priceRange]);

  if (isLoading) {
    return (
      <View className="flex-1 bg-zinc-950 items-center justify-center">
        <Stack.Screen options={{ headerShown: false }} />
        <Text className="text-white">Loading...</Text>
      </View>
    );
  }

  if (error || !stockData?.length) {
    return (
      <View className="flex-1 bg-zinc-950 items-center justify-center p-6">
        <Stack.Screen options={{ headerShown: false }} />
        <AlertCircle size={32} color="#EF4444" />
        <Text className="text-red-500 text-lg font-bold mt-3">Error Loading Data</Text>
        <Pressable onPress={() => router.back()} className="mt-4 bg-zinc-800 px-6 py-3 rounded-xl">
          <Text className="text-white">Go Back</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View className="flex-1 bg-zinc-950">
      <Stack.Screen options={{ headerShown: false }} />

      {/* Header */}
      <LinearGradient
        colors={isCrypto ? ['#EA580C', '#F97316', '#FB923C'] : ['#1E40AF', '#3B82F6', '#60A5FA']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{ paddingTop: 60, paddingBottom: 20, paddingHorizontal: 20 }}
      >
        <Pressable onPress={() => router.back()} className="flex-row items-center mb-4">
          <ArrowLeft size={24} color="white" />
          <Text className="text-white/80 ml-2">Back</Text>
        </Pressable>
        <View className="flex-row items-center justify-between">
          <View>
            <View className="flex-row items-center">
              <Text className="text-white text-2xl font-bold">{symbol}</Text>
              {isCrypto && (
                <View className="ml-2 px-2 py-0.5 bg-white/20 rounded">
                  <Text className="text-white text-xs font-medium">CRYPTO</Text>
                </View>
              )}
            </View>
            <Text className="text-white/80 text-sm mt-1">{stockInfo.name}</Text>
          </View>
          <View className="items-end">
            <Text className="text-white text-2xl font-bold">
              ${currentPrice.toFixed(currentPrice < 1 ? 4 : 2)}
            </Text>
            <Text className="text-white/70 text-xs">{stockInfo.sector}</Text>
          </View>
        </View>
      </LinearGradient>

      <ScrollView className="flex-1" contentContainerStyle={{ paddingBottom: 32 }}>
        {/* Price Chart */}
        <Animated.View entering={FadeInDown.delay(100)} className="px-4 mt-4">
          <View className="bg-zinc-900 rounded-2xl p-4 border border-zinc-800">
            <View className="flex-row items-center justify-between mb-4">
              <Text className="text-white font-semibold">Price Chart (2Y)</Text>
              <View className="flex-row items-center">
                <View className="flex-row items-center mr-4">
                  <View className="w-2 h-2 rounded-full bg-blue-500 mr-1" />
                  <Text className="text-zinc-500 text-xs">Price</Text>
                </View>
                <View className="flex-row items-center">
                  <ShoppingCart size={12} color="#10B981" />
                  <Text className="text-zinc-500 text-xs ml-1">Buy Signals</Text>
                </View>
              </View>
            </View>

            {/* SVG Chart */}
            <View style={{ height: CHART_HEIGHT, position: 'relative' }}>
              {/* Grid lines */}
              {[0, 0.25, 0.5, 0.75, 1].map((p, i) => (
                <View
                  key={i}
                  className="absolute w-full h-px bg-zinc-800"
                  style={{ top: p * CHART_HEIGHT }}
                />
              ))}

              {/* Price labels */}
              <View className="absolute right-0 h-full justify-between">
                <Text className="text-zinc-600 text-xs">${priceMax.toFixed(0)}</Text>
                <Text className="text-zinc-600 text-xs">${((priceMax + priceMin) / 2).toFixed(0)}</Text>
                <Text className="text-zinc-600 text-xs">${priceMin.toFixed(0)}</Text>
              </View>

              {/* Price line using SVG */}
              <View style={{ position: 'absolute', left: 0, top: 0, width: CHART_WIDTH, height: CHART_HEIGHT }}>
                <Svg width={CHART_WIDTH} height={CHART_HEIGHT} viewBox={`0 0 ${CHART_WIDTH} ${CHART_HEIGHT}`}>
                  {/* Gradient fill */}
                  <Defs>
                    <SvgGradient id="priceGradient" x1="0" y1="0" x2="0" y2="1">
                      <Stop offset="0%" stopColor={isCrypto ? '#F97316' : '#3B82F6'} stopOpacity={0.3} />
                      <Stop offset="100%" stopColor={isCrypto ? '#F97316' : '#3B82F6'} stopOpacity={0} />
                    </SvgGradient>
                  </Defs>

                  {/* Area fill */}
                  {chartData.length > 1 && (
                    <Path
                      d={`${pricePath} L ${CHART_WIDTH},${CHART_HEIGHT} L 0,${CHART_HEIGHT} Z`}
                      fill="url(#priceGradient)"
                    />
                  )}

                  {/* Line */}
                  <Path
                    d={pricePath}
                    fill="none"
                    stroke={isCrypto ? '#F97316' : '#3B82F6'}
                    strokeWidth="2"
                  />

                  {/* Buy signal markers */}
                  {chartBuySignals.map((signal, i) => (
                    <G key={i}>
                      {/* Vertical line */}
                      <Line
                        x1={signal.x}
                        y1={0}
                        x2={signal.x}
                        y2={CHART_HEIGHT}
                        stroke="#10B981"
                        strokeWidth="1"
                        strokeDasharray="4,4"
                        opacity={0.5}
                      />
                      {/* Circle marker */}
                      <Circle
                        cx={signal.x}
                        cy={signal.y}
                        r="6"
                        fill="#10B981"
                        stroke="#052e16"
                        strokeWidth="2"
                      />
                    </G>
                  ))}
                </Svg>
              </View>
            </View>

            {/* Date labels */}
            <View className="flex-row justify-between mt-2">
              {chartData.length > 0 && (
                <>
                  <Text className="text-zinc-600 text-xs">{chartData[0]?.date?.slice(0, 7)}</Text>
                  <Text className="text-zinc-600 text-xs">
                    {chartData[Math.floor(chartData.length / 2)]?.date?.slice(0, 7)}
                  </Text>
                  <Text className="text-zinc-600 text-xs">
                    {chartData[chartData.length - 1]?.date?.slice(0, 7)}
                  </Text>
                </>
              )}
            </View>
          </View>
        </Animated.View>

        {/* Buy Signal Explanation */}
        <Animated.View entering={FadeInDown.delay(200)} className="px-4 mt-4">
          <View className="bg-emerald-900/20 rounded-xl p-4 border border-emerald-800/30">
            <View className="flex-row items-center mb-2">
              <ShoppingCart size={16} color="#10B981" />
              <Text className="text-emerald-400 font-semibold ml-2">Historical Buy Signals</Text>
              <HelpButton metricKey="historicalSignals" />
            </View>
            <Text className="text-zinc-400 text-sm">
              Green markers show when our model would have signaled a buy opportunity based on value metrics
              (undervalued position, below moving averages, oversold RSI).
            </Text>
          </View>
        </Animated.View>

        {/* Historical Signal Performance */}
        {buySignals.length > 0 && (
          <Animated.View entering={FadeInDown.delay(300)} className="px-4 mt-4">
            <View className="bg-zinc-900 rounded-2xl p-4 border border-zinc-800">
              <View className="flex-row items-center mb-4">
                <History size={18} color="#3B82F6" />
                <Text className="text-white font-semibold ml-2">
                  Signal Performance ({buySignals.length} signals)
                </Text>
              </View>

              {/* Summary stats */}
              <View className="flex-row mb-4">
                <StatBox
                  label="1Y Win Rate"
                  value={`${Math.round(
                    (buySignals.filter(s => s.return1Y !== null && s.return1Y > 0).length /
                      buySignals.filter(s => s.return1Y !== null).length) *
                      100
                  )}%`}
                  color="#10B981"
                />
                <StatBox
                  label="Avg 1Y Return"
                  value={`${buySignals
                    .filter(s => s.return1Y !== null)
                    .reduce((sum, s) => sum + (s.return1Y || 0), 0) /
                    buySignals.filter(s => s.return1Y !== null).length > 0
                    ? '+'
                    : ''}${(
                    buySignals
                      .filter(s => s.return1Y !== null)
                      .reduce((sum, s) => sum + (s.return1Y || 0), 0) /
                    buySignals.filter(s => s.return1Y !== null).length
                  ).toFixed(1)}%`}
                  color="#3B82F6"
                />
                <StatBox
                  label="Total Signals"
                  value={`${buySignals.length}`}
                  color="#F59E0B"
                />
              </View>

              {/* Individual signals */}
              <Text className="text-zinc-500 text-xs mb-2">RECENT SIGNALS</Text>
              {buySignals.slice(-5).reverse().map((signal, i) => (
                <SignalRow key={i} signal={signal} />
              ))}
            </View>
          </Animated.View>
        )}

        {/* Current Value Metrics */}
        {currentMetrics && (
          <Animated.View entering={FadeInDown.delay(400)} className="px-4 mt-4">
            <View className="bg-zinc-900 rounded-2xl p-4 border border-zinc-800">
              <View className="flex-row items-center mb-4">
                <Target size={18} color="#F59E0B" />
                <Text className="text-white font-semibold ml-2">Current Value Metrics</Text>
              </View>

              <View className="flex-row flex-wrap">
                <MetricBadge
                  label="52W Position"
                  value={`${currentMetrics.valuePosition.toFixed(0)}%`}
                  isGood={currentMetrics.valuePosition < 40}
                />
                <MetricBadge
                  label="vs SMA200"
                  value={`${currentMetrics.distanceFromSMA200.toFixed(1)}%`}
                  isGood={currentMetrics.distanceFromSMA200 < 0}
                />
                <MetricBadge
                  label="RSI"
                  value={`${currentMetrics.rsi14.toFixed(0)}`}
                  isGood={currentMetrics.rsi14 < 40}
                />
                <MetricBadge
                  label="Drawdown"
                  value={`${currentMetrics.drawdownFrom52wHigh.toFixed(0)}%`}
                  isGood={currentMetrics.drawdownFrom52wHigh < -15}
                />
              </View>
            </View>
          </Animated.View>
        )}

        {/* Disclaimer */}
        <Animated.View entering={FadeInDown.delay(500)} className="px-4 mt-4">
          <View className="bg-amber-900/20 rounded-xl p-4 border border-amber-800/30">
            <Text className="text-amber-300 text-xs leading-4">
              Historical signals are for educational purposes only. Past performance does not guarantee
              future results. This is not financial advice.
            </Text>
          </View>
        </Animated.View>
      </ScrollView>
    </View>
  );
}

function StatBox({
  label,
  value,
  color,
}: {
  label: string;
  value: string;
  color: string;
}) {
  return (
    <View className="flex-1 items-center">
      <Text className="text-zinc-500 text-xs mb-1">{label}</Text>
      <Text style={{ color }} className="text-lg font-bold">
        {value}
      </Text>
    </View>
  );
}

function SignalRow({ signal }: { signal: HistoricalBuySignal }) {
  return (
    <View className="flex-row items-center py-3 border-b border-zinc-800">
      <View className="flex-1">
        <Text className="text-white font-medium">{signal.date}</Text>
        <Text className="text-zinc-500 text-xs">
          Score: {signal.valueScore} | ${signal.price.toFixed(2)}
        </Text>
      </View>
      <View className="flex-row">
        <ReturnBadge label="1Y" value={signal.return1Y} />
        <ReturnBadge label="3Y" value={signal.return3Y} />
        <ReturnBadge label="5Y" value={signal.return5Y} />
      </View>
    </View>
  );
}

function ReturnBadge({ label, value }: { label: string; value: number | null }) {
  if (value === null) {
    return (
      <View className="ml-3 items-center">
        <Text className="text-zinc-500 text-xs">{label}</Text>
        <Text className="text-zinc-600 text-xs">-</Text>
      </View>
    );
  }

  const isPositive = value > 0;
  return (
    <View className="ml-3 items-center">
      <Text className="text-zinc-500 text-xs">{label}</Text>
      <Text
        className={`text-xs font-medium ${isPositive ? 'text-emerald-400' : 'text-red-400'}`}
      >
        {isPositive ? '+' : ''}
        {value.toFixed(0)}%
      </Text>
    </View>
  );
}

function MetricBadge({
  label,
  value,
  isGood,
}: {
  label: string;
  value: string;
  isGood: boolean;
}) {
  return (
    <View className="w-1/2 mb-3 pr-2">
      <Text className="text-zinc-500 text-xs mb-1">{label}</Text>
      <View
        className={`rounded-lg py-2 px-3 ${isGood ? 'bg-emerald-500/20' : 'bg-zinc-800'}`}
      >
        <Text
          className={`font-semibold ${isGood ? 'text-emerald-400' : 'text-zinc-400'}`}
        >
          {value}
        </Text>
      </View>
    </View>
  );
}
