import React, { useMemo } from 'react';
import { View, Text } from 'react-native';
import { CartesianChart, Line, useChartPressState } from 'victory-native';
import { Circle, matchFont } from '@shopify/react-native-skia';
import { Platform } from 'react-native';
import type { BacktestResult } from '@/lib/api/stock-model';

const CHART_HEIGHT = 220;

interface PerformanceChartProps {
  data: BacktestResult[];
}

export function PerformanceChart({ data }: PerformanceChartProps) {
  // Use system font instead of custom font file
  const fontFamily = Platform.select({ ios: 'Helvetica', default: 'sans-serif' });
  const fontStyle = {
    fontFamily,
    fontSize: 10,
    fontWeight: '400' as const,
  };
  const font = matchFont(fontStyle);

  const { state, isActive } = useChartPressState({ x: 0, y: { model: 0, sp500: 0 } });

  const chartData = useMemo(() => {
    return data.map((d, i) => ({
      x: i,
      model: d.cumulativeModelReturn,
      sp500: d.cumulativeSp500Return,
      date: d.date,
    }));
  }, [data]);

  const yDomain = useMemo(() => {
    const allValues = chartData.flatMap(d => [d.model, d.sp500]);
    const min = Math.min(...allValues, 0);
    const max = Math.max(...allValues);
    const padding = (max - min) * 0.1;
    return [min - padding, max + padding] as [number, number];
  }, [chartData]);

  return (
    <View className="bg-white dark:bg-zinc-900 rounded-2xl p-4 shadow-lg">
      <Text className="text-lg font-bold text-zinc-800 dark:text-white mb-1">
        Cumulative Performance
      </Text>
      <Text className="text-zinc-500 dark:text-zinc-400 text-sm mb-4">
        Model vs S&P 500 (Monthly Rebalance)
      </Text>

      {/* Legend */}
      <View className="flex-row mb-4">
        <View className="flex-row items-center mr-6">
          <View className="w-3 h-3 rounded-full bg-emerald-500 mr-2" />
          <Text className="text-zinc-600 dark:text-zinc-300 text-sm">Model</Text>
        </View>
        <View className="flex-row items-center">
          <View className="w-3 h-3 rounded-full bg-blue-500 mr-2" />
          <Text className="text-zinc-600 dark:text-zinc-300 text-sm">S&P 500</Text>
        </View>
      </View>

      {/* Active Value Display */}
      {isActive && (
        <View className="flex-row justify-center mb-2 bg-zinc-100 dark:bg-zinc-800 rounded-lg py-2 px-4">
          <Text className="text-emerald-600 dark:text-emerald-400 font-bold mr-4">
            Model: {state.y.model.value.value.toFixed(1)}%
          </Text>
          <Text className="text-blue-600 dark:text-blue-400 font-bold">
            S&P: {state.y.sp500.value.value.toFixed(1)}%
          </Text>
        </View>
      )}

      <View style={{ height: CHART_HEIGHT }}>
        <CartesianChart
          data={chartData}
          xKey="x"
          yKeys={['model', 'sp500']}
          domain={{ y: yDomain }}
          axisOptions={{
            font,
            tickCount: { x: 5, y: 5 },
            labelColor: '#9CA3AF',
            lineColor: '#374151',
            formatYLabel: (v) => `${v.toFixed(0)}%`,
            formatXLabel: (v) => {
              const idx = Math.round(v);
              if (idx >= 0 && idx < chartData.length) {
                return chartData[idx].date.slice(5); // MM format
              }
              return '';
            },
          }}
          chartPressState={state}
        >
          {({ points }) => (
            <>
              <Line
                points={points.model}
                color="#10B981"
                strokeWidth={2.5}
                curveType="natural"
              />
              <Line
                points={points.sp500}
                color="#3B82F6"
                strokeWidth={2.5}
                curveType="natural"
              />
              {isActive && (
                <>
                  <Circle
                    cx={state.x.position}
                    cy={state.y.model.position}
                    r={6}
                    color="#10B981"
                  />
                  <Circle
                    cx={state.x.position}
                    cy={state.y.sp500.position}
                    r={6}
                    color="#3B82F6"
                  />
                </>
              )}
            </>
          )}
        </CartesianChart>
      </View>
    </View>
  );
}
