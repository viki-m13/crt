import React, { useEffect, useState, useCallback } from 'react';
import { View, Text } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withRepeat,
  withSequence,
  Easing,
  FadeIn,
  FadeInUp,
} from 'react-native-reanimated';
import {
  TrendingDown,
  Search,
  Database,
  BarChart3,
  Sparkles,
  CheckCircle,
} from 'lucide-react-native';
import { setProgressCallback, LoadingProgress } from '@/lib/api/use-value';

interface LoadingStep {
  label: string;
  icon: React.ReactNode;
  phase: LoadingProgress['phase'];
}

const LOADING_STEPS: LoadingStep[] = [
  { label: 'Connecting to markets...', icon: <Database size={18} color="#3B82F6" />, phase: 'fetching' },
  { label: 'Fetching stock data...', icon: <Search size={18} color="#3B82F6" />, phase: 'fetching' },
  { label: 'Analyzing value metrics...', icon: <BarChart3 size={18} color="#3B82F6" />, phase: 'analyzing' },
  { label: 'Finding similar instances...', icon: <TrendingDown size={18} color="#3B82F6" />, phase: 'analyzing' },
  { label: 'Calculating probabilities...', icon: <Sparkles size={18} color="#3B82F6" />, phase: 'calculating' },
];

export function LoadingStatus() {
  const [progress, setProgress] = useState<LoadingProgress>({
    phase: 'fetching',
    current: 0,
    total: 100,
    message: 'Starting...',
  });
  const [currentStep, setCurrentStep] = useState(0);

  const progressWidth = useSharedValue(0);
  const pulseOpacity = useSharedValue(0.3);
  const scanlineY = useSharedValue(0);

  // Set up progress callback
  useEffect(() => {
    setProgressCallback((newProgress) => {
      setProgress(newProgress);

      // Calculate overall progress percentage
      let overallProgress = 0;
      if (newProgress.phase === 'fetching') {
        // Fetching is 0-60%
        overallProgress = (newProgress.current / newProgress.total) * 60;
        setCurrentStep(newProgress.current === 0 ? 0 : 1);
      } else if (newProgress.phase === 'analyzing') {
        // Analyzing is 60-90%
        overallProgress = 60 + (newProgress.current / newProgress.total) * 30;
        setCurrentStep(newProgress.current < newProgress.total / 2 ? 2 : 3);
      } else if (newProgress.phase === 'calculating' || newProgress.phase === 'complete') {
        // Calculating is 90-100%
        overallProgress = 90 + (newProgress.current / newProgress.total) * 10;
        setCurrentStep(4);
      }

      progressWidth.value = withTiming(Math.min(overallProgress, 99), { duration: 300 });
    });

    return () => {
      setProgressCallback(null);
    };
  }, []);

  // Pulse animation
  useEffect(() => {
    pulseOpacity.value = withRepeat(
      withSequence(
        withTiming(0.7, { duration: 800, easing: Easing.inOut(Easing.ease) }),
        withTiming(0.3, { duration: 800, easing: Easing.inOut(Easing.ease) })
      ),
      -1,
      true
    );
  }, []);

  // Scanline animation
  useEffect(() => {
    scanlineY.value = withRepeat(
      withTiming(100, { duration: 2000, easing: Easing.linear }),
      -1,
      false
    );
  }, []);

  const progressStyle = useAnimatedStyle(() => ({
    width: `${progressWidth.value}%`,
  }));

  const pulseStyle = useAnimatedStyle(() => ({
    opacity: pulseOpacity.value,
  }));

  const scanlineStyle = useAnimatedStyle(() => ({
    top: `${scanlineY.value}%`,
  }));

  // Calculate display percentage
  const displayPercent = Math.round(
    progress.phase === 'fetching'
      ? (progress.current / progress.total) * 60
      : progress.phase === 'analyzing'
      ? 60 + (progress.current / progress.total) * 30
      : 90 + (progress.current / progress.total) * 10
  );

  return (
    <View className="flex-1 bg-zinc-950 items-center justify-center px-6">
      {/* Background grid effect */}
      <View className="absolute inset-0 opacity-5">
        {[...Array(20)].map((_, i) => (
          <View
            key={i}
            className="absolute w-full h-px bg-blue-500"
            style={{ top: `${i * 5}%` }}
          />
        ))}
        {[...Array(10)].map((_, i) => (
          <View
            key={i}
            className="absolute h-full w-px bg-blue-500"
            style={{ left: `${i * 10}%` }}
          />
        ))}
      </View>

      {/* Scanline effect */}
      <Animated.View
        style={[scanlineStyle, { position: 'absolute', left: 0, right: 0, height: 2 }]}
        className="bg-blue-500/20"
      />

      {/* Main content */}
      <Animated.View entering={FadeIn.delay(100)} className="w-full max-w-sm">
        {/* Header */}
        <Animated.View
          entering={FadeInUp.delay(200)}
          className="items-center mb-8"
        >
          <Animated.View style={pulseStyle}>
            <LinearGradient
              colors={['#1E40AF', '#3B82F6']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={{ width: 64, height: 64, borderRadius: 16, alignItems: 'center', justifyContent: 'center' }}
            >
              <TrendingDown size={32} color="white" />
            </LinearGradient>
          </Animated.View>
          <Text className="text-white text-xl font-bold mt-4">Value Finder</Text>
          <Text className="text-zinc-500 text-sm mt-1">Analyzing 200+ assets</Text>
        </Animated.View>

        {/* Progress container */}
        <Animated.View
          entering={FadeInUp.delay(300)}
          className="bg-zinc-900 rounded-2xl p-5 border border-zinc-800"
        >
          {/* Current symbol being analyzed */}
          <View className="flex-row items-center justify-between mb-4">
            <View className="flex-row items-center">
              <View className="w-2 h-2 rounded-full bg-blue-500 mr-2" />
              <Text className="text-zinc-400 text-sm">
                {progress.phase === 'fetching' ? 'Fetching' : progress.phase === 'analyzing' ? 'Analyzing' : 'Processing'}
              </Text>
            </View>
            <View className="bg-zinc-800 px-3 py-1 rounded-lg">
              <Text className="text-blue-400 font-mono font-bold">
                {progress.currentSymbol || '...'}
              </Text>
            </View>
          </View>

          {/* Main progress bar */}
          <View className="mb-4">
            <View className="h-3 bg-zinc-800 rounded-full overflow-hidden">
              <Animated.View style={progressStyle} className="h-full">
                <LinearGradient
                  colors={['#1E40AF', '#3B82F6', '#60A5FA']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={{ flex: 1, borderRadius: 999 }}
                />
              </Animated.View>
            </View>
            <View className="flex-row justify-between mt-2">
              <Text className="text-zinc-500 text-xs">
                {progress.phase === 'fetching'
                  ? `Batch ${progress.current}/${progress.total}`
                  : `${progress.current}/${progress.total} stocks`}
              </Text>
              <Text className="text-blue-400 font-mono font-bold text-xs">
                {Math.min(displayPercent, 99)}%
              </Text>
            </View>
          </View>

          {/* Steps */}
          <View className="space-y-2">
            {LOADING_STEPS.map((step, index) => (
              <StepIndicator
                key={index}
                step={step}
                isActive={index === currentStep}
                isComplete={index < currentStep}
              />
            ))}
          </View>
        </Animated.View>

        {/* Status message */}
        <Animated.View
          entering={FadeInUp.delay(400)}
          className="mt-4 items-center"
        >
          <Text className="text-zinc-600 text-xs text-center">
            {progress.message}
          </Text>
        </Animated.View>
      </Animated.View>
    </View>
  );
}

function StepIndicator({
  step,
  isActive,
  isComplete,
}: {
  step: LoadingStep;
  isActive: boolean;
  isComplete: boolean;
}) {
  const dotScale = useSharedValue(1);

  useEffect(() => {
    if (isActive) {
      dotScale.value = withRepeat(
        withSequence(
          withTiming(1.3, { duration: 400 }),
          withTiming(1, { duration: 400 })
        ),
        -1,
        true
      );
    } else {
      dotScale.value = withTiming(1, { duration: 200 });
    }
  }, [isActive]);

  const dotStyle = useAnimatedStyle(() => ({
    transform: [{ scale: dotScale.value }],
  }));

  return (
    <View className={`flex-row items-center py-2 ${isActive ? 'opacity-100' : isComplete ? 'opacity-60' : 'opacity-30'}`}>
      {isComplete ? (
        <CheckCircle size={18} color="#10B981" />
      ) : (
        <Animated.View style={dotStyle}>
          {step.icon}
        </Animated.View>
      )}
      <Text className={`ml-3 text-sm ${isActive ? 'text-white font-medium' : isComplete ? 'text-zinc-400' : 'text-zinc-500'}`}>
        {step.label}
      </Text>
    </View>
  );
}
