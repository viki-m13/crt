import React from 'react';
import { View, Text, Pressable } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { TrendingUp, TrendingDown, Activity, Target, Zap, BarChart3 } from 'lucide-react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';
import type { AlphaScore } from '@/lib/api/stock-model';
import { cn } from '@/lib/cn';

interface StockCardProps {
  stock: AlphaScore;
  rank: number;
  onPress?: () => void;
  delay?: number;
}

const SIGNAL_COLORS = {
  STRONG_BUY: ['#10B981', '#059669'] as const,
  BUY: ['#3B82F6', '#2563EB'] as const,
  HOLD: ['#F59E0B', '#D97706'] as const,
  AVOID: ['#6B7280', '#4B5563'] as const,
};

const RANK_BADGES = ['#FFD700', '#C0C0C0', '#CD7F32']; // Gold, Silver, Bronze

export function StockCard({ stock, rank, onPress, delay = 0 }: StockCardProps) {
  const gradientColors = SIGNAL_COLORS[stock.signal];
  const isHighConviction = stock.conviction >= 60;

  return (
    <Animated.View entering={FadeInDown.delay(delay).springify()}>
      <Pressable onPress={onPress} className="active:scale-[0.98]">
        <View className="bg-white dark:bg-zinc-900 rounded-2xl overflow-hidden shadow-lg mb-4">
          {/* Header with gradient */}
          <LinearGradient
            colors={[gradientColors[0], gradientColors[1]]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={{ padding: 16 }}
          >
            <View className="flex-row items-center justify-between">
              <View className="flex-row items-center">
                {/* Rank Badge */}
                <View
                  style={{ backgroundColor: RANK_BADGES[rank - 1] || '#6B7280' }}
                  className="w-8 h-8 rounded-full items-center justify-center mr-3"
                >
                  <Text className="text-white font-bold text-sm">{rank}</Text>
                </View>
                <View>
                  <Text className="text-white font-bold text-xl">{stock.symbol}</Text>
                  <Text className="text-white/80 text-sm" numberOfLines={1}>
                    {stock.name}
                  </Text>
                </View>
              </View>
              <View className="items-end">
                <Text className="text-white font-bold text-xl">
                  ${stock.currentPrice.toFixed(2)}
                </Text>
                <View className="flex-row items-center px-2 py-0.5 rounded-full bg-black/20">
                  {stock.expectedReturn >= 0 ? (
                    <TrendingUp size={12} color="white" />
                  ) : (
                    <TrendingDown size={12} color="white" />
                  )}
                  <Text className="text-white text-xs ml-1 font-medium">
                    {stock.expectedReturn >= 0 ? '+' : ''}{stock.expectedReturn.toFixed(1)}% exp
                  </Text>
                </View>
              </View>
            </View>
          </LinearGradient>

          {/* Alpha Score Bar */}
          <View className="px-4 pt-4">
            <View className="flex-row items-center justify-between mb-2">
              <View className="flex-row items-center">
                <Zap size={16} color={stock.alphaScore >= 60 ? '#10B981' : '#6B7280'} />
                <Text className="text-zinc-700 dark:text-zinc-300 text-sm font-semibold ml-1">
                  Alpha Score
                </Text>
              </View>
              <Text className={cn(
                'font-bold text-sm',
                stock.alphaScore >= 60 ? 'text-emerald-500' : 'text-zinc-500'
              )}>
                {stock.alphaScore.toFixed(0)}/100
              </Text>
            </View>
            <View className="h-3 bg-zinc-200 dark:bg-zinc-700 rounded-full overflow-hidden">
              <View
                style={{ width: `${Math.max(0, Math.min(100, stock.alphaScore))}%` }}
                className={cn(
                  'h-full rounded-full',
                  stock.alphaScore >= 70 ? 'bg-emerald-500' :
                  stock.alphaScore >= 55 ? 'bg-blue-500' : 'bg-zinc-400'
                )}
              />
            </View>
            <Text className="text-zinc-500 dark:text-zinc-400 text-xs mt-1">
              {stock.alphaScore >= 70 ? 'Strong alpha potential' :
               stock.alphaScore >= 55 ? 'Above average potential' : 'Moderate potential'}
            </Text>
          </View>

          {/* Factor Scores Grid */}
          <View className="p-4">
            <View className="flex-row justify-between mb-3">
              <StatItem
                label="Momentum"
                value={`${stock.factors.momentum12m > 0 ? '+' : ''}${(stock.factors.momentum12m).toFixed(1)}σ`}
                subtitle="12m-1m"
                highlight={stock.factors.momentum12m > 0.5}
              />
              <StatItem
                label="Quality"
                value={`${stock.factors.qualityScore.toFixed(0)}`}
                subtitle="consistency"
                highlight={stock.factors.qualityScore > 55}
              />
              <StatItem
                label="Trend"
                value={`${stock.factors.trendScore.toFixed(0)}`}
                subtitle="MA structure"
                highlight={stock.factors.trendScore > 60}
              />
            </View>

            {/* Risk Metrics */}
            <View className="mt-2 bg-zinc-50 dark:bg-zinc-800 rounded-xl p-3">
              <View className="flex-row justify-between items-center">
                <View className="flex-row items-center">
                  <Activity size={14} color="#8B5CF6" />
                  <Text className="text-zinc-600 dark:text-zinc-400 text-xs ml-1">
                    Vol: {stock.volatility.toFixed(0)}%
                  </Text>
                </View>
                <View className="flex-row items-center">
                  <BarChart3 size={14} color="#6B7280" />
                  <Text className="text-zinc-600 dark:text-zinc-400 text-xs ml-1">
                    Beta: {stock.beta.toFixed(2)}
                  </Text>
                </View>
                <View className="flex-row items-center">
                  <TrendingDown size={14} color="#EF4444" />
                  <Text className="text-zinc-600 dark:text-zinc-400 text-xs ml-1">
                    MDD: -{stock.maxDrawdown.toFixed(0)}%
                  </Text>
                </View>
              </View>
            </View>

            {/* Bottom Row - Regime & Conviction */}
            <View className="flex-row justify-between mt-4 pt-3 border-t border-zinc-100 dark:border-zinc-800">
              <View className="flex-row items-center">
                <View className={cn(
                  'px-2 py-1 rounded',
                  stock.regimeType === 'BULL' ? 'bg-emerald-100 dark:bg-emerald-900/30' :
                  stock.regimeType === 'BEAR' ? 'bg-red-100 dark:bg-red-900/30' :
                  stock.regimeType === 'VOLATILE' ? 'bg-amber-100 dark:bg-amber-900/30' :
                  'bg-zinc-100 dark:bg-zinc-800'
                )}>
                  <Text className={cn(
                    'text-xs font-semibold',
                    stock.regimeType === 'BULL' ? 'text-emerald-700 dark:text-emerald-400' :
                    stock.regimeType === 'BEAR' ? 'text-red-700 dark:text-red-400' :
                    stock.regimeType === 'VOLATILE' ? 'text-amber-700 dark:text-amber-400' :
                    'text-zinc-600 dark:text-zinc-400'
                  )}>
                    {stock.regimeType}
                  </Text>
                </View>
              </View>
              <View className="flex-row items-center">
                <Target size={16} color={isHighConviction ? '#10B981' : '#6B7280'} />
                <Text className="text-zinc-600 dark:text-zinc-300 text-sm ml-1">
                  Conviction:{' '}
                  <Text className={cn('font-bold', isHighConviction ? 'text-emerald-500' : '')}>
                    {stock.conviction.toFixed(0)}%
                  </Text>
                </Text>
              </View>
            </View>
          </View>
        </View>
      </Pressable>
    </Animated.View>
  );
}

function StatItem({
  label,
  value,
  subtitle,
  highlight = false,
}: {
  label: string;
  value: string;
  subtitle: string;
  highlight?: boolean;
}) {
  return (
    <View className="items-center">
      <Text className="text-zinc-500 dark:text-zinc-400 text-xs mb-0.5">{label}</Text>
      <Text
        className={cn(
          'font-bold text-base',
          highlight ? 'text-emerald-600 dark:text-emerald-400' : 'text-zinc-800 dark:text-zinc-200'
        )}
      >
        {value}
      </Text>
      <Text className="text-zinc-400 dark:text-zinc-500 text-xs">{subtitle}</Text>
    </View>
  );
}
