import React, { useState } from 'react';
import {
  View,
  Text,
  Pressable,
  Modal,
  ScrollView,
} from 'react-native';
import { HelpCircle, X } from 'lucide-react-native';
import Animated, { FadeIn, FadeOut, SlideInDown } from 'react-native-reanimated';

export interface TooltipContent {
  title: string;
  description: string;
  calculation?: string;
  interpretation?: string;
}

// All metric explanations
export const METRIC_TOOLTIPS: Record<string, TooltipContent> = {
  valueScore: {
    title: 'Value Score',
    description: 'A 0-100 score measuring how undervalued the asset appears based on technical indicators.',
    calculation: 'Combines: position in 52-week range, distance from 200-day moving average, RSI levels, and drawdown from highs. Lower prices relative to historical averages = higher score.',
    interpretation: '70+: Deep value opportunity. 50-70: Moderately undervalued. 30-50: Fair value. <30: Potentially overvalued.',
  },
  qualityScore: {
    title: 'Quality Score',
    description: 'Measures the stability and reliability of the asset to filter out "value traps" - assets that are cheap for good reason.',
    calculation: 'Based on: earnings/return consistency over time, volatility levels (lower = better), and trend direction (not in steep decline).',
    interpretation: '60+: High quality, stable asset. 40-60: Moderate quality. <40: Higher risk, may be a value trap.',
  },
  valuePosition: {
    title: '52W Position',
    description: 'Where the current price sits within the 52-week (1 year) trading range.',
    calculation: '(Current Price - 52W Low) / (52W High - 52W Low) × 100',
    interpretation: '0-20%: Near yearly lows (potential value). 80-100%: Near yearly highs. Lower positions often indicate better entry points.',
  },
  distanceFromSMA200: {
    title: 'vs SMA200',
    description: 'The percentage distance from the 200-day Simple Moving Average, a key long-term trend indicator.',
    calculation: '(Current Price - 200-day SMA) / 200-day SMA × 100',
    interpretation: 'Negative: Below the long-term average (potential value). Positive: Above average. Values under -10% often signal undervaluation.',
  },
  rsi: {
    title: 'RSI (Relative Strength Index)',
    description: 'A momentum indicator measuring the speed and magnitude of recent price changes.',
    calculation: 'Based on average gains vs losses over 14 days, scaled 0-100.',
    interpretation: '<30: Oversold (potential buying opportunity). 30-70: Neutral. >70: Overbought. Low RSI combined with value signals can indicate good entry points.',
  },
  drawdown: {
    title: 'Drawdown from 52W High',
    description: 'How far the current price has fallen from its 52-week high.',
    calculation: '(Current Price - 52W High) / 52W High × 100',
    interpretation: 'Larger negative values mean bigger pullbacks. -20% or more often indicates significant value opportunity if fundamentals are intact.',
  },
  probability: {
    title: 'Probability of Being Higher',
    description: 'The historical probability that assets in similar undervalued conditions went higher over the given time period.',
    calculation: 'Found similar historical instances (matching value position, SMA distance, RSI, drawdown), then calculated % that were higher after 1/3/5 years.',
    interpretation: '80%+: Strong historical precedent. 65-80%: Good odds. <65%: Mixed historical results.',
  },
  similarInstances: {
    title: 'Similar Historical Instances',
    description: 'Past occasions when this asset had similar value characteristics to today.',
    calculation: 'Searched through 10 years of data for times when value position, SMA distance, RSI, and drawdown were similar (within tolerance bands).',
    interpretation: 'More instances = more reliable probability estimates. Shows actual returns achieved in those similar situations.',
  },
  medianReturn: {
    title: 'Median Return',
    description: 'The middle return value from all similar historical instances - half did better, half did worse.',
    calculation: 'Sorted all returns from similar instances and took the middle value.',
    interpretation: 'More reliable than average (not skewed by outliers). Represents a "typical" outcome from similar situations.',
  },
  signal: {
    title: 'Trading Signal',
    description: 'Overall recommendation based on combining value score, quality score, and historical probabilities.',
    calculation: 'STRONG_BUY: High value score + good quality + strong historical odds. BUY: Good value + decent quality. HOLD: Fair value or quality concerns. AVOID: Overvalued or poor quality.',
    interpretation: 'Use as a starting point for research, not as direct trading advice.',
  },
  valueCategory: {
    title: 'Value Category',
    description: 'Classification of how undervalued the asset appears.',
    calculation: 'DEEP_VALUE: Score 70+ and in bottom 30% of 52W range. VALUE: Score 50+. FAIR: Score 30-50. EXPENSIVE: Score <30.',
    interpretation: 'Deep value opportunities are rare but often have the best risk/reward if quality checks pass.',
  },
  hitRate: {
    title: 'Hit Rate',
    description: 'The percentage of times that similar undervalued situations resulted in positive returns.',
    calculation: 'Count of positive outcomes / Total similar instances × 100',
    interpretation: 'Higher is better. Compare to baseline (stocks are higher ~70% of the time over 5 years anyway). Value approach should beat this baseline.',
  },
  alpha: {
    title: 'Alpha (Outperformance)',
    description: 'How much the value strategy outperformed simply holding the S&P 500.',
    calculation: 'Value strategy average return - S&P 500 average return over same period.',
    interpretation: 'Positive alpha = value approach adds value. This is the "edge" of the strategy.',
  },
};

interface HelpButtonProps {
  metricKey: string;
  size?: number;
}

export function HelpButton({ metricKey, size = 14 }: HelpButtonProps) {
  const [visible, setVisible] = useState(false);
  const tooltip = METRIC_TOOLTIPS[metricKey];

  if (!tooltip) return null;

  return (
    <>
      <Pressable
        onPress={() => setVisible(true)}
        hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        className="ml-1"
      >
        <HelpCircle size={size} color="#71717A" />
      </Pressable>

      <Modal
        visible={visible}
        transparent
        animationType="none"
        onRequestClose={() => setVisible(false)}
      >
        <Pressable
          className="flex-1 bg-black/60 justify-end"
          onPress={() => setVisible(false)}
        >
          <Animated.View
            entering={SlideInDown.springify().damping(20)}
            exiting={FadeOut.duration(150)}
          >
            <Pressable onPress={(e) => e.stopPropagation()}>
              <View className="bg-zinc-900 rounded-t-3xl p-5 pb-10 border-t border-zinc-700">
                {/* Header */}
                <View className="flex-row items-center justify-between mb-4">
                  <Text className="text-white text-xl font-bold">{tooltip.title}</Text>
                  <Pressable
                    onPress={() => setVisible(false)}
                    className="w-8 h-8 rounded-full bg-zinc-800 items-center justify-center"
                  >
                    <X size={18} color="#A1A1AA" />
                  </Pressable>
                </View>

                <ScrollView showsVerticalScrollIndicator={false} style={{ maxHeight: 400 }}>
                  {/* Description */}
                  <Text className="text-zinc-300 text-base leading-6 mb-4">
                    {tooltip.description}
                  </Text>

                  {/* Calculation */}
                  {tooltip.calculation && (
                    <View className="bg-zinc-800 rounded-xl p-4 mb-4">
                      <Text className="text-blue-400 text-xs font-semibold mb-2">
                        HOW IT'S CALCULATED
                      </Text>
                      <Text className="text-zinc-300 text-sm leading-5">
                        {tooltip.calculation}
                      </Text>
                    </View>
                  )}

                  {/* Interpretation */}
                  {tooltip.interpretation && (
                    <View className="bg-zinc-800 rounded-xl p-4">
                      <Text className="text-emerald-400 text-xs font-semibold mb-2">
                        HOW TO INTERPRET
                      </Text>
                      <Text className="text-zinc-300 text-sm leading-5">
                        {tooltip.interpretation}
                      </Text>
                    </View>
                  )}
                </ScrollView>
              </View>
            </Pressable>
          </Animated.View>
        </Pressable>
      </Modal>
    </>
  );
}

// Label with help button
interface LabelWithHelpProps {
  label: string;
  metricKey: string;
  className?: string;
}

export function LabelWithHelp({ label, metricKey, className = '' }: LabelWithHelpProps) {
  return (
    <View className={`flex-row items-center ${className}`}>
      <Text className="text-zinc-500 text-xs">{label}</Text>
      <HelpButton metricKey={metricKey} />
    </View>
  );
}
