import React from 'react';
import { View, Text } from 'react-native';
import { TrendingUp, TrendingDown, Award, Target, Activity, Percent, BarChart3, Shield } from 'lucide-react-native';
import Animated, { FadeInUp } from 'react-native-reanimated';
import type { BacktestSummary } from '@/lib/api/stock-model';
import { cn } from '@/lib/cn';

interface BacktestStatsProps {
  summary: BacktestSummary;
}

export function BacktestStats({ summary }: BacktestStatsProps) {
  const outperforms = summary.alpha > 0;
  const significantAlpha = Math.abs(summary.alpha) >= 5;

  return (
    <View className="bg-white dark:bg-zinc-900 rounded-2xl p-4 shadow-lg">
      <Text className="text-lg font-bold text-zinc-800 dark:text-white mb-4">
        Backtest Results
      </Text>

      {/* Alpha highlight */}
      <Animated.View
        entering={FadeInUp.delay(100)}
        className={cn(
          'p-4 rounded-xl mb-4',
          outperforms ? 'bg-emerald-50 dark:bg-emerald-900/30' : 'bg-red-50 dark:bg-red-900/30'
        )}
      >
        <View className="flex-row items-center justify-between">
          <View className="flex-row items-center">
            {outperforms ? (
              <TrendingUp size={24} color="#10B981" />
            ) : (
              <TrendingDown size={24} color="#EF4444" />
            )}
            <Text
              className={cn(
                'ml-2 text-xl font-bold',
                outperforms
                  ? 'text-emerald-700 dark:text-emerald-400'
                  : 'text-red-700 dark:text-red-400'
              )}
            >
              Alpha: {summary.alpha >= 0 ? '+' : ''}
              {summary.alpha.toFixed(1)}%
            </Text>
          </View>
          <Text className="text-zinc-500 dark:text-zinc-400 text-sm">vs S&P 500</Text>
        </View>
        <Text className="text-zinc-600 dark:text-zinc-300 text-sm mt-2">
          {outperforms
            ? `Model outperformed S&P 500 by ${summary.alpha.toFixed(1)}% annually`
            : `Model underperformed S&P 500 by ${Math.abs(summary.alpha).toFixed(1)}% annually`}
          {significantAlpha && outperforms && ' - Significant outperformance!'}
        </Text>
      </Animated.View>

      {/* Primary Stats Grid */}
      <View className="flex-row flex-wrap">
        <StatBox
          icon={<TrendingUp size={18} color="#10B981" />}
          label="Model Return"
          value={`${summary.annualizedModelReturn >= 0 ? '+' : ''}${summary.annualizedModelReturn.toFixed(1)}%`}
          sublabel="Annualized"
          delay={150}
        />
        <StatBox
          icon={<Activity size={18} color="#3B82F6" />}
          label="S&P 500"
          value={`${summary.annualizedSp500Return >= 0 ? '+' : ''}${summary.annualizedSp500Return.toFixed(1)}%`}
          sublabel="Annualized"
          delay={200}
        />
        <StatBox
          icon={<Target size={18} color="#8B5CF6" />}
          label="Sharpe Ratio"
          value={summary.sharpeRatio.toFixed(2)}
          sublabel="Risk-adjusted"
          delay={250}
          highlight={summary.sharpeRatio >= 1}
        />
        <StatBox
          icon={<TrendingDown size={18} color="#EF4444" />}
          label="Max Drawdown"
          value={`-${summary.maxDrawdown.toFixed(1)}%`}
          sublabel="Worst peak-to-trough"
          delay={300}
        />
        <StatBox
          icon={<Award size={18} color="#F59E0B" />}
          label="Win Rate"
          value={`${summary.winRate.toFixed(0)}%`}
          sublabel={`${summary.outperformancePeriods}/${summary.totalPeriods} periods`}
          delay={350}
          highlight={summary.winRate >= 55}
        />
        <StatBox
          icon={<Percent size={18} color="#06B6D4" />}
          label="Total Return"
          value={`${summary.totalModelReturn >= 0 ? '+' : ''}${summary.totalModelReturn.toFixed(0)}%`}
          sublabel={`vs ${summary.totalSp500Return >= 0 ? '+' : ''}${summary.totalSp500Return.toFixed(0)}% S&P`}
          delay={400}
        />
      </View>

      {/* Advanced Risk Metrics */}
      <View className="mt-4 pt-4 border-t border-zinc-100 dark:border-zinc-800">
        <Text className="text-sm font-semibold text-zinc-700 dark:text-zinc-300 mb-3">
          Advanced Risk Metrics
        </Text>
        <View className="flex-row flex-wrap">
          <StatBox
            icon={<Shield size={18} color="#10B981" />}
            label="Sortino Ratio"
            value={summary.sortinoRatio.toFixed(2)}
            sublabel="Downside risk"
            delay={450}
            highlight={summary.sortinoRatio >= 1.5}
          />
          <StatBox
            icon={<BarChart3 size={18} color="#6366F1" />}
            label="Calmar Ratio"
            value={summary.calmarRatio.toFixed(2)}
            sublabel="Return / Drawdown"
            delay={500}
            highlight={summary.calmarRatio >= 1}
          />
          <StatBox
            icon={<Activity size={18} color="#EC4899" />}
            label="Info Ratio"
            value={summary.informationRatio.toFixed(2)}
            sublabel="Excess return / TE"
            delay={550}
            highlight={summary.informationRatio >= 0.5}
          />
          <StatBox
            icon={<TrendingUp size={18} color="#F97316" />}
            label="Profit Factor"
            value={summary.profitFactor >= 10 ? '>10' : summary.profitFactor.toFixed(2)}
            sublabel="Win/Loss ratio"
            delay={600}
            highlight={summary.profitFactor >= 1.5}
          />
        </View>
      </View>
    </View>
  );
}

function StatBox({
  icon,
  label,
  value,
  sublabel,
  delay,
  highlight = false,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sublabel: string;
  delay: number;
  highlight?: boolean;
}) {
  return (
    <Animated.View
      entering={FadeInUp.delay(delay)}
      className="w-1/2 p-2"
    >
      <View className={cn(
        'rounded-xl p-3',
        highlight ? 'bg-emerald-50 dark:bg-emerald-900/20' : 'bg-zinc-50 dark:bg-zinc-800'
      )}>
        <View className="flex-row items-center mb-1">
          {icon}
          <Text className="text-zinc-500 dark:text-zinc-400 text-xs ml-1.5">{label}</Text>
        </View>
        <Text className={cn(
          'text-lg font-bold',
          highlight ? 'text-emerald-600 dark:text-emerald-400' : 'text-zinc-900 dark:text-white'
        )}>
          {value}
        </Text>
        <Text className="text-zinc-400 dark:text-zinc-500 text-xs">{sublabel}</Text>
      </View>
    </Animated.View>
  );
}
