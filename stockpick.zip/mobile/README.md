# Value Asset Finder

A mobile app that identifies undervalued stocks and crypto with high probability of appreciation based on historical similar instances. Uses a CRT-style pattern matching approach to find assets currently below fair value.

## Core Concept

Unlike momentum-based models, this app focuses on **value investing** principles:

1. **Find Undervalued Assets**: Identifies stocks & crypto trading below historical fair value
2. **Pattern Matching**: Matches current conditions to similar past instances
3. **Historical Probability**: Calculates actual outcomes from similar historical situations
4. **Quality Filters**: Avoids value traps with quality and stability checks

## Features

### Value Picks Tab
- Shows top 5 undervalued assets with highest upside probability
- **Value Metrics**: Score, quality, 52W position, distance from SMA200, RSI, drawdown
- **Historical Probability**: Based on actual outcomes from similar past instances
- **Similar Past Instances**: Shows what happened when assets were in similar conditions
- **Help Tooltips**: Tap the ? icons to learn how each metric is calculated
- **Tap any stock** to view detailed chart with historical buy signals
- Categories: DEEP_VALUE, VALUE, FAIR, EXPENSIVE
- Signals: STRONG_BUY, BUY, HOLD, AVOID

### Stock Detail Screen (NEW)
- **Price Chart**: 2-year price history with gradient fill
- **Historical Buy Signals**: Green markers show when the model would have signaled a buy
- **Signal Performance**: Win rate, average returns from past buy signals
- **Current Metrics**: Real-time value metrics for the asset
- Shows what would have happened if you followed the signals historically

### Evidence Tab
- Historical validation of the value approach
- **Probability of Being Higher**: After 1Y, 3Y, 5Y based on similar instances
- **Alpha vs S&P 500**: How much value picks outperformed
- **Median Returns**: By time horizon
- Total instances analyzed

### All Assets Tab
- **200+ assets**: Stocks across all sectors + 15 major cryptocurrencies
- Filter by: All, Stocks only, Crypto only
- Search by symbol, name, or sector
- Sort by: Value Score, 1Y Probability, 5Y Probability, Quality, Name
- Crypto assets highlighted with orange badges

### Loading Experience
- **Real-time progress tracking**: Shows actual data fetching and analysis progress
- **Animated status bar**: Tracks batches and individual stock analysis
- **Step indicators**: Visual feedback for each phase of loading

## How It Works

### Value Metrics (tap ? for details)
- **Value Score**: 0-100 measuring how undervalued (higher = more undervalued)
- **Quality Score**: Stability and reliability to filter value traps
- **52W Position**: Where price sits in yearly range (lower = more value)
- **vs SMA200**: % above/below 200-day moving average
- **RSI**: Momentum indicator (under 30 = oversold)
- **Drawdown**: How far below 52-week high

### Historical Pattern Matching
1. Look through 10 years of historical data
2. Find instances where the asset had similar value characteristics
3. Measure what actually happened 1, 3, and 5 years later
4. Calculate probability and median returns from those instances

### Quality Filters (Avoiding Value Traps)
- **Earnings Stability**: Consistency of returns over time
- **Volatility**: Lower volatility = higher quality
- **Trend Direction**: Avoid assets in steep decline

## Assets Analyzed (200+)

### Stocks by Sector
- **Technology (37)**: AAPL, MSFT, GOOGL, NVDA, META, AMD, CRM, ADBE, NOW, PANW, CRWD, PLTR, SNOW, DDOG...
- **Financial (21)**: JPM, V, MA, GS, BAC, WFC, MS, SCHW, CME, BLK, SPGI...
- **Healthcare (29)**: UNH, JNJ, LLY, MRK, ABBV, PFE, AMGN, ISRG, SYK...
- **Consumer (40)**: AMZN, HD, COST, MCD, NKE, NFLX, SBUX, TGT, LULU, CMG...
- **Industrial (30)**: CAT, DE, UNP, HON, GE, BA, LMT, UPS, FDX...
- **Energy (20)**: XOM, CVX, COP, SLB, MPC, OXY...
- **Utilities (20)**: NEE, DUK, SO, AEP, XEL...
- **REITs (20)**: PLD, AMT, EQIX, PSA, SPG, O...
- **Materials (20)**: LIN, SHW, NEM, FCX, NUE...

### Crypto (22)
- **Major Coins**: BTC, ETH, SOL, XRP, ADA, AVAX, DOT, LINK, MATIC, UNI, ATOM, LTC, BCH, DOGE, XLM
- **Crypto Stocks**: COIN, MSTR, MARA, RIOT, HUT, BITF, CLSK

## Key Metrics Explained

Tap the ? icon next to any metric to see:
- **What it measures**
- **How it's calculated**
- **How to interpret the values**

## Performance Optimization: Pre-computed Data

The app supports pre-computed data to load instantly instead of fetching/calculating live (which takes 2-3 minutes).

### Quick Setup (GitHub Gist - Easiest)

1. **Generate the data** (on your computer with Node.js):
   ```bash
   cd scripts
   npx ts-node generate-stock-data.ts > stock-data.json
   ```

2. **Upload to GitHub Gist**:
   - Go to https://gist.github.com
   - Create a new gist, paste the JSON content
   - Click "Create secret gist"
   - Click "Raw" to get the raw URL

3. **Add the URL to your app**:
   - Go to the ENV tab in Vibecode
   - Add: `EXPO_PUBLIC_PRECOMPUTED_DATA_URL=<your_raw_gist_url>`

4. **Run daily** (optional): Set up a GitHub Action or cron job to regenerate the data nightly

### How It Works
- If pre-computed data URL is set and data is <24h old → loads instantly
- If data is stale or URL not set → falls back to live calculation
- Data includes all stock scores, factor analysis, and signals

## Tech Stack

- Expo SDK 53 / React Native
- React Query for data fetching/caching
- NativeWind (TailwindCSS) for styling
- Yahoo Finance API for 10 years of historical prices
- React Native SVG for charts
- FlashList for performant lists
- React Native Reanimated for animations

## Disclaimer

Past performance does not guarantee future results. Undervalued assets can remain undervalued or decline further. Crypto is highly volatile. This analysis is for educational purposes only and not financial advice. Always do your own research before investing.
